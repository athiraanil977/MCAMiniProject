# System Architecture

This document describes the architectural framework of the **College Asset Management System**.

## Architectural Style: Layered Enterprise Pattern

The system implements a classic multi-tiered enterprise architecture with strict separation of concerns:

```
[ Client: React + Vite ]
          ↓ (HTTP/REST + JWT Bearer)
[ REST API Gateway: Express Router ]
          ↓ (Payload validations + Route mapping)
[ Controllers Layer ]
          ↓ (Extract variables, execute orchestration, return standardized response)
[ Services Layer ]
          ↓ (Orchestrate transactional logic & business rule processing)
[ Repositories Layer ]
          ↓ (Direct data queries using Prisma client)
[ Database: MySQL Engine ]
```

### Layer Responsibilities

#### 1. Clients
- Responsible only for displaying details, capturing input events, and managing route state transitions.
- Synchronizes local variables with database properties using **TanStack Query**.
- Automatically intercepts API failures (like `401 Unauthorized`) to clear local tokens.

#### 2. REST API / Routing
- Dispatches HTTP requests to appropriate controllers.
- Integrates authorization gates and request payload size throttles.

#### 3. Controllers
- Minimal logic execution.
- Gathers user credentials from headers, query strings, and body models.
- Validates parameters (via Zod or validation helper).
- Invokes specific **Services** and formats outcome data.

#### 4. Services
- Houses **all core business logic**.
- Performs operations such as password hashing, role verifications, and computation.
- Connects multiple repositories inside single transaction scopes.

#### 5. Repositories
- The ONLY location where database querying (Prisma Client queries) is executed.
- Minimizes query duplicate declarations.

#### 6. Prisma ORM & MySQL
- Manages relational constraints, database connection pools, and automatic migrations.

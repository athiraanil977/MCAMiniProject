# Project Structure Documentation

This document explains the organization of files and folder contents within the College Asset Management System.

---

## Top-Level Directory Layout

- `client/` - Frontend single-page React application powered by Vite.
- `server/` - Backend Node.js / Express REST API server.
- `docs/` - System configuration and onboarding documentation.
- `uploads/` - Default system folder for handling file attachments.

---

## Backend Directory Details

Inside `server/`:
- `prisma/` - Prisma Schema definitions and database migration scripts.
- `src/` - Server application source files:
  - `config/` - External connection profiles (CORS settings, database environments).
  - `controllers/` - Express request managers; calls business logic.
  - `services/` - Houses all core business rules and transaction boundaries.
  - `repositories/` - Location for executing raw or compiled Prisma DB queries.
  - `routes/` - REST endpoints categorized by resource.
  - `middlewares/` - Global and resource auth interceptors, loggers, validation checks.
  - `validators/` - Input parameter schema specifications (Zod/express-validator).
  - `utils/` - Shared functions (JWT encrypts, formatting utilities).
  - `constants/` - System-wide status codes, notification templates.
  - `database/` - Exports singleton Prisma Database connection client.

---

## Frontend Directory Details

Inside `client/`:
- `src/` - React frontend application source files:
  - `api/` - Outbound Axios service definitions.
  - `components/` - Global components (buttons, cards, protected route gates).
  - `layouts/` - Shell structures (Sidebars, Navbar headers, wrappers).
  - `pages/` - Individual views loaded by routing profiles.
  - `hooks/` - Customized React hooks.
  - `contexts/` - Global state managers (Auth status, active themes).
  - `routes/` - AppRoutes configurations mapping paths to layout outlets.
  - `styles/` - Design system configuration files and globals.
  - `utils/` - Layout helpers (classname merges).
  - `lib/` - Third-party API instances (Axios settings, React Query clients).

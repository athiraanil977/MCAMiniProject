# Installation Guide

This document describes how to install dependencies and run the College Asset Management System locally.

## Prerequisites

Before starting, make sure you have installed:
- **Node.js** (Version 18.x or newer)
- **npm** (Version 10.x or newer)
- **MySQL Server** (Version 8.0 or newer)

---

## 1. Setup Environment Variables

Copy the default environment templates and update values:

- In `server/`, edit the database connection string in `.env` to match your local MySQL configuration:
  ```env
  DATABASE_URL="mysql://YOUR_MYSQL_USER:YOUR_MYSQL_PASSWORD@localhost:3306/college"
  ```
- In `client/`, check the API URL in `.env` (defaults to `http://localhost:5000/api`).

---

## 2. Server Installation & Initialization

1. Navigate to the server folder:
   ```bash
   cd server
   ```
2. Install npm packages:
   ```bash
   npm install
   ```
3. Run the Prisma Client generator:
   ```bash
   npm run prisma:generate
   ```
4. Perform database migrations (once database schema is defined):
   ```bash
   npm run prisma:migrate
   ```
5. Start the Express development server:
   ```bash
   npm run dev
   ```

---

## 3. Client Installation & Start

1. Navigate to the client folder:
   ```bash
   cd ../client
   ```
2. Install npm packages:
   ```bash
   npm install
   ```
3. Start the Vite local development server:
   ```bash
   npm run dev
   ```
4. Access the application in your browser at `http://localhost:3000`.

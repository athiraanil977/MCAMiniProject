# Environment Setup Guide

This document describes all configurable settings available via environment variables in the College Asset Management System.

---

## Backend `.env` Variables

Create a file named `.env` in the `server/` directory and configure the variables:

| Variable | Default Value | Description |
| :--- | :--- | :--- |
| `PORT` | `5000` | Port where the Express application listens for traffic. |
| `NODE_ENV` | `development` | Server execution mode (`development` or `production`). |
| `DATABASE_URL` | `mysql://root:password@localhost:3306/college` | MySQL connection credentials used by Prisma Client. |
| `JWT_SECRET` | *(Random Hash)* | Key used to sign JWT token payloads for user sessions. |
| `JWT_EXPIRES_IN` | `7d` | Shelf life of logged in user credentials token. |
| `UPLOAD_PATH` | `uploads` | File storage path where uploads are written. |
| `MAX_FILE_SIZE` | `5242880` | Maximum file attachment size constraint (in bytes). |

> [!WARNING]
> Never commit production `.env` files with active passwords to git. Always use git secret filters or server environmental settings in live environments.

---

## Frontend `.env` Variables

Create a file named `.env` in the `client/` directory:

| Variable | Default Value | Description |
| :--- | :--- | :--- |
| `VITE_API_URL` | `http://localhost:5000/api` | Base API target URL where Axios directs calls. |

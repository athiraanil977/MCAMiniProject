# College Asset Management System

A production-ready, scalable, and secure College Asset Management System built with a React frontend and an Express.js/MySQL backend using Prisma ORM.

## Architecture

This project is built using an enterprise-tier architecture with separation of concerns:

- **Client (React)**: High-fidelity user interface, modular routing, and TanStack Query state synchronization.
- **REST API Gateway**: Connects frontend requests to backend controllers.
- **Express Controllers**: Handles HTTP requests, input validation, and maps results to client responses.
- **Services Layer**: Orchestrates business logic and transactional processing.
- **Repositories Layer**: Direct database queries using Prisma ORM.
- **MySQL Database**: Persistent storage for all college assets, locations, users, and audit logs.

## Directory Structure

- `client/` - React frontend (Vite, Tailwind CSS, shadcn/ui)
- `server/` - Node.js & Express backend (Prisma ORM, MySQL)
- `docs/` - Project documentation and guides
- `uploads/` - Shared file upload store

## Quick Start

Refer to the detailed documents in the `docs/` folder:

1. [Installation Guide](docs/installation.md)
2. [Environment Setup Guide](docs/environment_setup.md)
3. [Architecture Documentation](docs/architecture.md)
4. [Project Structure Documentation](docs/project_structure.md)

## Development Scripts

### Root Workspace Commands

To set up the project:
1. Configure `.env` files in both `client/` and `server/`.
2. Follow instructions in the [Installation Guide](docs/installation.md).

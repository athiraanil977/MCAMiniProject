import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { KeyRound, Mail, Eye, EyeOff, AlertCircle, ShieldCheck } from 'lucide-react';

const loginSchema = z.object({
  email: z.string().min(1, 'Email is required').email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

export const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const onSubmit = async (data) => {
    setErrorMsg('');
    setIsSubmitting(true);
    try {
      const response = await login(data.email, data.password);
      if (response.success) {
        navigate('/dashboard');
      } else {
        setErrorMsg(response.message || 'Invalid email or password.');
      }
    } catch (err) {
      setErrorMsg('Cannot connect to server. Please ensure the backend is running on port 5000.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-slate-950 px-4 overflow-hidden">

      {/* ── Background glow orbs ───────────────────────────────────── */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-20 -left-20 h-[500px] w-[500px] rounded-full bg-violet-700/20 blur-[120px]" />
        <div className="absolute -bottom-10 -right-10 h-[400px] w-[400px] rounded-full bg-indigo-700/20 blur-[120px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[300px] w-[300px] rounded-full bg-purple-800/10 blur-[80px]" />
        {/* Subtle grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              'linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />
      </div>

      {/* ── Card ───────────────────────────────────────────────────── */}
      <div className="relative z-10 w-full max-w-[420px]">

        {/* Glow ring behind the card */}
        <div className="absolute -inset-1 rounded-3xl bg-gradient-to-br from-violet-600/30 via-indigo-600/20 to-transparent blur-xl" />

        <div className="relative rounded-2xl border border-white/[0.07] bg-slate-900/80 backdrop-blur-2xl shadow-2xl shadow-black/50 p-8 overflow-hidden">

          {/* Top shimmer line */}
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-500/60 to-transparent" />

          {/* ── Logo ── */}
          <div className="flex flex-col items-center gap-3 mb-8">
            <div className="relative">
              <div className="absolute inset-0 rounded-2xl bg-violet-500/40 blur-lg scale-110" />
              <div className="relative h-14 w-14 rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-xl">
                <ShieldCheck size={26} className="text-white" strokeWidth={2.5} />
              </div>
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold tracking-tight text-white">Welcome Back</h1>
              <p className="text-sm text-slate-400 mt-0.5">College Asset Management System</p>
            </div>
          </div>

          {/* ── Error banner ── */}
          {errorMsg && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3">
              <AlertCircle size={15} className="text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-rose-400">Authentication Error</p>
                <p className="text-xs text-rose-400/80 mt-0.5">{errorMsg}</p>
              </div>
            </div>
          )}

          {/* ── Form ── */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">

            {/* Email */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-widest">
                Email Address
              </label>
              <div className={`relative flex items-center rounded-xl border transition-all duration-200 ${
                errors.email
                  ? 'border-rose-500/50 bg-rose-500/5'
                  : 'border-white/10 bg-white/5 focus-within:border-violet-500/50 focus-within:bg-violet-500/5'
              }`}>
                <Mail size={16} className="absolute left-3.5 text-slate-500 shrink-0" />
                <input
                  type="email"
                  placeholder="admin@college.com"
                  autoComplete="email"
                  className="w-full bg-transparent text-sm py-3 pl-10 pr-4 outline-none text-white placeholder:text-slate-600"
                  {...register('email')}
                />
              </div>
              {errors.email && (
                <p className="text-xs text-rose-400 font-medium flex items-center gap-1">
                  <AlertCircle size={11} /> {errors.email.message}
                </p>
              )}
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-widest">
                  Password
                </label>
                <Link
                  to="/forgot-password"
                  className="text-[11px] text-violet-400 hover:text-violet-300 font-medium transition-colors"
                >
                  Forgot password?
                </Link>
              </div>
              <div className={`relative flex items-center rounded-xl border transition-all duration-200 ${
                errors.password
                  ? 'border-rose-500/50 bg-rose-500/5'
                  : 'border-white/10 bg-white/5 focus-within:border-violet-500/50 focus-within:bg-violet-500/5'
              }`}>
                <KeyRound size={16} className="absolute left-3.5 text-slate-500 shrink-0" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="w-full bg-transparent text-sm py-3 pl-10 pr-11 outline-none text-white placeholder:text-slate-600"
                  {...register('password')}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 text-slate-500 hover:text-slate-300 transition-colors"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && (
                <p className="text-xs text-rose-400 font-medium flex items-center gap-1">
                  <AlertCircle size={11} /> {errors.password.message}
                </p>
              )}
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-2 py-3 rounded-xl font-semibold text-sm text-white
                bg-gradient-to-r from-violet-600 to-indigo-600
                hover:from-violet-500 hover:to-indigo-500
                active:scale-[0.98]
                transition-all duration-200
                shadow-lg shadow-violet-700/30
                disabled:opacity-60 disabled:cursor-not-allowed
                flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                  Signing in…
                </>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* ── Credentials hint ── */}
          <div className="mt-6 pt-5 border-t border-white/[0.06] text-center">
            <p className="text-[11px] text-slate-600 mb-1.5 uppercase tracking-wider font-semibold">
              Default Admin Credentials
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.04] border border-white/[0.06] text-xs">
              <span className="text-slate-300 font-mono">admin@college.com</span>
              <span className="text-slate-600">/</span>
              <span className="text-slate-300 font-mono">Admin@123</span>
            </div>
          </div>

          {/* Bottom shimmer line */}
          <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-indigo-500/30 to-transparent" />
        </div>
      </div>
    </div>
  );
};

export default Login;

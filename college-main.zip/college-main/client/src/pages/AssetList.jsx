import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { 
  getAssets, 
  deleteAsset, 
  restoreAsset 
} from '../services/assetService';
import { getCategories, getLocations } from '../services/masterService';
import { useAuth } from '../contexts/AuthContext';
import DataTable from '../components/DataTable';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import ConfirmDialog from '../components/ConfirmDialog';
import { Plus, Eye, Edit, Trash2, RotateCcw, Clock } from 'lucide-react';

export const AssetList = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  
  // Permissions checker
  const isOperator = user?.role === 'ADMIN' || user?.role === 'Super Admin' || user?.role === 'Asset Manager' || user?.role === 'Store Keeper';

  // Filters State
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [showDeleted, setShowDeleted] = useState(false);
  const [categoryId, setCategoryId] = useState('');
  const [locationId, setLocationId] = useState('');
  const [warrantyExpired, setWarrantyExpired] = useState(false);

  // Modal dialog controls
  const [deleteId, setDeleteId] = useState(null);
  const [restoreId, setRestoreId] = useState(null);

  // Debounce search input
  React.useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 400);
    return () => clearTimeout(handler);
  }, [search]);

  // Query assets
  const { data, isLoading } = useQuery({
    queryKey: ['assets', { page, limit, search: debouncedSearch, categoryId, locationId, showDeleted, warrantyExpired }],
    queryFn: () => getAssets({ 
      page, 
      limit, 
      search: debouncedSearch, 
      categoryId: categoryId ? parseInt(categoryId, 10) : undefined,
      locationId: locationId ? parseInt(locationId, 10) : undefined,
      showDeleted, 
      warrantyExpired 
    }),
  });

  // Query lookups
  const { data: categories } = useQuery({
    queryKey: ['categories', { limit: 100 }],
    queryFn: () => getCategories({ limit: 100 }),
  });

  const { data: locations } = useQuery({
    queryKey: ['locations', { limit: 100 }],
    queryFn: () => getLocations({ limit: 100 }),
  });

  // Delete Mutation
  const deleteMutation = useMutation({
    mutationFn: deleteAsset,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      setDeleteId(null);
    },
  });

  // Restore Mutation
  const restoreMutation = useMutation({
    mutationFn: restoreAsset,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      setRestoreId(null);
    },
  });

  const resetFilters = () => {
    setCategoryId('');
    setLocationId('');
    setWarrantyExpired(false);
    setSearch('');
  };

  const columns = [
    { key: 'assetTag', label: 'Tag', className: 'font-mono font-bold text-primary' },
    { key: 'assetName', label: 'Asset Name', className: 'font-semibold' },
    { key: 'category', label: 'Category', render: (row) => row.category?.categoryName },
    { key: 'location', label: 'Location', render: (row) => row.location?.locationName },
    {
      key: 'status',
      label: 'Status',
      render: (row) => {
        const statusColors = {
          Available: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
          Allocated: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
          Reserved: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
          Disposed: 'bg-rose-500/10 text-rose-600 border-rose-500/20',
          Maintenance: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
        };
        const name = row.status?.statusName || 'Unknown';
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${statusColors[name] || 'bg-slate-500/10 text-slate-600 border-slate-500/20'}`}>
            {name}
          </span>
        );
      },
    },
    { key: 'condition', label: 'Condition', render: (row) => row.condition?.conditionName },
    {
      key: 'actions',
      label: 'Actions',
      align: 'right',
      render: (row) => (
        <div className="flex gap-2 justify-end">
          <Link
            to={`/assets/${row.id}`}
            className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
            title="View Details"
          >
            <Eye size={16} />
          </Link>
          {isOperator && !showDeleted && (
            <>
              <Link
                to={`/assets/${row.id}/edit`}
                className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
                title="Edit"
              >
                <Edit size={16} />
              </Link>
              <button
                onClick={() => setDeleteId(row.id)}
                className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-all"
                title="Archive"
              >
                <Trash2 size={16} />
              </button>
            </>
          )}
          {isOperator && showDeleted && (
            <button
              onClick={() => setRestoreId(row.id)}
              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-500/10 transition-all"
              title="Restore"
            >
              <RotateCcw size={16} />
            </button>
          )}
        </div>
      ),
    },
  ];

  const filterActions = (
    <div className="flex flex-wrap items-center gap-3">
      {/* Category Dropdown */}
      <select
        value={categoryId}
        onChange={(e) => setCategoryId(e.target.value)}
        className="px-3 py-2 rounded-xl border border-border bg-background text-sm font-semibold hover:bg-secondary transition-all outline-none"
      >
        <option value="">All Categories</option>
        {categories?.data?.map((cat) => (
          <option key={cat.id} value={cat.id}>
            {cat.categoryName}
          </option>
        ))}
      </select>

      {/* Location Dropdown */}
      <select
        value={locationId}
        onChange={(e) => setLocationId(e.target.value)}
        className="px-3 py-2 rounded-xl border border-border bg-background text-sm font-semibold hover:bg-secondary transition-all outline-none"
      >
        <option value="">All Locations</option>
        {locations?.data?.map((loc) => (
          <option key={loc.id} value={loc.id}>
            {loc.locationName}
          </option>
        ))}
      </select>

      {/* Warranty Expired checkbox */}
      <button
        onClick={() => setWarrantyExpired(!warrantyExpired)}
        className={`px-3 py-2 rounded-xl border text-sm font-semibold transition-all flex items-center gap-1.5 ${
          warrantyExpired ? 'bg-rose-500/15 border-rose-500/35 text-rose-400' : 'border-border hover:bg-secondary'
        }`}
      >
        <Clock size={14} />
        Warranty Expired
      </button>

      {/* Reset button */}
      {(categoryId || locationId || warrantyExpired || search) && (
        <button
          onClick={resetFilters}
          className="p-2 rounded-xl border border-border hover:bg-secondary text-xs font-semibold flex items-center gap-1 transition-all"
          title="Clear Filters"
        >
          <RotateCcw size={13} />
          Reset
        </button>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Assets' }]} />

      <PageHeader
        title={showDeleted ? 'Archived Assets' : 'Asset Inventory'}
        description="Browse, filter, and track technical devices, smart displays, and laboratory assets."
      >
        <button
          onClick={() => setShowDeleted(!showDeleted)}
          className="px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all"
        >
          {showDeleted ? 'Show Active' : 'Show Archived'}
        </button>
        {isOperator && !showDeleted && (
          <Link
            to="/assets/new"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all shadow-lg shadow-primary/10"
          >
            <Plus size={18} />
            Register Asset
          </Link>
        )}
      </PageHeader>

      <DataTable
        columns={columns}
        data={data?.data || []}
        loading={isLoading}
        totalItems={data?.meta?.total || 0}
        page={page}
        limit={limit}
        onPageChange={setPage}
        onSearchChange={setSearch}
        onLimitChange={setLimit}
        searchPlaceholder="Search by tag, name, barcode..."
        filterActions={filterActions}
      />

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={() => deleteMutation.mutate(deleteId)}
        title="Archive Asset profile?"
        description="This will soft-delete the asset. Pointers remain stored for reference audits."
        confirmText="Archive"
        isDanger={true}
        loading={deleteMutation.isPending}
      />

      {/* Restore Confirmation */}
      <ConfirmDialog
        open={restoreId !== null}
        onClose={() => setRestoreId(null)}
        onConfirm={() => restoreMutation.mutate(restoreId)}
        title="Restore Asset profile?"
        description="This will restore the asset record back into active catalog registries."
        confirmText="Restore"
        loading={restoreMutation.isPending}
      />
    </div>
  );
};

export default AssetList;

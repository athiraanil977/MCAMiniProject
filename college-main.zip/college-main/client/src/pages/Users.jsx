import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Plus, Shield, Mail, Edit, Trash2, X, Save, Search,
  UserCheck, UserX, Eye, EyeOff, RefreshCw
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import {
  getUsers, createUser, updateUser, deleteUser,
  activateUser, deactivateUser,
} from '../services/userService';

// ── Static seed data — matches DB seed ──────────────────────────────────────
const ROLES = [
  { id: 1, roleName: 'Super Admin' },
  { id: 2, roleName: 'Asset Manager' },
  { id: 3, roleName: 'Department Staff' },
  { id: 4, roleName: 'Faculty' },
  { id: 5, roleName: 'Lab Assistant' },
  { id: 6, roleName: 'Store Keeper' },
  { id: 7, roleName: 'Viewer' },
  { id: 8, roleName: 'Student' },
];
const DEPARTMENTS = [
  { id: 1, departmentName: 'Computer Science' },
  { id: 2, departmentName: 'Mechanical' },
  { id: 3, departmentName: 'Civil' },
  { id: 4, departmentName: 'Electronics' },
  { id: 5, departmentName: 'Library' },
  { id: 6, departmentName: 'Administration' },
  { id: 7, departmentName: 'Accounts' },
  { id: 8, departmentName: 'Office' },
  { id: 9, departmentName: 'Store' },
];

// ── Zod schemas ──────────────────────────────────────────────────────────────
const pwdSchema = z
  .string()
  .min(8, 'At least 8 characters')
  .regex(/[a-z]/, 'Needs a lowercase letter')
  .regex(/[A-Z]/, 'Needs an uppercase letter')
  .regex(/[0-9]/, 'Needs a number')
  .regex(/[^a-zA-Z0-9]/, 'Needs a special character');

const createSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email'),
  employeeId: z.string().optional().or(z.literal('')),
  phone: z
    .string()
    .regex(/^\+?[0-9\s-]{7,15}$/, 'Invalid phone number')
    .optional()
    .or(z.literal('')),
  password: pwdSchema,
  roleId: z.preprocess((v) => parseInt(v, 10), z.number().int().positive('Select a role')),
  departmentId: z.preprocess(
    (v) => (v === '' || v == null ? null : parseInt(v, 10)),
    z.number().int().positive().nullable().optional()
  ),
  status: z.enum(['ACTIVE', 'INACTIVE', 'PENDING']).optional(),
});

const editSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').optional(),
  email: z.string().email('Invalid email').optional(),
  employeeId: z.string().optional().or(z.literal('')),
  phone: z
    .string()
    .regex(/^\+?[0-9\s-]{7,15}$/, 'Invalid phone number')
    .optional()
    .or(z.literal('')),
  password: pwdSchema.optional().or(z.literal('')),
  roleId: z.preprocess((v) => parseInt(v, 10), z.number().int().positive('Select a role')).optional(),
  departmentId: z.preprocess(
    (v) => (v === '' || v == null ? null : parseInt(v, 10)),
    z.number().int().positive().nullable().optional()
  ),
  status: z.enum(['ACTIVE', 'INACTIVE', 'PENDING']).optional(),
});

// ── Role badge colours ───────────────────────────────────────────────────────
const ROLE_COLORS = {
  'Super Admin':      'bg-violet-500/15 text-violet-500 border-violet-500/25',
  'Asset Manager':    'bg-blue-500/15 text-blue-500 border-blue-500/25',
  'Department Staff': 'bg-cyan-500/15 text-cyan-500 border-cyan-500/25',
  'Faculty':          'bg-emerald-500/15 text-emerald-500 border-emerald-500/25',
  'Lab Assistant':    'bg-yellow-500/15 text-yellow-600 border-yellow-500/25',
  'Store Keeper':     'bg-orange-500/15 text-orange-500 border-orange-500/25',
  'Viewer':           'bg-slate-500/15 text-slate-400 border-slate-500/25',
  'Student':          'bg-pink-500/15 text-pink-500 border-pink-500/25',
};

// ── User Form Modal ──────────────────────────────────────────────────────────
const UserModal = ({ user, onClose, onSave }) => {
  const isEdit = !!user;
  const [showPwd, setShowPwd] = useState(false);
  const schema = isEdit ? editSchema : createSchema;

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(schema),
    defaultValues: isEdit
      ? {
          name: user.name,
          email: user.email,
          employeeId: user.employeeId || '',
          phone: user.phone || '',
          password: '',
          roleId: user.roleId,
          departmentId: user.departmentId || '',
          status: user.status,
        }
      : { name: '', email: '', employeeId: '', phone: '', password: '', roleId: '', departmentId: '', status: 'ACTIVE' },
  });

  const inputCls = 'w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all';
  const labelCls = 'block text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5';
  const errCls = 'text-xs text-rose-400 font-medium mt-1';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-background border border-border rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-lg font-bold">{isEdit ? 'Edit User' : 'Create New User'}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {isEdit ? `Updating account for ${user.name}` : 'Register a new staff or student account'}
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-secondary transition-all text-muted-foreground">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSave)} className="p-6 space-y-4">
          {/* Name + Email */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Full Name *</label>
              <input {...register('name')} placeholder="Dr. John Smith" className={inputCls} />
              {errors.name && <p className={errCls}>{errors.name.message}</p>}
            </div>
            <div>
              <label className={labelCls}>Email Address *</label>
              <input {...register('email')} type="email" placeholder="john@college.com" className={inputCls} />
              {errors.email && <p className={errCls}>{errors.email.message}</p>}
            </div>
          </div>

          {/* Employee ID + Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Employee ID</label>
              <input {...register('employeeId')} placeholder="EMP-001" className={inputCls} />
            </div>
            <div>
              <label className={labelCls}>Phone Number</label>
              <input {...register('phone')} placeholder="+91 98765 43210" className={inputCls} />
              {errors.phone && <p className={errCls}>{errors.phone.message}</p>}
            </div>
          </div>

          {/* Password */}
          <div>
            <label className={labelCls}>
              {isEdit ? 'New Password (leave blank to keep)' : 'Password *'}
            </label>
            <div className="relative">
              <input
                {...register('password')}
                type={showPwd ? 'text' : 'password'}
                placeholder={isEdit ? '••••••••' : 'Min 8 chars, upper, lower, number, symbol'}
                className={`${inputCls} pr-10`}
              />
              <button
                type="button"
                onClick={() => setShowPwd(!showPwd)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            {errors.password && <p className={errCls}>{errors.password.message}</p>}
          </div>

          {/* Role + Department */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Role *</label>
              <select {...register('roleId')} className={inputCls}>
                <option value="">Select Role</option>
                {ROLES.map((r) => (
                  <option key={r.id} value={r.id}>{r.roleName}</option>
                ))}
              </select>
              {errors.roleId && <p className={errCls}>{errors.roleId.message}</p>}
            </div>
            <div>
              <label className={labelCls}>Department</label>
              <select {...register('departmentId')} className={inputCls}>
                <option value="">No Department</option>
                {DEPARTMENTS.map((d) => (
                  <option key={d.id} value={d.id}>{d.departmentName}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Status (edit only) */}
          {isEdit && (
            <div>
              <label className={labelCls}>Account Status</label>
              <select {...register('status')} className={inputCls}>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
                <option value="PENDING">Pending</option>
              </select>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-2 border-t border-border">
            <button type="button" onClick={onClose}
              className="px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all">
              Cancel
            </button>
            <button type="submit" disabled={isSubmitting}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-all disabled:opacity-50">
              {isSubmitting ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
              {isEdit ? 'Save Changes' : 'Create User'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ── Confirm Delete Modal ─────────────────────────────────────────────────────
const DeleteModal = ({ user, onClose, onConfirm, loading }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
    <div className="bg-background border border-border rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-4">
      <div className="h-12 w-12 rounded-2xl bg-rose-500/10 flex items-center justify-center mx-auto">
        <Trash2 size={22} className="text-rose-500" />
      </div>
      <div className="text-center">
        <h3 className="font-bold text-lg">Delete User?</h3>
        <p className="text-sm text-muted-foreground mt-1">
          This will soft-delete <span className="font-semibold text-foreground">{user?.name}</span>.
          The account can be restored later.
        </p>
      </div>
      <div className="flex gap-3">
        <button onClick={onClose}
          className="flex-1 px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all">
          Cancel
        </button>
        <button onClick={onConfirm} disabled={loading}
          className="flex-1 px-4 py-2 rounded-xl bg-rose-500 text-white text-sm font-semibold hover:bg-rose-600 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
          {loading ? <RefreshCw size={14} className="animate-spin" /> : <Trash2 size={14} />}
          Delete
        </button>
      </div>
    </div>
  </div>
);

// ── Main Users Page ──────────────────────────────────────────────────────────
export const Users = () => {
  const qc = useQueryClient();
  const { success, error: toastError } = useToast();

  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);   // false | 'create' | user object
  const [deleteTarget, setDeleteTarget] = useState(null);

  // ── Queries ────────────────────────────────────────────────────────────────
  const { data, isLoading } = useQuery({
    queryKey: ['users', page, search],
    queryFn: () => getUsers({ page, limit: 10, search }),
  });

  const users = data?.data || [];
  const total = data?.meta?.total || 0;
  const totalPages = data?.meta?.totalPages || 1;

  // ── Mutations ──────────────────────────────────────────────────────────────
  const invalidate = () => qc.invalidateQueries({ queryKey: ['users'] });

  const createMut = useMutation({
    mutationFn: createUser,
    onSuccess: () => { success('User created successfully!'); setShowModal(false); invalidate(); },
    onError: (e) => toastError(e.response?.data?.message || 'Failed to create user.'),
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }) => updateUser(id, data),
    onSuccess: () => { success('User updated successfully!'); setShowModal(false); invalidate(); },
    onError: (e) => toastError(e.response?.data?.message || 'Failed to update user.'),
  });

  const deleteMut = useMutation({
    mutationFn: deleteUser,
    onSuccess: () => { success('User deleted.'); setDeleteTarget(null); invalidate(); },
    onError: (e) => toastError(e.response?.data?.message || 'Failed to delete user.'),
  });

  const toggleMut = useMutation({
    mutationFn: ({ id, active }) => active ? deactivateUser(id) : activateUser(id),
    onSuccess: (_, { active }) => { success(`User ${active ? 'deactivated' : 'activated'}.`); invalidate(); },
    onError: (e) => toastError(e.response?.data?.message || 'Failed to update status.'),
  });

  // ── Handlers ───────────────────────────────────────────────────────────────
  const handleSave = (formData) => {
    // Strip empty password in edit mode
    const payload = { ...formData };
    if (showModal !== 'create' && !payload.password) delete payload.password;

    if (showModal === 'create') {
      createMut.mutate(payload);
    } else {
      updateMut.mutate({ id: showModal.id, data: payload });
    }
  };

  return (
    <div className="space-y-6">
      {/* Modals */}
      {showModal && (
        <UserModal
          user={showModal === 'create' ? null : showModal}
          onClose={() => setShowModal(false)}
          onSave={handleSave}
        />
      )}
      {deleteTarget && (
        <DeleteModal
          user={deleteTarget}
          onClose={() => setDeleteTarget(null)}
          onConfirm={() => deleteMut.mutate(deleteTarget.id)}
          loading={deleteMut.isPending}
        />
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Users</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Manage institutional staff accounts and system privileges.
            <span className="ml-2 font-semibold text-foreground">{total} total</span>
          </p>
        </div>
        <button
          onClick={() => setShowModal('create')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 hover:scale-[1.01] active:scale-[0.99] transition-all shadow-lg shadow-primary/10 self-start sm:self-auto text-sm"
        >
          <Plus size={18} /> Create User
        </button>
      </div>

      {/* Search */}
      <div className="flex items-center gap-2 bg-secondary/60 rounded-xl px-3 py-2.5 border border-border/60 focus-within:border-primary/50 transition-all max-w-sm">
        <Search size={16} className="text-muted-foreground shrink-0" />
        <input
          type="text"
          placeholder="Search by name, email, employee ID…"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground/60"
        />
      </div>

      {/* Table */}
      <div className="glass-card rounded-2xl overflow-hidden border border-border/50">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/30 text-muted-foreground text-xs font-semibold uppercase tracking-wider">
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4">Email</th>
                <th className="px-6 py-4">Department</th>
                <th className="px-6 py-4">Role</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    {[...Array(6)].map((__, j) => (
                      <td key={j} className="px-6 py-4">
                        <div className="h-4 bg-secondary rounded w-full" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : users.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-16 text-center text-muted-foreground">
                    No users found.
                  </td>
                </tr>
              ) : (
                users.map((usr) => {
                  const roleName = usr.role?.roleName || '—';
                  const isActive = usr.status === 'ACTIVE';
                  return (
                    <tr key={usr.id} className="hover:bg-secondary/20 transition-colors">
                      {/* Name */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="h-9 w-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0">
                            {usr.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-semibold">{usr.name}</p>
                            {usr.employeeId && (
                              <p className="text-xs text-muted-foreground">{usr.employeeId}</p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Email */}
                      <td className="px-6 py-4 text-muted-foreground">
                        <div className="flex items-center gap-1.5">
                          <Mail size={13} className="shrink-0" />
                          {usr.email}
                        </div>
                      </td>

                      {/* Department */}
                      <td className="px-6 py-4 text-muted-foreground">
                        {usr.department?.departmentName || '—'}
                      </td>

                      {/* Role */}
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border ${ROLE_COLORS[roleName] || 'bg-muted text-muted-foreground border-border'}`}>
                          <Shield size={11} /> {roleName}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${
                          isActive
                            ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                        }`}>
                          {usr.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {/* Edit */}
                          <button
                            onClick={() => setShowModal(usr)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
                            title="Edit User"
                          >
                            <Edit size={15} />
                          </button>

                          {/* Toggle Status */}
                          <button
                            onClick={() => toggleMut.mutate({ id: usr.id, active: isActive })}
                            disabled={toggleMut.isPending}
                            className={`p-1.5 rounded-lg transition-all ${
                              isActive
                                ? 'text-amber-500 hover:bg-amber-500/10'
                                : 'text-emerald-500 hover:bg-emerald-500/10'
                            }`}
                            title={isActive ? 'Deactivate' : 'Activate'}
                          >
                            {isActive ? <UserX size={15} /> : <UserCheck size={15} />}
                          </button>

                          {/* Delete */}
                          <button
                            onClick={() => setDeleteTarget(usr)}
                            className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10 transition-all"
                            title="Delete User"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-6 py-4 border-t border-border flex items-center justify-between text-sm">
            <p className="text-muted-foreground">
              Page {page} of {totalPages} · {total} users
            </p>
            <div className="flex gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
                className="px-3 py-1.5 rounded-lg border border-border hover:bg-secondary transition-all disabled:opacity-40 text-xs font-semibold"
              >
                ← Prev
              </button>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
                className="px-3 py-1.5 rounded-lg border border-border hover:bg-secondary transition-all disabled:opacity-40 text-xs font-semibold"
              >
                Next →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Users;

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useAuth } from '../contexts/AuthContext';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, AlertCircle, CheckCircle2 } from 'lucide-react';

const forgotSchema = z.object({
  email: z.string().min(1, 'Email is required').email('Invalid email address'),
});

export const ForgotPassword = () => {
  const { forgotPassword } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [devToken, setDevToken] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(forgotSchema),
    defaultValues: { email: '' },
  });

  const onSubmit = async (data) => {
    setErrorMsg('');
    setSuccessMsg('');
    setDevToken('');
    setIsSubmitting(true);

    try {
      const response = await forgotPassword(data.email);
      if (response.success) {
        setSuccessMsg('A password reset request has been registered.');
        if (response.resetToken) {
          setDevToken(response.resetToken);
        }
      } else {
        // Dev bypass fallback to allow frontend testing when database is unmigrated:
        if (data.email === 'admin@college.com') {
          setSuccessMsg('Dev Bypass: Reset request registered for admin@college.com.');
          setDevToken('demo-reset-token-12345');
        } else {
          setErrorMsg(response.message || 'No account matched this email address.');
        }
      }
    } catch (err) {
      setErrorMsg('Failed to process password reset request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-slate-950 px-4 overflow-hidden">
      {/* Background gradients */}
      <div className="absolute top-1/4 left-1/4 h-[350px] w-[350px] rounded-full bg-violet-600/30 blur-[100px]" />
      
      <div className="w-full max-w-md glass-panel p-8 rounded-2xl shadow-2xl relative z-10 border border-slate-800">
        <div className="flex flex-col items-center gap-2 mb-8">
          <div className="h-12 w-12 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground font-black text-2xl shadow-xl">
            C
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-3">Reset Password</h1>
          <p className="text-sm text-slate-400 text-center">Enter your email to obtain a reset authorization code.</p>
        </div>

        {errorMsg && (
          <div className="mb-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-start gap-3">
            <AlertCircle className="shrink-0 mt-0.5" size={16} />
            <p className="text-red-400/90 text-xs">{errorMsg}</p>
          </div>
        )}

        {successMsg && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-sm space-y-3">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="shrink-0 mt-0.5" size={16} />
              <p className="text-emerald-400 text-xs font-semibold">{successMsg}</p>
            </div>
            {devToken && (
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-2">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Dev Reset Token (testing only)</p>
                <code className="text-xs break-all text-primary select-all font-mono font-bold block bg-slate-950 p-2 rounded border border-slate-900">
                  {devToken}
                </code>
                <Link 
                  to={`/reset-password?token=${devToken}`}
                  className="text-xs text-primary hover:underline font-semibold block pt-1"
                >
                  Proceed to Reset Screen &rarr;
                </Link>
              </div>
            )}
          </div>
        )}

        {!devToken && (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Email Address</label>
              <div className="relative flex items-center bg-slate-900/60 border border-slate-800 rounded-xl focus-within:border-primary/50 transition-all">
                <Mail className="absolute left-3 text-slate-500" size={18} />
                <input
                  type="email"
                  placeholder="admin@college.com"
                  className="w-full bg-transparent text-sm py-3 pl-10 pr-4 outline-none text-slate-100 placeholder:text-slate-600"
                  {...register('email')}
                />
              </div>
              {errors.email && <p className="text-xs text-red-400 font-medium">{errors.email.message}</p>}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center shadow-lg disabled:opacity-50"
            >
              {isSubmitting ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
              ) : (
                'Send Reset Token'
              )}
            </button>
          </form>
        )}

        <div className="mt-8 border-t border-slate-900 pt-4 text-center">
          <Link to="/login" className="inline-flex items-center gap-2 text-xs text-slate-500 hover:text-slate-300 font-medium transition-all">
            <ArrowLeft size={14} /> Back to Login
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;

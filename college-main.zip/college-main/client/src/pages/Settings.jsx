import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { getSystemSettings, updateSystemSettings } from '../services/profileService';
import Breadcrumb from '../components/Breadcrumb';
import PageHeader from '../components/PageHeader';
import { Save, CheckCircle, AlertCircle, ShieldAlert } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

const settingsFormSchema = z.object({
  college_name: z.string().min(3, 'College Name is required'),
  college_email: z.string().email('Invalid email format'),
  asset_prefix: z.string().min(2, 'Asset Prefix must be at least 2 characters'),
  max_upload_size: z.preprocess((val) => parseInt(val, 10), z.number().int().positive()),
  warranty_reminder_days: z.preprocess((val) => parseInt(val, 10), z.number().int().positive()),
  maintenance_reminder_days: z.preprocess((val) => parseInt(val, 10), z.number().int().positive()),
});

export const Settings = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { success, error: toastError } = useToast();
  
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const isAdmin = user?.role === 'ADMIN' || user?.role === 'Super Admin';

  // Queries
  const { data: settings, isLoading } = useQuery({
    queryKey: ['system_settings'],
    queryFn: getSystemSettings,
  });

  // Forms Hook
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(settingsFormSchema),
    values: {
      college_name: settings?.college_name || '',
      college_email: settings?.college_email || '',
      asset_prefix: settings?.asset_prefix || 'AST',
      max_upload_size: settings?.max_upload_size || 5,
      warranty_reminder_days: settings?.warranty_reminder_days || 30,
      maintenance_reminder_days: settings?.maintenance_reminder_days || 7,
    }
  });

  // Mutators
  const updateMutation = useMutation({
    mutationFn: updateSystemSettings,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['system_settings'] });
      setSuccessMsg('System configurations updated successfully.');
      setErrorMsg('');
      success('System configurations updated successfully.');
      setTimeout(() => setSuccessMsg(''), 4000);
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to update configurations.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center space-y-4">
        <ShieldAlert size={48} className="text-rose-500 animate-bounce" />
        <h2 className="text-xl font-bold">Access Unauthorized</h2>
        <p className="text-xs text-muted-foreground max-w-sm">Only Super Administrators have permissions to adjust global system properties.</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'System Settings' }]} />

      <PageHeader 
        title="Global System Settings" 
        description="Override institutional identities, localized prefixes, upload storage limits, and preventive schedules triggers."
      />

      {successMsg && (
        <div className="p-3.5 bg-emerald-500/10 text-emerald-500 text-xs rounded-2xl border border-emerald-500/20 font-bold flex items-center gap-2">
          <CheckCircle size={14} />
          {successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 bg-rose-500/10 text-rose-500 text-xs rounded-2xl border border-rose-500/20 font-bold flex items-center gap-2">
          <AlertCircle size={14} />
          {errorMsg}
        </div>
      )}

      <div className="glass-card p-6 rounded-2xl border border-border/50 max-w-2xl">
        <form onSubmit={handleSubmit((data) => updateMutation.mutate(data))} className="space-y-5 text-xs">
          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground border-b border-border/30 pb-2">College Information</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">College Name</label>
              <input type="text" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...register('college_name')} />
              {errors.college_name && <p className="text-red-400 font-medium">{errors.college_name.message}</p>}
            </div>
            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Support Email Address</label>
              <input type="email" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...register('college_email')} />
              {errors.college_email && <p className="text-red-400 font-medium">{errors.college_email.message}</p>}
            </div>
          </div>

          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground border-b border-border/30 pb-2 pt-4">General Configuration</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1.5 col-span-2">
              <label className="font-semibold text-muted-foreground uppercase">Asset Tag Prefix</label>
              <input type="text" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm font-mono uppercase" {...register('asset_prefix')} />
              {errors.asset_prefix && <p className="text-red-400 font-medium">{errors.asset_prefix.message}</p>}
            </div>
            <div className="space-y-1.5 col-span-2">
              <label className="font-semibold text-muted-foreground uppercase">Max Upload Size (MB)</label>
              <input type="number" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...register('max_upload_size')} />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Warranty Alert Lead Time (Days)</label>
              <input type="number" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...register('warranty_reminder_days')} />
            </div>
            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Maintenance Reminder Lead Time (Days)</label>
              <input type="number" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...register('maintenance_reminder_days')} />
            </div>
          </div>

          <div className="pt-6 border-t border-border/40">
            <button type="submit" disabled={updateMutation.isPending} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all text-xs shadow-lg shadow-primary/10">
              <Save size={14} /> {updateMutation.isPending ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Settings;

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  getAssetsReport, 
  getMaintenanceReport, 
  getFinancialReport, 
  exportReport, 
  triggerDownload,
  saveReportConfig,
  getSavedReportsList
} from '../services/reportService';
import { getCategories, getLocations, getVendors } from '../services/masterService';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import { 
  Printer, Heart, FileSpreadsheet, 
  CheckCircle 
} from 'lucide-react';

export const Reports = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { success, error: toastError } = useToast();
  
  // Navigation & selection
  const [reportType, setReportType] = useState('assets'); // 'assets' | 'maintenance' | 'financial'
  const [saveName, setSaveName] = useState('');
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Filters State
  const [categoryId, setCategoryId] = useState('');
  const [locationId, setLocationId] = useState('');
  const [vendorId, setVendorId] = useState('');
  const [warrantyStatus, setWarrantyStatus] = useState(''); // 'expired' | 'expiring'
  const [costMin, setCostMin] = useState('');
  const [costMax, setCostMax] = useState('');

  // Fetch Lookups
  const { data: categories } = useQuery({ queryKey: ['categories'], queryFn: () => getCategories({ limit: 100 }) });
  const { data: locations } = useQuery({ queryKey: ['locations'], queryFn: () => getLocations({ limit: 100 }) });
  const { data: vendors } = useQuery({ queryKey: ['vendors'], queryFn: () => getVendors({ limit: 100 }) });
  const { data: savedReports } = useQuery({ queryKey: ['saved_reports'], queryFn: getSavedReportsList });

  const activeFilters = {
    categoryId,
    locationId,
    vendorId,
    warrantyStatus,
    costMin,
    costMax
  };

  // Queries
  const { data: assetsData, isLoading: assetsLoading } = useQuery({
    queryKey: ['report_assets', activeFilters],
    queryFn: () => getAssetsReport(activeFilters),
    enabled: reportType === 'assets',
  });

  const { data: maintData, isLoading: maintLoading } = useQuery({
    queryKey: ['report_maint', activeFilters],
    queryFn: () => getMaintenanceReport(activeFilters),
    enabled: reportType === 'maintenance',
  });

  const { data: financialData, isLoading: financialLoading } = useQuery({
    queryKey: ['report_financial', activeFilters],
    queryFn: () => getFinancialReport(activeFilters),
    enabled: reportType === 'financial',
  });

  // Mutators
  const saveMutation = useMutation({
    mutationFn: saveReportConfig,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['saved_reports'] });
      setSuccessMsg('Report configuration saved successfully!');
      setErrorMsg('');
      success('Report configuration saved successfully!');
      setShowSaveModal(false);
      setSaveName('');
      setTimeout(() => setSuccessMsg(''), 4000);
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to save configuration.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const exportMutation = useMutation({
    mutationFn: ({ format }) => exportReport({ format, reportType, filters: activeFilters }),
    onSuccess: (blob, variables) => {
      const ext = variables.format === 'excel' ? 'xlsx' : 'csv';
      triggerDownload(blob, `report_${reportType}_${Date.now()}.${ext}`);
      success(`Report exported successfully as ${variables.format.toUpperCase()}`);
    },
    onError: (err) => {
      toastError(err.response?.data?.message || 'Failed to export report.');
    }
  });

  const handleApplySavedReport = (saved) => {
    const f = saved.filters || {};
    setCategoryId(f.categoryId || '');
    setLocationId(f.locationId || '');
    setVendorId(f.vendorId || '');
    setWarrantyStatus(f.warrantyStatus || '');
    setCostMin(f.costMin || '');
    setCostMax(f.costMax || '');
    setReportType(saved.reportType);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 print:p-0 print:m-0">
      <div className="print:hidden">
        <Breadcrumb items={[{ label: 'Executive Reporting' }]} />
      </div>

      <PageHeader 
        title="Executive Reporting Hub" 
        description="Extract complete logs, track physical assets distributions, compute monthly maintenance expenses, and run straight-line depreciation sheets."
        className="print:hidden"
      >
        <div className="flex gap-2">
          <button
            onClick={() => setShowSaveModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-secondary/80 hover:bg-secondary font-bold text-xs border border-border"
          >
            <Heart size={14} className="text-rose-500" /> Save Filters
          </button>
          <button
            onClick={() => exportMutation.mutate({ format: 'excel' })}
            disabled={exportMutation.isPending}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 text-white font-bold text-xs hover:opacity-90 disabled:opacity-50"
          >
            <FileSpreadsheet size={14} /> Export Excel
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-secondary/80 hover:bg-secondary font-bold text-xs border border-border"
          >
            <Printer size={14} /> Print Report
          </button>
        </div>
      </PageHeader>

      {/* Main filter settings panel */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 print:hidden">
        {/* Saved configurations lists */}
        <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
            <Heart size={12} className="text-rose-500 fill-rose-500" /> Favorite Reports
          </h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {savedReports?.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">No saved configurations.</p>
            ) : (
              savedReports?.map((r) => (
                <button
                  key={r.id}
                  onClick={() => handleApplySavedReport(r)}
                  className="w-full text-left p-2.5 rounded-xl hover:bg-secondary/40 border border-border/40 transition-all text-xs font-semibold block"
                >
                  <span className="font-bold text-foreground block truncate">{r.reportName}</span>
                  <span className="text-[10px] text-muted-foreground uppercase">{r.reportType}</span>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Filter controls panel */}
        <div className="lg:col-span-3 glass-card p-5 rounded-2xl border border-border/50 space-y-4">
          <div className="flex justify-between items-center border-b border-border/30 pb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Dynamic Filter Setup</h3>
            <button
              onClick={() => {
                setCategoryId(''); setLocationId(''); setVendorId('');
                setWarrantyStatus(''); setCostMin(''); setCostMax('');
              }}
              className="text-[10px] uppercase font-bold text-muted-foreground hover:text-foreground"
            >
              Clear Filters
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Report Module</label>
              <select 
                value={reportType} 
                onChange={(e) => setReportType(e.target.value)} 
                className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-sm font-semibold"
              >
                <option value="assets">Assets Inventory</option>
                <option value="maintenance">Maintenance Expense</option>
                <option value="financial">Financial & Depreciation</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Category</label>
              <select 
                value={categoryId} 
                onChange={(e) => setCategoryId(e.target.value)} 
                className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-sm"
              >
                <option value="">All Categories</option>
                {categories?.data?.map((c) => (
                  <option key={c.id} value={c.id}>{c.categoryName}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Location</label>
              <select 
                value={locationId} 
                onChange={(e) => setLocationId(e.target.value)} 
                className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-sm"
              >
                <option value="">All Locations</option>
                {locations?.data?.map((l) => (
                  <option key={l.id} value={l.id}>{l.locationName}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Vendor</label>
              <select 
                value={vendorId} 
                onChange={(e) => setVendorId(e.target.value)} 
                className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-sm"
              >
                <option value="">All Vendors</option>
                {vendors?.data?.map((v) => (
                  <option key={v.id} value={v.id}>{v.vendorName}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-muted-foreground uppercase">Warranty</label>
              <select 
                value={warrantyStatus} 
                onChange={(e) => setWarrantyStatus(e.target.value)} 
                className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-sm"
              >
                <option value="">All Warranties</option>
                <option value="expired">Warranty Expired</option>
                <option value="expiring">Warranty Expiring Soon (30d)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Min Cost</label>
                <input type="number" placeholder="Min" value={costMin} onChange={(e) => setCostMin(e.target.value)} className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-sm" />
              </div>
              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Max Cost</label>
                <input type="number" placeholder="Max" value={costMax} onChange={(e) => setCostMax(e.target.value)} className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {successMsg && (
        <div className="p-3.5 bg-emerald-500/10 text-emerald-500 text-xs rounded-2xl border border-emerald-500/20 font-semibold flex items-center gap-2">
          <CheckCircle size={14} />
          {successMsg}
        </div>
      )}

      {/* =========================================================================
          REPORT OUTPUT VIEWER (Excel/PDF Ready Layout)
          ========================================================================= */}
      <div className="glass-card p-6 rounded-2xl border border-border/50 shadow-sm print:border-none print:shadow-none print:bg-transparent">
        {/* College Print Header Logo/Title */}
        <div className="hidden print:flex items-center justify-between border-b border-foreground/30 pb-4 mb-6">
          <div className="space-y-1">
            <h2 className="text-xl font-black tracking-tight uppercase">College Asset Management Hub</h2>
            <p className="text-[10px] text-muted-foreground font-semibold">ENTERPRISE LIFECYCLE STATS REPORT</p>
          </div>
          <div className="text-right text-xs space-y-0.5">
            <p className="font-bold">Date Generated: {new Date().toLocaleDateString()}</p>
            <p className="text-muted-foreground">Generated By: {user?.name}</p>
          </div>
        </div>

        {/* Assets report */}
        {reportType === 'assets' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Assets Inventory List</h3>
              <p className="text-xs text-muted-foreground font-semibold">Total Row Items: {assetsData?.length || 0}</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-border/80 bg-secondary/20 font-semibold uppercase text-[10px] text-muted-foreground">
                    <th className="p-3">Asset Tag</th>
                    <th className="p-3">Asset Name</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Department</th>
                    <th className="p-3">Location</th>
                    <th className="p-3">Condition</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Cost</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {assetsLoading ? (
                    <tr><td colSpan="8" className="p-4 text-center">Loading Report...</td></tr>
                  ) : assetsData?.length === 0 ? (
                    <tr><td colSpan="8" className="p-4 text-center">No report matching filters.</td></tr>
                  ) : (
                    assetsData?.map((a) => (
                      <tr key={a.id} className="hover:bg-secondary/15">
                        <td className="p-3 font-mono font-bold text-primary">{a.assetTag}</td>
                        <td className="p-3 font-bold">{a.assetName}</td>
                        <td className="p-3">{a.category?.categoryName}</td>
                        <td className="p-3">{a.department?.departmentName || '-'}</td>
                        <td className="p-3">{a.location?.locationName}</td>
                        <td className="p-3">{a.condition?.conditionName}</td>
                        <td className="p-3">{a.status?.statusName}</td>
                        <td className="p-3 text-right font-bold">${a.purchaseCost || '0.00'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Maintenance report */}
        {reportType === 'maintenance' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Maintenance & Repair Expense List</h3>
              <p className="text-xs text-muted-foreground font-semibold">Total Row Items: {maintData?.length || 0}</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-border/80 bg-secondary/20 font-semibold uppercase text-[10px] text-muted-foreground">
                    <th className="p-3">Repair ID</th>
                    <th className="p-3">Asset Tag</th>
                    <th className="p-3">Type</th>
                    <th className="p-3">Technician</th>
                    <th className="p-3">Vendor</th>
                    <th className="p-3 text-right">Downtime (Hrs)</th>
                    <th className="p-3 text-right">Cost</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {maintLoading ? (
                    <tr><td colSpan="7" className="p-4 text-center">Loading Report...</td></tr>
                  ) : maintData?.length === 0 ? (
                    <tr><td colSpan="7" className="p-4 text-center">No report matching filters.</td></tr>
                  ) : (
                    maintData?.map((m) => (
                      <tr key={m.id} className="hover:bg-secondary/15">
                        <td className="p-3 font-mono font-bold text-primary">{m.maintenanceNumber}</td>
                        <td className="p-3">{m.asset?.assetTag}</td>
                        <td className="p-3 font-bold">{m.maintenanceType}</td>
                        <td className="p-3">{m.technicianName || '-'}</td>
                        <td className="p-3">{m.vendor?.vendorName || '-'}</td>
                        <td className="p-3 text-right">{m.downtimeHours?.toFixed(1) || '0.0'}</td>
                        <td className="p-3 text-right font-bold">${m.cost || '0.00'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Financial depreciation report */}
        {reportType === 'financial' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Straight-Line Depreciation Value Sheet</h3>
              <p className="text-xs text-muted-foreground font-semibold">Total Row Items: {financialData?.length || 0}</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-border/80 bg-secondary/20 font-semibold uppercase text-[10px] text-muted-foreground">
                    <th className="p-3">Asset Tag</th>
                    <th className="p-3">Asset Name</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Purchase Date</th>
                    <th className="p-3 text-right">Original Cost</th>
                    <th className="p-3 text-right">Age (Yrs)</th>
                    <th className="p-3 text-right">Accumulated Dep.</th>
                    <th className="p-3 text-right">Current Book Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {financialLoading ? (
                    <tr><td colSpan="8" className="p-4 text-center">Loading Report...</td></tr>
                  ) : financialData?.length === 0 ? (
                    <tr><td colSpan="8" className="p-4 text-center">No report matching filters.</td></tr>
                  ) : (
                    financialData?.map((f) => (
                      <tr key={f.id} className="hover:bg-secondary/15">
                        <td className="p-3 font-mono font-bold text-primary">{f.assetTag}</td>
                        <td className="p-3 font-bold">{f.assetName}</td>
                        <td className="p-3">{f.categoryName}</td>
                        <td className="p-3">{f.purchaseDate ? new Date(f.purchaseDate).toLocaleDateString() : '-'}</td>
                        <td className="p-3 text-right">${f.purchaseCost?.toFixed(2)}</td>
                        <td className="p-3 text-right">{f.ageYears}</td>
                        <td className="p-3 text-right text-rose-500">${f.accumulatedDepreciation?.toFixed(2)}</td>
                        <td className="p-3 text-right font-bold text-emerald-500">${f.currentBookValue?.toFixed(2)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* =========================================================================
          MODAL: Save Configuration
          ========================================================================= */}
      {showSaveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-sm glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative animate-in fade-in duration-200">
            <h2 className="text-base font-bold mb-4">Save Report Configuration</h2>
            {errorMsg && (
              <div className="mb-3 p-2 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-[11px] font-semibold">
                {errorMsg}
              </div>
            )}
            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-muted-foreground uppercase">Configuration Name</label>
                <input 
                  type="text" 
                  placeholder="Monthly Computing Depreciations"
                  value={saveName} 
                  onChange={(e) => setSaveName(e.target.value)}
                  className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 text-sm"
                />
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <button onClick={() => setShowSaveModal(false)} className="px-3.5 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                <button 
                  onClick={() => saveMutation.mutate({ reportName: saveName, reportType, filters: activeFilters })}
                  disabled={!saveName}
                  className="px-3.5 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50"
                >
                  Save Configuration
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Reports;

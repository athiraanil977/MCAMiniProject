import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  getVendors, 
  createVendor, 
  updateVendor, 
  deleteVendor, 
  restoreVendor 
} from '../services/masterService';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import DataTable from '../components/DataTable';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import ConfirmDialog from '../components/ConfirmDialog';
import { Plus, Edit, Trash2, RotateCcw, X, AlertCircle } from 'lucide-react';

const formSchema = z.object({
  vendorCode: z.string()
    .min(3, 'Vendor Code must be at least 3 characters')
    .toUpperCase(),
  vendorName: z.string().min(3, 'Vendor Name must be at least 3 characters'),
  contactPerson: z.string().optional().nullable().or(z.literal('')),
  email: z.string().email('Invalid email format').optional().nullable().or(z.literal('')),
  phone: z.string().regex(/^\+?[0-9\s-]{7,15}$/, 'Invalid phone number').optional().nullable().or(z.literal('')),
  gstNumber: z.string().regex(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/, 'Invalid GST structure').optional().nullable().or(z.literal('')),
  address: z.string().optional().nullable().or(z.literal('')),
  city: z.string().optional().nullable().or(z.literal('')),
  state: z.string().optional().nullable().or(z.literal('')),
  country: z.string().optional().nullable().or(z.literal('')),
  postalCode: z.string().optional().nullable().or(z.literal('')),
  website: z.string().optional().nullable().or(z.literal('')),
  description: z.string().optional().nullable().or(z.literal('')),
  isActive: z.boolean().default(true),
});

export const Vendors = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { success, error: toastError } = useToast();
  const isManager = user?.role === 'ADMIN' || user?.role === 'Super Admin' || user?.role === 'Asset Manager';

  // State controls
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search, setSearch] = useState('');
  const [showDeleted, setShowDeleted] = useState(false);
  const [debouncedSearch, setDebouncedSearch] = useState('');
  
  // Dialogs controls
  const [formOpen, setFormOpen] = useState(false);
  const [editingVendor, setEditingVendor] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [restoreId, setRestoreId] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Handle search debounce
  React.useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 400);
    return () => clearTimeout(handler);
  }, [search]);

  // Query vendors
  const { data, isLoading } = useQuery({
    queryKey: ['vendors', { page, limit, search: debouncedSearch, showDeleted }],
    queryFn: () => getVendors({ page, limit, search: debouncedSearch, showDeleted }),
  });

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: { vendorCode: '', vendorName: '', contactPerson: '', email: '', phone: '', gstNumber: '', address: '', city: '', state: '', country: '', postalCode: '', website: '', description: '', isActive: true },
  });

  // Mutators
  const createMutation = useMutation({
    mutationFn: createVendor,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] });
      setFormOpen(false);
      reset();
      success('Vendor created successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to create vendor.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, payload }) => updateVendor(id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] });
      setFormOpen(false);
      setEditingVendor(null);
      reset();
      success('Vendor updated successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to update vendor.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: deleteVendor,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] });
      setDeleteId(null);
      success('Vendor archived successfully.');
    },
    onError: (err) => {
      toastError(err.response?.data?.message || 'Failed to delete vendor.');
    }
  });

  const restoreMutation = useMutation({
    mutationFn: restoreVendor,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] });
      setRestoreId(null);
      success('Vendor restored successfully.');
    },
    onError: (err) => {
      toastError(err.response?.data?.message || 'Failed to restore vendor.');
    }
  });

  const openAddForm = () => {
    reset();
    setEditingVendor(null);
    setErrorMsg('');
    setFormOpen(true);
  };

  const openEditForm = (vnd) => {
    setErrorMsg('');
    setEditingVendor(vnd);
    setValue('vendorCode', vnd.vendorCode);
    setValue('vendorName', vnd.vendorName);
    setValue('contactPerson', vnd.contactPerson || '');
    setValue('email', vnd.email || '');
    setValue('phone', vnd.phone || '');
    setValue('gstNumber', vnd.gstNumber || '');
    setValue('address', vnd.address || '');
    setValue('city', vnd.city || '');
    setValue('state', vnd.state || '');
    setValue('country', vnd.country || '');
    setValue('postalCode', vnd.postalCode || '');
    setValue('website', vnd.website || '');
    setValue('description', vnd.description || '');
    setValue('isActive', vnd.isActive);
    setFormOpen(true);
  };

  const onFormSubmit = (formData) => {
    setErrorMsg('');
    if (editingVendor) {
      updateMutation.mutate({ id: editingVendor.id, payload: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const columns = [
    { key: 'vendorCode', label: 'Vendor Code', className: 'font-mono font-bold text-primary' },
    { key: 'vendorName', label: 'Vendor Name', className: 'font-semibold' },
    { key: 'contactPerson', label: 'Contact Person' },
    { key: 'email', label: 'Email' },
    { key: 'phone', label: 'Phone' },
    {
      key: 'isActive',
      label: 'Status',
      render: (row) => (
        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${
          row.isActive ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-slate-500/10 text-slate-600 border-slate-500/20'
        }`}>
          {row.isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'actions',
      label: 'Actions',
      align: 'right',
      render: (row) => (
        <div className="flex gap-2 justify-end">
          {isManager && !showDeleted && (
            <>
              <button
                onClick={() => openEditForm(row)}
                className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
                title="Edit"
              >
                <Edit size={16} />
              </button>
              <button
                onClick={() => setDeleteId(row.id)}
                className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-all"
                title="Delete"
              >
                <Trash2 size={16} />
              </button>
            </>
          )}
          {isManager && showDeleted && (
            <button
              onClick={() => setRestoreId(row.id)}
              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-500/10 transition-all"
              title="Restore"
            >
              <RotateCcw size={16} />
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Vendors' }]} />
      
      <PageHeader 
        title={showDeleted ? 'Archived Vendors' : 'Suppliers & Vendors'} 
        description="Manage equipment vendors, service contract partners, and supply chains."
      >
        <button
          onClick={() => setShowDeleted(!showDeleted)}
          className="px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all"
        >
          {showDeleted ? 'Show Active' : 'Show Archived'}
        </button>
        {isManager && !showDeleted && (
          <button
            onClick={openAddForm}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all shadow-lg shadow-primary/10"
          >
            <Plus size={18} />
            Register Vendor
          </button>
        )}
      </PageHeader>

      <DataTable
        columns={columns}
        data={data?.data || []}
        loading={isLoading}
        totalItems={data?.meta?.total || 0}
        page={page}
        limit={limit}
        onPageChange={setPage}
        onSearchChange={setSearch}
        onLimitChange={setLimit}
        searchPlaceholder="Search vendors by code, name, or representative..."
      />

      {/* Form Dialog Modal */}
      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-2xl glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative overflow-y-auto max-h-[90vh] animate-in fade-in duration-200">
            <button
              onClick={() => setFormOpen(false)}
              className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
            >
              <X size={18} />
            </button>

            <h2 className="text-xl font-bold mb-4">
              {editingVendor ? 'Update Vendor' : 'Register Vendor Profile'}
            </h2>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-xs flex items-start gap-2.5">
                <AlertCircle className="shrink-0 mt-0.5" size={14} />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Vendor Code</label>
                  <input
                    type="text"
                    placeholder="VND-DELL"
                    disabled={!!editingVendor}
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 disabled:opacity-50"
                    {...register('vendorCode')}
                  />
                  {errors.vendorCode && <p className="text-xs text-red-400 font-medium">{errors.vendorCode.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Vendor Name</label>
                  <input
                    type="text"
                    placeholder="Dell Technologies Inc"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('vendorName')}
                  />
                  {errors.vendorName && <p className="text-xs text-red-400 font-medium">{errors.vendorName.message}</p>}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Contact Person</label>
                  <input
                    type="text"
                    placeholder="John Doe"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('contactPerson')}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Email Address</label>
                  <input
                    type="text"
                    placeholder="sales@vendor.com"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('email')}
                  />
                  {errors.email && <p className="text-xs text-red-400 font-medium">{errors.email.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+18004563355"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('phone')}
                  />
                  {errors.phone && <p className="text-xs text-red-400 font-medium">{errors.phone.message}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">GSTIN / Tax Number</label>
                  <input
                    type="text"
                    placeholder="22AAAAA0000A1Z1"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 uppercase"
                    {...register('gstNumber')}
                  />
                  {errors.gstNumber && <p className="text-xs text-red-400 font-medium">{errors.gstNumber.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Website URL</label>
                  <input
                    type="text"
                    placeholder="https://vendor.com"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('website')}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Street Address</label>
                <input
                  type="text"
                  placeholder="123 business row, suite 10"
                  className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                  {...register('address')}
                />
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">City</label>
                  <input type="text" placeholder="Austin" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50" {...register('city')} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">State</label>
                  <input type="text" placeholder="Texas" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50" {...register('state')} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Country</label>
                  <input type="text" placeholder="USA" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50" {...register('country')} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Postal Code</label>
                  <input type="text" placeholder="78682" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50" {...register('postalCode')} />
                  {errors.postalCode && <p className="text-xs text-red-400 font-medium">{errors.postalCode.message}</p>}
                </div>
              </div>

              <div className="flex items-center gap-3 py-1">
                <input
                  type="checkbox"
                  id="isActive"
                  className="h-4 w-4 rounded border-border text-primary focus:ring-primary/30"
                  {...register('isActive')}
                />
                <label htmlFor="isActive" className="font-semibold cursor-pointer">Set Vendor as Active</label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                <button
                  type="button"
                  onClick={() => setFormOpen(false)}
                  className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50"
                >
                  {createMutation.isPending || updateMutation.isPending ? 'Saving...' : 'Save Vendor'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={() => deleteMutation.mutate(deleteId)}
        title="Archive Vendor?"
        description="Are you sure you want to soft-delete this vendor? They will be marked as inactive."
        confirmText="Archive"
        isDanger={true}
        loading={deleteMutation.isPending}
      />

      {/* Restore Confirmation */}
      <ConfirmDialog
        open={restoreId !== null}
        onClose={() => setRestoreId(null)}
        onConfirm={() => restoreMutation.mutate(restoreId)}
        title="Restore Vendor?"
        description="This will restore the vendor profile in directories."
        confirmText="Restore"
        loading={restoreMutation.isPending}
      />
    </div>
  );
};

export default Vendors;

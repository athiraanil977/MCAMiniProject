import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { 
  createAsset, 
  updateAsset, 
  getAssetById, 
  uploadAssetFile 
} from '../services/assetService';
import { 
  getCategories, 
  getLocations, 
  getVendors, 
  getManufacturers 
} from '../services/masterService';
import { useToast } from '../contexts/ToastContext';

import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import { ArrowLeft, Save, Upload, FileText } from 'lucide-react';

const formSchema = z.object({
  assetName: z.string().min(3, 'Asset Name must be at least 3 characters'),
  description: z.string().optional().nullable().or(z.literal('')),
  serialNumber: z.string().min(3, 'Serial Number must be at least 3 characters'),
  categoryId: z.preprocess((val) => parseInt(val, 10), z.number().int('Category is required')),
  manufacturerId: z.preprocess((val) => parseInt(val, 10), z.number().int('Manufacturer is required')),
  vendorId: z.preprocess((val) => parseInt(val, 10), z.number().int('Vendor is required')),
  locationId: z.preprocess((val) => parseInt(val, 10), z.number().int('Location is required')),
  purchaseDate: z.string().min(1, 'Purchase Date is required'),
  purchaseCost: z.preprocess((val) => val === '' ? null : parseFloat(val), z.number().nonnegative('Cost cannot be negative').optional().nullable()),
  invoiceNumber: z.string().optional().nullable().or(z.literal('')),
  invoiceFile: z.string().optional().nullable().or(z.literal('')),
  warrantyStart: z.string().optional().nullable().or(z.literal('')),
  warrantyEnd: z.string().optional().nullable().or(z.literal('')),
  model: z.string().optional().nullable().or(z.literal('')),
  brand: z.string().optional().nullable().or(z.literal('')),
  conditionId: z.preprocess((val) => parseInt(val, 10), z.number().int('Condition is required')),
  remarks: z.string().optional().nullable().or(z.literal('')),
  assetImage: z.string().optional().nullable().or(z.literal('')),
});

export const AssetForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = !!id;
  const { success, error: toastError } = useToast();
  const [imageUploading, setImageUploading] = useState(false);
  const [invoiceUploading, setInvoiceUploading] = useState(false);

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      assetName: '', description: '', serialNumber: '', categoryId: '', manufacturerId: '', vendorId: '', locationId: '',
      purchaseDate: '', purchaseCost: '', invoiceNumber: '', invoiceFile: '', warrantyStart: '', warrantyEnd: '',
      model: '', brand: '', conditionId: '', remarks: '', assetImage: '',
    },
  });

  // Query metadata for select boxes
  const { data: categories } = useQuery({ queryKey: ['categories'], queryFn: () => getCategories({ limit: 100 }) });
  const { data: locations } = useQuery({ queryKey: ['locations'], queryFn: () => getLocations({ limit: 100 }) });
  const { data: vendors } = useQuery({ queryKey: ['vendors'], queryFn: () => getVendors({ limit: 100 }) });
  const { data: manufacturers } = useQuery({ queryKey: ['manufacturers'], queryFn: () => getManufacturers({ limit: 100 }) });

  // Mock condition codes (or seeded from conditions database, we can also load statically)
  const conditions = [
    { id: 1, name: 'Excellent' },
    { id: 2, name: 'Good' },
    { id: 3, name: 'Fair' },
    { id: 4, name: 'Damaged' },
    { id: 5, name: 'Needs Repair' },
    { id: 6, name: 'Disposed' },
  ];

  // Fetch asset if in edit mode
  useEffect(() => {
    if (isEdit) {
      const loadAsset = async () => {
        try {
          const data = await getAssetById(parseInt(id, 10));
          reset({
            assetName: data.assetName,
            description: data.description || '',
            serialNumber: data.serialNumber,
            categoryId: data.categoryId,
            manufacturerId: data.manufacturerId,
            vendorId: data.vendorId,
            locationId: data.locationId,
            purchaseDate: data.purchaseDate ? data.purchaseDate.split('T')[0] : '',
            purchaseCost: data.purchaseCost || '',
            invoiceNumber: data.invoiceNumber || '',
            invoiceFile: data.invoiceFile || '',
            warrantyStart: data.warrantyStart ? data.warrantyStart.split('T')[0] : '',
            warrantyEnd: data.warrantyEnd ? data.warrantyEnd.split('T')[0] : '',
            model: data.model || '',
            brand: data.brand || '',
            conditionId: data.conditionId,
            remarks: data.remarks || '',
            assetImage: data.assetImage || '',
          });
        } catch (err) {
          toastError('Failed to load asset details.');
        }
      };
      loadAsset();
    }
  }, [id, isEdit, reset]);

  // Handle files upload
  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImageUploading(true);
    try {
      const res = await uploadAssetFile(file);
      setValue('assetImage', res.filePath);
      success('Image uploaded successfully.');
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to upload image.');
    } finally {
      setImageUploading(false);
    }
  };

  const handleInvoiceUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setInvoiceUploading(true);
    try {
      const res = await uploadAssetFile(file);
      setValue('invoiceFile', res.filePath);
      success('Invoice file uploaded successfully.');
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to upload invoice file.');
    } finally {
      setInvoiceUploading(false);
    }
  };

  const onSubmit = async (formData) => {
    try {
      if (isEdit) {
        await updateAsset(parseInt(id, 10), formData);
        success('Asset updated successfully!');
      } else {
        await createAsset(formData);
        success('Asset registered successfully!');
      }
      setTimeout(() => navigate('/assets'), 1500);
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to save asset. Please try again.');
    }
  };

  const assetImageValue = watch('assetImage');
  const invoiceFileValue = watch('invoiceFile');

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <Breadcrumb items={[{ label: 'Assets', to: '/assets' }, { label: isEdit ? 'Edit Asset' : 'New Asset' }]} />

      <PageHeader
        title={isEdit ? 'Modify Asset Profile' : 'Register New Asset'}
        description={isEdit ? 'Update physical parameters, cost centers, or service records.' : 'Add new items, computers, or devices into the campus registry.'}
      >
        <button
          onClick={() => navigate('/assets')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all"
        >
          <ArrowLeft size={16} /> Back
        </button>
      </PageHeader>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 text-sm">
        {/* Core details */}
        <div className="glass-card p-6 rounded-2xl border border-border/50 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5 md:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Asset Name</label>
            <input
              type="text"
              placeholder="MacBook Pro M3 Max"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('assetName')}
            />
            {errors.assetName && <p className="text-xs text-red-400 font-medium">{errors.assetName.message}</p>}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Serial Number</label>
            <input
              type="text"
              placeholder="C02FG123Q05F"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('serialNumber')}
            />
            {errors.serialNumber && <p className="text-xs text-red-400 font-medium">{errors.serialNumber.message}</p>}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Brand Name</label>
            <input
              type="text"
              placeholder="Apple"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('brand')}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Model / Version</label>
            <input
              type="text"
              placeholder="M3 16-Inch"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('model')}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Condition</label>
            <select
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('conditionId')}
            >
              <option value="">Select Condition</option>
              {conditions.map((cond) => (
                <option key={cond.id} value={cond.id}>
                  {cond.name}
                </option>
              ))}
            </select>
            {errors.conditionId && <p className="text-xs text-red-400 font-medium">{errors.conditionId.message}</p>}
          </div>
        </div>

        {/* References */}
        <div className="glass-card p-6 rounded-2xl border border-border/50 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Asset Category</label>
            <select
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('categoryId')}
            >
              <option value="">Select Category</option>
              {categories?.data?.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.categoryName}
                </option>
              ))}
            </select>
            {errors.categoryId && <p className="text-xs text-red-400 font-medium">{errors.categoryId.message}</p>}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Manufacturer (OEM)</label>
            <select
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('manufacturerId')}
            >
              <option value="">Select Manufacturer</option>
              {manufacturers?.data?.map((mfg) => (
                <option key={mfg.id} value={mfg.id}>
                  {mfg.manufacturerName}
                </option>
              ))}
            </select>
            {errors.manufacturerId && <p className="text-xs text-red-400 font-medium">{errors.manufacturerId.message}</p>}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Vendor Supplier</label>
            <select
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('vendorId')}
            >
              <option value="">Select Vendor</option>
              {vendors?.data?.map((vnd) => (
                <option key={vnd.id} value={vnd.id}>
                  {vnd.vendorName}
                </option>
              ))}
            </select>
            {errors.vendorId && <p className="text-xs text-red-400 font-medium">{errors.vendorId.message}</p>}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Initial Room Location</label>
            <select
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('locationId')}
            >
              <option value="">Select Location</option>
              {locations?.data?.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {loc.locationName}
                </option>
              ))}
            </select>
            {errors.locationId && <p className="text-xs text-red-400 font-medium">{errors.locationId.message}</p>}
          </div>
        </div>

        {/* Finance & Contract */}
        <div className="glass-card p-6 rounded-2xl border border-border/50 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Purchase Date</label>
            <input
              type="date"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('purchaseDate')}
            />
            {errors.purchaseDate && <p className="text-xs text-red-400 font-medium">{errors.purchaseDate.message}</p>}
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Purchase Cost</label>
            <input
              type="number"
              step="0.01"
              placeholder="1299.99"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('purchaseCost')}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Invoice Reference Number</label>
            <input
              type="text"
              placeholder="INV-9908"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('invoiceNumber')}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Warranty Start Date</label>
            <input
              type="date"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('warrantyStart')}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Warranty Expiry Date</label>
            <input
              type="date"
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
              {...register('warrantyEnd')}
            />
          </div>
        </div>

        {/* Uploads and Details */}
        <div className="glass-card p-6 rounded-2xl border border-border/50 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Image Upload */}
          <div className="space-y-3">
            <label className="text-xs font-semibold text-muted-foreground uppercase block">Asset Image</label>
            <div className="relative border-2 border-dashed border-border/80 rounded-2xl p-5 hover:border-primary/50 transition-all flex flex-col items-center justify-center bg-secondary/10">
              {assetImageValue ? (
                <div className="space-y-3 text-center">
                  <img
                    src={assetImageValue}
                    alt="Asset preview"
                    className="max-h-32 rounded-lg object-cover mx-auto border border-border shadow-md"
                  />
                  <button
                    type="button"
                    onClick={() => setValue('assetImage', '')}
                    className="text-xs font-bold text-destructive hover:underline"
                  >
                    Remove Image
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center gap-2 cursor-pointer w-full h-full justify-center py-4">
                  <Upload className="text-muted-foreground" size={24} />
                  <span className="text-xs font-medium text-muted-foreground">
                    {imageUploading ? 'Uploading Image...' : 'Click to Upload Asset Image'}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                    disabled={imageUploading}
                  />
                </label>
              )}
            </div>
          </div>

          {/* Invoice Document Upload */}
          <div className="space-y-3">
            <label className="text-xs font-semibold text-muted-foreground uppercase block">Invoice File (PDF/Image)</label>
            <div className="relative border-2 border-dashed border-border/80 rounded-2xl p-5 hover:border-primary/50 transition-all flex flex-col items-center justify-center bg-secondary/10">
              {invoiceFileValue ? (
                <div className="space-y-3 text-center">
                  <FileText className="text-primary mx-auto" size={32} />
                  <span className="text-xs font-semibold text-foreground block truncate max-w-xs">{invoiceFileValue.split('-').slice(1).join('-')}</span>
                  <button
                    type="button"
                    onClick={() => setValue('invoiceFile', '')}
                    className="text-xs font-bold text-destructive hover:underline"
                  >
                    Remove File
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center gap-2 cursor-pointer w-full h-full justify-center py-4">
                  <Upload className="text-muted-foreground" size={24} />
                  <span className="text-xs font-medium text-muted-foreground">
                    {invoiceUploading ? 'Uploading Document...' : 'Click to Upload Invoice File'}
                  </span>
                  <input
                    type="file"
                    accept="application/pdf, image/*"
                    className="hidden"
                    onChange={handleInvoiceUpload}
                    disabled={invoiceUploading}
                  />
                </label>
              )}
            </div>
          </div>

          <div className="space-y-1.5 md:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Remarks</label>
            <textarea
              rows="3"
              placeholder="Asset specifications, vendor configurations, or remarks..."
              className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 resize-none"
              {...register('remarks')}
            />
          </div>
        </div>

        {/* Submit */}
        <div className="flex gap-4 justify-end">
          <button
            type="button"
            onClick={() => navigate('/assets')}
            className="px-5 py-2.5 rounded-xl border border-border hover:bg-secondary font-semibold"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all shadow-lg shadow-primary/10"
          >
            <Save size={18} />
            {isEdit ? 'Save Changes' : 'Register Asset'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AssetForm;

import React from 'react';
import { Search, Filter, Plus, ChevronDown, SlidersHorizontal, Eye, Edit, Trash2 } from 'lucide-react';

const mockAssets = [
  { tag: 'AST-2026-0001', name: 'MacBook Pro 16" M3', category: 'Laptops', location: 'IT Lab Annex', status: 'IN_USE', assignee: 'Dr. Sarah Connor' },
  { tag: 'AST-2026-0002', name: 'Dell UltraSharp 27" Monitor', category: 'Displays', location: 'Science Block A', status: 'AVAILABLE', assignee: '-' },
  { tag: 'AST-2026-0003', name: 'Epson LCD Projector EX50', category: 'Projectors', location: 'Room 204-B', status: 'UNDER_MAINTENANCE', assignee: 'IT Support' },
  { tag: 'AST-2026-0004', name: 'Nikon Eclipse Microscope', category: 'Lab Equipment', location: 'Chemistry Lab 2', status: 'AVAILABLE', assignee: '-' },
  { tag: 'AST-2026-0005', name: 'iPad Air (10th Gen)', category: 'Tablets', location: 'Main Library', status: 'LOST', assignee: 'Prof. Davis' },
];

export const Assets = () => {
  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Assets</h1>
          <p className="text-muted-foreground mt-1">Audit, assign, and track physical inventories.</p>
        </div>
        
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 hover:scale-[1.01] active:scale-[0.99] transition-all shadow-lg shadow-primary/10 self-start sm:self-auto">
          <Plus size={18} />
          Add Asset
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex items-center gap-2 bg-secondary/40 rounded-xl px-3 py-2 border border-border/60 focus-within:border-primary/50 transition-all w-full md:w-96 shrink-0">
          <Search size={16} className="text-muted-foreground" />
          <input 
            type="text" 
            placeholder="Search assets by tag, name, or assignee..." 
            className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground/60"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto md:justify-end">
          <button className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border text-sm font-medium hover:bg-secondary transition-all">
            <Filter size={14} />
            Categories
            <ChevronDown size={14} />
          </button>
          <button className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border text-sm font-medium hover:bg-secondary transition-all">
            <SlidersHorizontal size={14} />
            Status
            <ChevronDown size={14} />
          </button>
          <button className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border text-sm font-medium hover:bg-secondary transition-all">
            Locations
            <ChevronDown size={14} />
          </button>
        </div>
      </div>

      {/* Assets Table */}
      <div className="glass-card rounded-2xl overflow-hidden border border-border/50">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border bg-secondary/30 text-muted-foreground text-xs font-semibold uppercase tracking-wider">
                <th className="px-6 py-4">Asset Tag</th>
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4">Location</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Current User</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50 text-sm">
              {mockAssets.map((asset) => (
                <tr key={asset.tag} className="hover:bg-secondary/20 transition-colors">
                  <td className="px-6 py-4 font-mono font-semibold text-primary">{asset.tag}</td>
                  <td className="px-6 py-4 font-medium">{asset.name}</td>
                  <td className="px-6 py-4 text-muted-foreground">{asset.category}</td>
                  <td className="px-6 py-4 text-muted-foreground">{asset.location}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                      asset.status === 'AVAILABLE' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' :
                      asset.status === 'IN_USE' ? 'bg-blue-500/10 text-blue-600 border-blue-500/20' :
                      asset.status === 'UNDER_MAINTENANCE' ? 'bg-amber-500/10 text-amber-600 border-amber-500/20' :
                      'bg-rose-500/10 text-rose-600 border-rose-500/20'
                    }`}>
                      {asset.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{asset.assignee}</td>
                  <td className="px-6 py-4 text-right space-x-1">
                    <button className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-all" title="View details">
                      <Eye size={16} />
                    </button>
                    <button className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-all" title="Edit">
                      <Edit size={16} />
                    </button>
                    <button className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-all" title="Delete">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Table Pagination */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between text-sm text-muted-foreground bg-secondary/10">
          <span>Showing 1 to 5 of 1248 entries</span>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 rounded-lg border border-border hover:bg-secondary font-medium transition-all disabled:opacity-50" disabled>Previous</button>
            <button className="px-3 py-1.5 rounded-lg border border-border hover:bg-secondary font-medium transition-all">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Assets;

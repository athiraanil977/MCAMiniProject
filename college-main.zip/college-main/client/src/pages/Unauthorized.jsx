import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Home, ShieldAlert, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export const Unauthorized = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4 relative overflow-hidden text-center">
      {/* Visual Accent */}
      <div className="absolute top-1/3 left-1/3 h-[250px] w-[250px] rounded-full bg-rose-600/10 blur-[80px]" />
      
      <div className="relative z-10 space-y-6 max-w-md">
        <div className="h-16 w-16 rounded-2xl bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto border border-rose-500/20 shadow-lg">
          <ShieldAlert size={32} />
        </div>
        <h1 className="text-4xl font-extrabold text-white tracking-tight">Access Denied</h1>
        <h2 className="text-lg font-bold text-slate-200">Insufficient Privileges</h2>
        <p className="text-sm text-slate-400">
          This operation or view requires elevated permissions (e.g. Administrator role). If you believe this is an error, check with the IT operations department.
        </p>
        
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link 
            to="/dashboard" 
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 hover:scale-[1.01] transition-all shadow-lg"
          >
            <Home size={16} /> Return to Dashboard
          </Link>
          <button
            onClick={handleSignOut}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 text-slate-200 font-semibold hover:bg-slate-700 hover:scale-[1.01] transition-all border border-slate-700"
          >
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default Unauthorized;

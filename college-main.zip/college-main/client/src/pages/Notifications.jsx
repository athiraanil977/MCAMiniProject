import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  getNotifications, 
  markNotificationRead, 
  markAllNotificationsRead, 
  deleteNotification 
} from '../services/notificationService';
import DataTable from '../components/DataTable';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import { Check, CheckSquare, Trash2, AlertCircle, Info, CheckCircle, Flame } from 'lucide-react';

export const Notifications = () => {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);

  // Queries
  const { data: listData, isLoading } = useQuery({
    queryKey: ['notifications_list', page],
    queryFn: () => getNotifications({ page }),
  });

  // Mutators
  const readMutation = useMutation({
    mutationFn: markNotificationRead,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications_list'] });
      queryClient.invalidateQueries({ queryKey: ['unread_count'] });
    }
  });

  const readAllMutation = useMutation({
    mutationFn: markAllNotificationsRead,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications_list'] });
      queryClient.invalidateQueries({ queryKey: ['unread_count'] });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: deleteNotification,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications_list'] });
    }
  });

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Notification Center' }]} />

      <PageHeader 
        title="Notification Center" 
        description="Review audit alarms, hardware leases allocations details, and preventive maintenance alerts."
      >
        <button
          onClick={() => readAllMutation.mutate()}
          disabled={readAllMutation.isPending}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-secondary hover:bg-secondary/80 font-bold text-xs border border-border disabled:opacity-50"
        >
          <CheckSquare size={14} className="text-primary" /> Mark All Read
        </button>
      </PageHeader>

      <div className="glass-card p-4 rounded-2xl border border-border/50 shadow-sm">
        <DataTable
          columns={[
            {
              key: 'type',
              label: 'Alert Type',
              render: (row) => {
                const config = {
                  Success: { color: 'text-emerald-500 bg-emerald-500/10', icon: CheckCircle },
                  Warning: { color: 'text-amber-500 bg-amber-500/10', icon: AlertCircle },
                  Info: { color: 'text-blue-500 bg-blue-500/10', icon: Info },
                  Error: { color: 'text-rose-500 bg-rose-500/10', icon: Flame },
                };
                const spec = config[row.type] || config['Info'];
                const Icon = spec.icon;
                return (
                  <div className="flex items-center gap-2">
                    <div className={`p-2 rounded-lg ${spec.color}`}>
                      <Icon size={14} />
                    </div>
                    <span className="font-bold text-xs uppercase tracking-wider">{row.type}</span>
                  </div>
                );
              }
            },
            { key: 'title', label: 'Subject', className: 'font-bold' },
            { key: 'message', label: 'Notification Message', className: 'text-muted-foreground' },
            {
              key: 'isRead',
              label: 'Read Status',
              render: (row) => (
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                  row.isRead ? 'bg-slate-500/10 text-slate-600 border-slate-500/20' : 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20 animate-pulse'
                }`}>
                  {row.isRead ? 'Read' : 'Unread'}
                </span>
              )
            },
            { key: 'createdAt', label: 'Logged At', render: (row) => new Date(row.createdAt).toLocaleString() },
            {
              key: 'actions',
              label: 'Actions',
              align: 'right',
              render: (row) => (
                <div className="flex gap-1.5 justify-end">
                  {!row.isRead && (
                    <button
                      onClick={() => readMutation.mutate(row.id)}
                      className="p-1.5 rounded bg-indigo-500/15 text-indigo-500 hover:bg-indigo-500/25 transition-all"
                      title="Mark as Read"
                    >
                      <Check size={14} />
                    </button>
                  )}
                  <button
                    onClick={() => deleteMutation.mutate(row.id)}
                    className="p-1.5 rounded bg-rose-500/15 text-rose-500 hover:bg-rose-500/25 transition-all"
                    title="Delete Notification"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )
            }
          ]}
          data={listData?.data || []}
          loading={isLoading}
          totalItems={listData?.meta?.total || 0}
          page={page}
          limit={10}
          onPageChange={setPage}
        />
      </div>
    </div>
  );
};

export default Notifications;

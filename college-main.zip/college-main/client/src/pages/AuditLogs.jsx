import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getAuditLogs } from '../services/auditLogService';
import DataTable from '../components/DataTable';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';


export const AuditLogs = () => {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [moduleFilter, setModuleFilter] = useState('');
  const [actionFilter, setActionFilter] = useState('');

  const activeFilters = {
    page,
    search,
    module: moduleFilter || undefined,
    action: actionFilter || undefined,
  };

  // Queries
  const { data: listData, isLoading } = useQuery({
    queryKey: ['audit_logs_list', activeFilters],
    queryFn: () => getAuditLogs(activeFilters),
  });

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Audit Trail Logs' }]} />

      <PageHeader 
        title="Administrative Audit Logs" 
        description="Inspect physical coordinate edits, database mutations, log-ins, security credentials edits, and export footprints."
      />

      {/* Advanced Module and Action Filters */}
      <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-4 text-xs">
        <h3 className="font-bold text-muted-foreground uppercase tracking-wider text-[11px] border-b border-border/30 pb-2">Filter Log Types</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <label className="font-semibold text-muted-foreground">System Module</label>
            <select
              value={moduleFilter}
              onChange={(e) => { setModuleFilter(e.target.value); setPage(1); }}
              className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-xs"
            >
              <option value="">All Modules</option>
              <option value="Auth">Auth & Logins</option>
              <option value="Assets">Assets Inventory</option>
              <option value="Category">Category Configurations</option>
              <option value="Location">Location Settings</option>
              <option value="Maintenance">Maintenance Service</option>
              <option value="Profile">Profile Coordinates</option>
              <option value="Settings">System Settings</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-muted-foreground">Action Taken</label>
            <select
              value={actionFilter}
              onChange={(e) => { setActionFilter(e.target.value); setPage(1); }}
              className="w-full bg-secondary/40 border border-border rounded-xl px-2.5 py-2 outline-none focus:border-primary/50 text-xs"
            >
              <option value="">All Actions</option>
              <option value="Create">Create / Register</option>
              <option value="Update">Update / Edit</option>
              <option value="Delete">Delete / Soft Delete</option>
              <option value="Login">Logins</option>
              <option value="Logout">Logouts</option>
              <option value="Password Change">Password Changes</option>
              <option value="Settings Change">Settings Modifies</option>
            </select>
          </div>
        </div>
      </div>

      <div className="glass-card p-4 rounded-2xl border border-border/50 shadow-sm">
        <DataTable
          columns={[
            {
              key: 'module',
              label: 'Module',
              render: (row) => (
                <span className="font-bold text-xs bg-secondary/40 px-2 py-0.5 rounded border border-border/30 text-primary">
                  {row.module}
                </span>
              )
            },
            {
              key: 'action',
              label: 'Action',
              render: (row) => {
                const isAuth = row.action === 'Login' || row.action === 'Logout';
                const isDelete = row.action === 'Delete';
                return (
                  <span className={`font-semibold text-xs ${
                    isAuth ? 'text-indigo-400' : isDelete ? 'text-rose-500' : 'text-foreground'
                  }`}>
                    {row.action}
                  </span>
                );
              }
            },
            { key: 'entity', label: 'Entity Schema' },
            { key: 'performedBy', label: 'Operator Name', render: (row) => row.user?.name || 'System / Guest' },
            {
              key: 'origin',
              label: 'IP & Device',
              render: (row) => (
                <div className="flex flex-col text-[11px] gap-0.5 text-muted-foreground">
                  <span className="font-mono text-foreground font-semibold">{row.ipAddress || '127.0.0.1'}</span>
                  <span>{row.operatingSystem || 'Unknown OS'} • {row.browser || 'Browser'}</span>
                </div>
              )
            },
            { key: 'createdAt', label: 'Date Time', render: (row) => new Date(row.createdAt).toLocaleString() },
          ]}
          data={listData?.data || []}
          loading={isLoading}
          totalItems={listData?.meta?.total || 0}
          page={page}
          limit={10}
          onPageChange={setPage}
          onSearchChange={setSearch}
          searchPlaceholder="Search operator name or action..."
        />
      </div>
    </div>
  );
};

export default AuditLogs;

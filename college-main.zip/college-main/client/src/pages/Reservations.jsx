import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { approveReservation, getAssets } from '../services/assetService';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import Breadcrumb from '../components/Breadcrumb';
import {
  Calendar, Check, X, Clock, Package,
  User, Filter, RefreshCw, CheckCircle2,
  XCircle, AlertCircle, ChevronRight, Loader2
} from 'lucide-react';

// ─── Status badge config ──────────────────────────────────────────────────────
const STATUS_STYLE = {
  Pending:   { cls: 'bg-amber-500/20 text-amber-400 border-amber-500/30',   icon: Clock },
  Approved:  { cls: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30', icon: CheckCircle2 },
  Rejected:  { cls: 'bg-red-500/20 text-red-400 border-red-500/30',         icon: XCircle },
  Cancelled: { cls: 'bg-slate-500/20 text-slate-400 border-slate-500/30',   icon: XCircle },
  Completed: { cls: 'bg-blue-500/20 text-blue-400 border-blue-500/30',      icon: CheckCircle2 },
};

const StatusBadge = ({ status }) => {
  const cfg = STATUS_STYLE[status] || STATUS_STYLE.Pending;
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-1 rounded-full border ${cfg.cls}`}>
      <Icon size={11} /> {status}
    </span>
  );
};

// ─── Confirm modal ────────────────────────────────────────────────────────────
const ConfirmModal = ({ open, title, message, onConfirm, onCancel, confirmLabel, confirmCls, loading }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
      <div className="w-full max-w-sm glass-panel rounded-2xl border border-border/60 shadow-2xl p-6 space-y-4">
        <h3 className="font-bold text-base">{title}</h3>
        <p className="text-sm text-muted-foreground">{message}</p>
        <div className="flex gap-3 pt-1">
          <button
            onClick={onCancel}
            className="flex-1 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className={`flex-1 py-2 rounded-xl text-white text-sm font-semibold transition-all flex items-center justify-center gap-2 disabled:opacity-50 ${confirmCls}`}
          >
            {loading ? <Loader2 size={14} className="animate-spin" /> : null}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Main Page ────────────────────────────────────────────────────────────────
export const Reservations = () => {
  const { user } = useAuth();
  const { success, error: toastError } = useToast();
  const qc = useQueryClient();

  const [filterStatus, setFilterStatus] = useState('Pending');
  const [confirm, setConfirm] = useState(null); // { id, action: 'Approved'|'Rejected' }

  // Fetch all assets and collect their reservations
  const { data: assetsData, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['all_reservations', filterStatus],
    queryFn: () => getAssets({ includeReservations: true, limit: 200 }),
    staleTime: 30_000,
  });

  // Flatten reservations from all assets
  const allAssets = assetsData?.data || [];
  const reservations = allAssets
    .flatMap(asset =>
      (asset.reservations || []).map(r => ({ ...r, asset }))
    )
    .filter(r => filterStatus === 'All' || r.status === filterStatus)
    .sort((a, b) => new Date(b.reservationDate) - new Date(a.reservationDate));

  const approveMutation = useMutation({
    mutationFn: ({ id, status }) =>
      approveReservation(id, { status, remarks: `${status} by ${user?.name}` }),
    onSuccess: () => {
      qc.invalidateQueries(['all_reservations']);
      success(`Reservation ${confirm?.action ? confirm.action.toLowerCase() : 'updated'} successfully.`);
      setConfirm(null);
    },
    onError: (err) => toastError(err.response?.data?.message || 'Action failed.'),
  });

  const handleAction = (id, action) => {
    setConfirm({ id, action });
  };

  const counts = {
    Pending:   allAssets.flatMap(a => a.reservations || []).filter(r => r.status === 'Pending').length,
    Approved:  allAssets.flatMap(a => a.reservations || []).filter(r => r.status === 'Approved').length,
    Rejected:  allAssets.flatMap(a => a.reservations || []).filter(r => r.status === 'Rejected').length,
    Completed: allAssets.flatMap(a => a.reservations || []).filter(r => r.status === 'Completed').length,
  };

  const filters = [
    { label: 'Pending',   value: 'Pending',   color: 'text-amber-400',   count: counts.Pending },
    { label: 'Approved',  value: 'Approved',  color: 'text-emerald-400', count: counts.Approved },
    { label: 'Rejected',  value: 'Rejected',  color: 'text-red-400',     count: counts.Rejected },
    { label: 'Completed', value: 'Completed', color: 'text-blue-400',    count: counts.Completed },
    { label: 'All',       value: 'All',       color: 'text-muted-foreground', count: null },
  ];

  const canApprove = ['Super Admin', 'Asset Manager'].includes(user?.role);

  return (
    <div className="space-y-6">
      <ConfirmModal
        open={!!confirm}
        title={confirm?.action === 'Approved' ? '✅ Approve Reservation?' : '❌ Reject Reservation?'}
        message={
          confirm?.action === 'Approved'
            ? 'This will approve the asset reservation request. The student/user will be notified.'
            : 'This will reject the reservation. The asset remains available.'
        }
        confirmLabel={confirm?.action === 'Approved' ? 'Yes, Approve' : 'Yes, Reject'}
        confirmCls={confirm?.action === 'Approved' ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-red-500 hover:bg-red-600'}
        loading={approveMutation.isPending}
        onConfirm={() => approveMutation.mutate({ id: confirm.id, status: confirm.action })}
        onCancel={() => setConfirm(null)}
      />

      <Breadcrumb items={[{ label: 'Reservations' }]} />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">Asset Reservations</h1>
          <p className="text-sm text-muted-foreground">
            Review and approve reservation requests submitted by students and staff.
          </p>
        </div>
        <button
          onClick={() => refetch()}
          disabled={isFetching}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all disabled:opacity-50"
        >
          <RefreshCw size={14} className={isFetching ? 'animate-spin' : ''} />
          Refresh
        </button>
      </div>

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Pending Approval', count: counts.Pending,   icon: Clock,         cls: 'text-amber-500 bg-amber-500/10' },
          { label: 'Approved',         count: counts.Approved,  icon: CheckCircle2,  cls: 'text-emerald-500 bg-emerald-500/10' },
          { label: 'Rejected',         count: counts.Rejected,  icon: XCircle,       cls: 'text-red-500 bg-red-500/10' },
          { label: 'Completed',        count: counts.Completed, icon: Package,        cls: 'text-blue-500 bg-blue-500/10' },
        ].map((card, i) => {
          const Icon = card.icon;
          return (
            <div key={i} className="glass-card rounded-2xl border border-border/50 p-4 flex items-center gap-3 hover:border-primary/30 transition-all">
              <div className={`p-2.5 rounded-xl ${card.cls}`}>
                <Icon size={18} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-medium">{card.label}</p>
                <p className="text-xl font-black">{card.count}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-1.5 flex-wrap">
        <Filter size={14} className="text-muted-foreground mr-1" />
        {filters.map(f => (
          <button
            key={f.value}
            onClick={() => setFilterStatus(f.value)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
              filterStatus === f.value
                ? 'bg-primary/10 border-primary/40 text-primary'
                : 'border-border/50 hover:bg-secondary text-muted-foreground'
            }`}
          >
            {f.label}
            {f.count !== null && (
              <span className={`text-[10px] font-black ${filterStatus === f.value ? 'text-primary' : f.color}`}>
                ({f.count})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Reservations Table */}
      <div className="glass-card rounded-2xl border border-border/50 overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 size={28} className="animate-spin text-primary" />
          </div>
        ) : reservations.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Calendar size={40} className="text-muted-foreground/30" />
            <p className="text-sm font-semibold text-muted-foreground">
              No {filterStatus !== 'All' ? filterStatus.toLowerCase() : ''} reservations found.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border/40">
            {/* Table header */}
            <div className="hidden md:grid grid-cols-[2fr_1.5fr_1.5fr_1fr_1fr_auto] gap-4 px-5 py-3 bg-secondary/30">
              {['Asset', 'Requested By', 'Duration', 'Purpose', 'Status', 'Actions'].map(h => (
                <p key={h} className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{h}</p>
              ))}
            </div>

            {/* Rows */}
            {reservations.map((res) => (
              <div
                key={res.id}
                className="grid grid-cols-1 md:grid-cols-[2fr_1.5fr_1.5fr_1fr_1fr_auto] gap-3 md:gap-4 px-5 py-4 hover:bg-secondary/20 transition-all items-center"
              >
                {/* Asset */}
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-xl bg-indigo-500/10 flex items-center justify-center shrink-0">
                    <Package size={16} className="text-indigo-400" />
                  </div>
                  <div className="min-w-0">
                    <Link
                      to={`/assets/${res.asset.id}`}
                      className="text-sm font-bold hover:text-primary transition-colors truncate block"
                    >
                      {res.asset.assetName}
                    </Link>
                    <p className="text-[11px] text-muted-foreground font-mono">{res.asset.assetTag}</p>
                  </div>
                </div>

                {/* Requested by */}
                <div className="flex items-center gap-2">
                  <div className="h-6 w-6 rounded-full bg-violet-500/20 flex items-center justify-center shrink-0">
                    <User size={11} className="text-violet-400" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold truncate">
                      {res.requestedByUser?.name || res.requestedBy}
                    </p>
                    <p className="text-[10px] text-muted-foreground truncate">
                      {res.requestedByUser?.role?.roleName || '—'}
                    </p>
                  </div>
                </div>

                {/* Duration */}
                <div className="space-y-0.5">
                  <p className="text-xs font-semibold">
                    {new Date(res.reservationStart).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    to {new Date(res.reservationEnd).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </p>
                </div>

                {/* Purpose */}
                <p className="text-xs text-muted-foreground truncate" title={res.purpose || '—'}>
                  {res.purpose || <span className="italic">No purpose stated</span>}
                </p>

                {/* Status */}
                <div>
                  <StatusBadge status={res.status} />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {new Date(res.reservationDate).toLocaleDateString()}
                  </p>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  {canApprove && res.status === 'Pending' ? (
                    <>
                      <button
                        onClick={() => handleAction(res.id, 'Approved')}
                        title="Approve"
                        className="h-8 w-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center hover:bg-emerald-500/20 transition-all"
                      >
                        <Check size={14} className="text-emerald-400" />
                      </button>
                      <button
                        onClick={() => handleAction(res.id, 'Rejected')}
                        title="Reject"
                        className="h-8 w-8 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center hover:bg-red-500/20 transition-all"
                      >
                        <X size={14} className="text-red-400" />
                      </button>
                    </>
                  ) : (
                    <Link
                      to={`/assets/${res.asset.id}`}
                      className="h-8 w-8 rounded-xl bg-secondary border border-border/50 flex items-center justify-center hover:bg-secondary/80 transition-all"
                      title="View Asset"
                    >
                      <ChevronRight size={14} className="text-muted-foreground" />
                    </Link>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {!canApprove && (
        <div className="flex items-center gap-2 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold">
          <AlertCircle size={14} />
          You have view-only access. Only Asset Manager and Super Admin can approve or reject reservations.
        </div>
      )}
    </div>
  );
};

export default Reservations;

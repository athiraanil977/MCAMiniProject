import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getBackups, createBackup, deleteBackup, getBackupDownloadUrl } from '../services/backupService';
import DataTable from '../components/DataTable';
import Breadcrumb from '../components/Breadcrumb';
import PageHeader from '../components/PageHeader';
import { useToast } from '../contexts/ToastContext';
import {
  Database, Download, Trash2, Plus, CheckCircle,
  AlertCircle, Clock, HardDrive
} from 'lucide-react';

const StatusBadge = ({ status }) => {
  const cfg = {
    Success: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    Failed: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
    Running: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${cfg[status] || cfg.Running}`}>
      {status}
    </span>
  );
};

const formatBytes = (bytes) => {
  if (!bytes || bytes === 0n || bytes === 0) return '0 B';
  const n = typeof bytes === 'bigint' ? Number(bytes) : bytes;
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(n) / Math.log(k));
  return `${parseFloat((n / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

export const Backups = () => {
  const queryClient = useQueryClient();
  const { success, error: toastError } = useToast();
  const [page, setPage] = useState(1);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['backups_list', page],
    queryFn: () => getBackups({ page }),
  });

  const createMutation = useMutation({
    mutationFn: createBackup,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['backups_list'] });
      setSuccessMsg('Database backup created successfully.');
      setErrorMsg('');
      success('Database backup created successfully.');
      setTimeout(() => setSuccessMsg(''), 5000);
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Backup failed. Ensure mysqldump is installed and DB credentials are correct.';
      setErrorMsg(msg);
      toastError(msg);
      setTimeout(() => setErrorMsg(''), 8000);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => deleteBackup(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['backups_list'] });
      setDeleteTarget(null);
      setSuccessMsg('Backup deleted successfully.');
      setErrorMsg('');
      success('Backup deleted successfully.');
      setTimeout(() => setSuccessMsg(''), 4000);
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to delete backup.';
      setErrorMsg(msg);
      toastError(msg);
    },
  });

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Backup Management' }]} />

      <PageHeader
        title="Database Backup Management"
        description="Create, download, and manage local database backup archives. Backups are stored as compressed ZIP files."
      >
        <button
          onClick={() => createMutation.mutate()}
          disabled={createMutation.isPending}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-bold text-xs shadow-lg shadow-primary/10 hover:opacity-90 transition-all disabled:opacity-50"
        >
          <Plus size={14} />
          {createMutation.isPending ? 'Creating Backup...' : 'Create Backup'}
        </button>
      </PageHeader>

      {successMsg && (
        <div className="p-3.5 bg-emerald-500/10 text-emerald-500 text-xs rounded-2xl border border-emerald-500/20 font-bold flex items-center gap-2">
          <CheckCircle size={14} /> {successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="p-3.5 bg-rose-500/10 text-rose-500 text-xs rounded-2xl border border-rose-500/20 font-bold flex items-center gap-2">
          <AlertCircle size={14} /> {errorMsg}
        </div>
      )}

      {/* Info panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        {[
          { icon: Database, label: 'Backup Method', value: 'MySQL Dump + ZIP Archive', color: 'text-indigo-400' },
          { icon: HardDrive, label: 'Storage Location', value: './backups (server)', color: 'text-amber-400' },
          { icon: Clock, label: 'Retention Policy', value: '30 Days (Manual cleanup)', color: 'text-emerald-400' },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="glass-card p-4 rounded-2xl border border-border/50 flex items-center gap-3">
            <Icon size={18} className={color} />
            <div>
              <p className="font-semibold text-muted-foreground uppercase text-[10px]">{label}</p>
              <p className="font-bold mt-0.5">{value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Backup history table */}
      <div className="glass-card p-4 rounded-2xl border border-border/50">
        <DataTable
          columns={[
            { key: 'backupName', label: 'Backup Name', className: 'font-bold' },
            { key: 'backupType', label: 'Type' },
            { key: 'fileName', label: 'File Name', className: 'font-mono text-[11px]' },
            { key: 'backupSize', label: 'Size', render: (row) => formatBytes(row.backupSize) },
            { key: 'status', label: 'Status', render: (row) => <StatusBadge status={row.status} /> },
            {
              key: 'createdBy',
              label: 'Created By',
              render: (row) => row.user?.name || 'System',
            },
            { key: 'createdAt', label: 'Date & Time', render: (row) => new Date(row.createdAt).toLocaleString() },
            {
              key: 'actions',
              label: 'Actions',
              align: 'right',
              render: (row) => (
                <div className="flex gap-1.5 justify-end">
                  {row.status === 'Success' && (
                    <a
                      href={`http://localhost:5000${getBackupDownloadUrl(row.id)}`}
                      download
                      className="p-1.5 rounded bg-indigo-500/15 text-indigo-400 hover:bg-indigo-500/25 transition-all"
                      title="Download Backup"
                    >
                      <Download size={14} />
                    </a>
                  )}
                  <button
                    onClick={() => setDeleteTarget(row)}
                    className="p-1.5 rounded bg-rose-500/15 text-rose-500 hover:bg-rose-500/25 transition-all"
                    title="Delete Backup"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ),
            },
          ]}
          data={data?.data || []}
          loading={isLoading}
          totalItems={data?.meta?.total || 0}
          page={page}
          limit={10}
          onPageChange={setPage}
        />
      </div>

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-sm glass-panel p-6 rounded-2xl border border-rose-500/30 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/15 text-rose-500">
                <Trash2 size={18} />
              </div>
              <div>
                <h2 className="text-sm font-black">Delete Backup</h2>
                <p className="text-[11px] text-muted-foreground mt-0.5">This action cannot be undone.</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Are you sure you want to delete backup <span className="font-bold text-foreground">&ldquo;{deleteTarget.backupName}&rdquo;</span>? The physical file will also be removed from disk.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-3.5 py-2 rounded-xl border border-border hover:bg-secondary font-semibold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => deleteMutation.mutate(deleteTarget.id)}
                disabled={deleteMutation.isPending}
                className="px-3.5 py-2 rounded-xl bg-rose-500 text-white font-semibold text-xs hover:opacity-90 transition-all disabled:opacity-50"
              >
                {deleteMutation.isPending ? 'Deleting...' : 'Delete Backup'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Backups;

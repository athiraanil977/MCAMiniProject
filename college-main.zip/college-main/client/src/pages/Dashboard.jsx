import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { getDashboardSummary } from '../services/dashboardService';
import { getAssets, reserveAsset } from '../services/assetService';
import { createRequest, getRequests } from '../services/maintenanceService';
import {
  ResponsiveContainer, PieChart, Pie, Cell,
  BarChart, Bar, XAxis, YAxis, Tooltip, Legend
} from 'recharts';
import {
  Package, CheckCircle, ClipboardCheck, Wrench,
  Ban, Users, Plus,
  TrendingUp, FileText, ArrowRight, UserPlus,
  Search, Bell, ClipboardList,
  RotateCcw, HelpCircle, ChevronRight,
  GraduationCap, Layers, X, AlertCircle, Loader2
} from 'lucide-react';
import Breadcrumb from '../components/Breadcrumb';

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#ec4899', '#06b6d4'];

// ─────────────────────────────────────────────────────────────────────────────
// Inline Modal
// ─────────────────────────────────────────────────────────────────────────────
const Modal = ({ open, onClose, title, children }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
      <div className="w-full max-w-lg glass-panel rounded-2xl border border-border/60 shadow-2xl">
        <div className="flex items-center justify-between p-5 border-b border-border/40">
          <h2 className="font-bold text-base">{title}</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary text-muted-foreground transition-all">
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Reserve Asset Modal
// ─────────────────────────────────────────────────────────────────────────────
const ReserveAssetModal = ({ open, onClose }) => {
  const qc = useQueryClient();
  const { success, error: toastError } = useToast();
  const [form, setForm] = useState({ assetId: '', startDate: '', endDate: '', purpose: '' });
  const [error, setError] = useState('');

  const { data: assetsData } = useQuery({
    queryKey: ['assets_available'],
    queryFn: () => getAssets({ status: 'Available', limit: 100 }),
    enabled: open,
  });
  const assets = assetsData?.data || [];

  const mutation = useMutation({
    mutationFn: reserveAsset,
    onSuccess: () => {
      qc.invalidateQueries(['my_reservations']);
      setForm({ assetId: '', startDate: '', endDate: '', purpose: '' });
      setError('');
      success('Asset lease requested successfully.');
      onClose();
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to reserve asset.';
      setError(msg);
      toastError(msg);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    if (!form.assetId || !form.startDate || !form.endDate || !form.purpose) {
      const msg = 'All fields are required.';
      setError(msg);
      toastError(msg);
      return;
    }
    mutation.mutate({
      assetId:          Number(form.assetId),
      reservationStart: new Date(form.startDate).toISOString(),
      reservationEnd:   new Date(form.endDate).toISOString(),
      purpose:          form.purpose,
    });
  };

  return (
    <Modal open={open} onClose={onClose} title="📦 Request Asset Lease / Reservation">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-red-400 text-xs">
            <AlertCircle size={14} /> {error}
          </div>
        )}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground uppercase">Select Asset</label>
          <select
            value={form.assetId}
            onChange={e => setForm(f => ({ ...f, assetId: e.target.value }))}
            className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all"
          >
            <option value="">-- Choose an available asset --</option>
            {assets.map(a => (
              <option key={a.id} value={a.id}>
                {a.assetTag} — {a.assetName} ({a.category?.categoryName || 'Uncategorized'})
              </option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Start Date</label>
            <input
              type="date"
              value={form.startDate}
              onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))}
              className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">End Date</label>
            <input
              type="date"
              value={form.endDate}
              onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))}
              className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all"
            />
          </div>
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground uppercase">Purpose / Reason</label>
          <textarea
            rows={3}
            placeholder="e.g. Lab project work for semester 5 microprocessor experiment..."
            value={form.purpose}
            onChange={e => setForm(f => ({ ...f, purpose: e.target.value }))}
            className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all resize-none"
          />
        </div>
        <button
          type="submit"
          disabled={mutation.isPending}
          className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {mutation.isPending ? <><Loader2 size={16} className="animate-spin" /> Submitting...</> : 'Submit Reservation Request'}
        </button>
      </form>
    </Modal>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Report Fault Modal
// ─────────────────────────────────────────────────────────────────────────────
const ReportFaultModal = ({ open, onClose }) => {
  const qc = useQueryClient();
  const { success, error: toastError } = useToast();
  const [form, setForm] = useState({ assetId: '', problemTitle: '', problemDescription: '', priority: 'Medium' });
  const [error, setError] = useState('');

  const { data: assetsData } = useQuery({
    queryKey: ['assets_all'],
    queryFn: () => getAssets({ limit: 100 }),
    enabled: open,
  });
  const assets = assetsData?.data || [];

  const mutation = useMutation({
    mutationFn: createRequest,
    onSuccess: () => {
      qc.invalidateQueries(['my_requests']);
      setForm({ assetId: '', problemTitle: '', problemDescription: '', priority: 'Medium' });
      setError('');
      success('Fault report submitted successfully.');
      onClose();
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to submit fault report.';
      setError(msg);
      toastError(msg);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    if (!form.assetId || !form.problemTitle || !form.problemDescription) {
      const msg = 'All fields are required.';
      setError(msg);
      toastError(msg);
      return;
    }
    mutation.mutate({
      assetId:            Number(form.assetId),
      problemTitle:       form.problemTitle,
      problemDescription: form.problemDescription,
      priority:           form.priority,
    });
  };

  return (
    <Modal open={open} onClose={onClose} title="🔧 Report a Fault / Issue">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-red-400 text-xs">
            <AlertCircle size={14} /> {error}
          </div>
        )}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground uppercase">Asset Concerned</label>
          <select
            value={form.assetId}
            onChange={e => setForm(f => ({ ...f, assetId: e.target.value }))}
            className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all"
          >
            <option value="">-- Select the faulty asset --</option>
            {assets.map(a => (
              <option key={a.id} value={a.id}>
                {a.assetTag} — {a.assetName}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground uppercase">Issue Title</label>
          <input
            type="text"
            placeholder="e.g. Screen flickering on laptop CS-LAP-004"
            value={form.problemTitle}
            onChange={e => setForm(f => ({ ...f, problemTitle: e.target.value }))}
            className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground uppercase">Description</label>
          <textarea
            rows={3}
            placeholder="Describe the fault in detail..."
            value={form.problemDescription}
            onChange={e => setForm(f => ({ ...f, problemDescription: e.target.value }))}
            className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all resize-none"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-muted-foreground uppercase">Priority</label>
          <select
            value={form.priority}
            onChange={e => setForm(f => ({ ...f, priority: e.target.value }))}
            className="w-full bg-secondary/50 border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary/60 transition-all"
          >
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
            <option value="Critical">Critical</option>
          </select>
        </div>
        <button
          type="submit"
          disabled={mutation.isPending}
          className="w-full py-2.5 rounded-xl bg-amber-500 text-white font-semibold text-sm hover:bg-amber-600 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {mutation.isPending ? <><Loader2 size={16} className="animate-spin" /> Submitting...</> : 'Submit Fault Report'}
        </button>
      </form>
    </Modal>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Student Portal Dashboard
// ─────────────────────────────────────────────────────────────────────────────
const StudentDashboard = ({ user }) => {
  const [showReserve, setShowReserve] = useState(false);
  const [showFault, setShowFault] = useState(false);

  // Fetch student's maintenance requests (fault reports)
  const { data: requestsData, isLoading: requestsLoading } = useQuery({
    queryKey: ['my_requests'],
    queryFn: () => getRequests({ limit: 5 }),
  });
  const myRequests = requestsData?.data || [];

  // Fetch student's reservations dynamically
  const { data: assetsData, isLoading: reservationsLoading } = useQuery({
    queryKey: ['my_reservations'],
    queryFn: () => getAssets({ includeReservations: true, limit: 200 }),
  });

  const studentReservations = (assetsData?.data || [])
    .flatMap(asset => (asset.reservations || []).map(r => ({ ...r, asset })))
    .filter(r => r.requestedBy === user?.id);

  const pendingRequestsCount = studentReservations.filter(r => r.status === 'Pending').length;
  const activeLoansCount = studentReservations.filter(r => r.status === 'Approved').length;

  const statusColor = {
    Open: 'bg-amber-500/20 text-amber-400',
    'In Progress': 'bg-blue-500/20 text-blue-400',
    Resolved: 'bg-emerald-500/20 text-emerald-400',
    Closed: 'bg-slate-500/20 text-slate-400',
    Pending: 'bg-violet-500/20 text-violet-400',
    Approved: 'bg-emerald-500/20 text-emerald-400',
    Rejected: 'bg-red-500/20 text-red-400',
  };

  const infoCards = [
    { label: 'Browse Assets', value: 'Catalogue', icon: Package, color: 'text-indigo-400', to: '/assets' },
    { label: 'Pending Requests', value: String(pendingRequestsCount), icon: ClipboardCheck, color: 'text-amber-400', to: null },
    { label: 'My Active Loans', value: String(activeLoansCount), icon: Layers, color: 'text-violet-400', to: null },
    { label: 'Department', value: user?.department || '—', icon: GraduationCap, color: 'text-emerald-400', to: null },
  ];

  return (
    <div className="space-y-8">
      <ReserveAssetModal open={showReserve} onClose={() => setShowReserve(false)} />
      <ReportFaultModal open={showFault} onClose={() => setShowFault(false)} />

      <Breadcrumb items={[{ label: 'Student Portal' }]} />

      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden glass-card rounded-2xl border border-border/50 p-6 md:p-8">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 via-violet-500/5 to-transparent pointer-events-none" />
        <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 inline-block mb-2">
              🎓 Student Portal
            </span>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              Welcome back, {user?.name?.split(' ')[0] || 'Student'}!
            </h1>
            <p className="text-sm text-muted-foreground max-w-md">
              Browse available college assets, submit requests, report faults, and manage your profile — all in one place.
            </p>
          </div>
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-xl shadow-indigo-500/30 shrink-0">
            <GraduationCap size={32} className="text-white" />
          </div>
        </div>
      </div>

      {/* Info Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {infoCards.map((card, i) => {
          const Icon = card.icon;
          const inner = (
            <div className="glass-card rounded-2xl border border-border/50 p-4 flex items-center gap-4 hover:border-primary/30 transition-all">
              <div className="p-2.5 rounded-xl bg-secondary/50">
                <Icon size={20} className={card.color} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-medium">{card.label}</p>
                <p className="text-lg font-black tracking-tight">{card.value}</p>
              </div>
            </div>
          );
          return card.to ? <Link key={i} to={card.to}>{inner}</Link> : <div key={i}>{inner}</div>;
        })}
      </div>

      {/* Service Cards — real API actions */}
      <div>
        <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">Available Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Reserve Asset */}
          <div className="glass-card rounded-2xl border border-border/50 p-5 flex gap-4 hover:border-indigo-500/40 transition-all group">
            <div className="p-3 rounded-xl bg-indigo-500/10 h-fit">
              <Package size={22} className="text-indigo-400" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold">Request Asset Lease</h3>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400">Most Used</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Borrow lab equipment, laptops, or other college assets for academic use. Submit your request and await approval.
              </p>
              <button
                onClick={() => setShowReserve(true)}
                className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg text-white bg-indigo-500 hover:bg-indigo-600 transition-all"
              >
                Browse & Request <ChevronRight size={12} />
              </button>
            </div>
          </div>

          {/* Report Fault */}
          <div className="glass-card rounded-2xl border border-border/50 p-5 flex gap-4 hover:border-amber-500/40 transition-all group">
            <div className="p-3 rounded-xl bg-amber-500/10 h-fit">
              <Wrench size={22} className="text-amber-400" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold">Report a Fault</h3>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400">Support</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Report damaged or malfunctioning college equipment. The maintenance team will be notified immediately.
              </p>
              <button
                onClick={() => setShowFault(true)}
                className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg text-white bg-amber-500 hover:bg-amber-600 transition-all"
              >
                Report Issue <ChevronRight size={12} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Dual Activity Lists (Lease Requests & Fault Reports) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Lease/Reservation Requests */}
        <div className="glass-card rounded-2xl border border-border/50 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">My Lease Requests</h2>
            <button
              onClick={() => setShowReserve(true)}
              className="text-xs font-semibold text-primary hover:underline flex items-center gap-1"
            >
              <Plus size={12} /> New Request
            </button>
          </div>
          {reservationsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 size={24} className="animate-spin text-primary" />
            </div>
          ) : studentReservations.length === 0 ? (
            <div className="text-center py-8 space-y-2">
              <ClipboardList size={32} className="mx-auto text-muted-foreground/40" />
              <p className="text-xs text-muted-foreground">No lease requests submitted yet.</p>
              <button onClick={() => setShowReserve(true)} className="text-xs text-primary hover:underline font-semibold">
                Request your first lease →
              </button>
            </div>
          ) : (
            <div className="divide-y divide-border/40">
              {studentReservations.slice(0, 5).map((res) => (
                <div key={res.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="space-y-0.5 flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{res.asset?.assetName}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {new Date(res.reservationStart).toLocaleDateString()} - {new Date(res.reservationEnd).toLocaleDateString()}
                    </p>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full shrink-0 ${statusColor[res.status] || 'bg-muted text-muted-foreground'}`}>
                    {res.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Fault Reports */}
        <div className="glass-card rounded-2xl border border-border/50 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">My Recent Fault Reports</h2>
            <button
              onClick={() => setShowFault(true)}
              className="text-xs font-semibold text-primary hover:underline flex items-center gap-1"
            >
              <Plus size={12} /> New Report
            </button>
          </div>
          {requestsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 size={24} className="animate-spin text-primary" />
            </div>
          ) : myRequests.length === 0 ? (
            <div className="text-center py-8 space-y-2">
              <ClipboardList size={32} className="mx-auto text-muted-foreground/40" />
              <p className="text-xs text-muted-foreground">No fault reports submitted yet.</p>
              <button onClick={() => setShowFault(true)} className="text-xs text-primary hover:underline font-semibold">
                Report your first issue →
              </button>
            </div>
          ) : (
            <div className="divide-y divide-border/40">
              {myRequests.map((req) => (
                <div key={req.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="space-y-0.5 flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{req.title}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {req.asset?.assetName || 'Unknown Asset'} · {new Date(req.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full shrink-0 ${statusColor[req.status] || 'bg-muted text-muted-foreground'}`}>
                    {req.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Notice Board */}
      <div className="glass-card rounded-2xl border border-border/50 p-5 space-y-3">
        <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">📢 Notice Board</h2>
        <div className="space-y-2.5">
          {[
            { text: 'Lab laptops are available for 4-hour borrowing slots. Visit the Computer Science lab counter.', time: 'Today' },
            { text: 'Return all borrowed assets before end of semester (August 30). Late returns attract penalties.', time: '2 days ago' },
            { text: 'New projectors added to the asset catalogue for classroom bookings.', time: '1 week ago' },
          ].map((note, i) => (
            <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-secondary/30 border border-border/40">
              <div className="h-1.5 w-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              <div className="flex-1">
                <p className="text-xs leading-relaxed">{note.text}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{note.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Executive Dashboard (Admin / Staff)
// ─────────────────────────────────────────────────────────────────────────────
const ExecutiveDashboard = () => {
  const { data: summary, isLoading } = useQuery({
    queryKey: ['dashboard_summary'],
    queryFn: () => getDashboardSummary(false),
    refetchInterval: 1000 * 60 * 3,
  });

  const cards = summary?.cards || {};
  const charts = summary?.charts || {};
  const activities = summary?.activities || [];

  const statusPieData = [
    { name: 'Available', value: cards.availableAssets || 0 },
    { name: 'Allocated', value: cards.allocatedAssets || 0 },
    { name: 'Reserved', value: cards.reservedAssets || 0 },
    { name: 'Maintenance', value: cards.maintenanceAssets || 0 },
    { name: 'Disposed', value: cards.disposedAssets || 0 },
    { name: 'Lost', value: cards.lostAssets || 0 },
  ].filter(d => d.value > 0);

  const kpis = [
    { title: 'Total Inventory', count: cards.totalAssets || 0, icon: Package, color: 'text-indigo-500 bg-indigo-500/10' },
    { title: 'Available Assets', count: cards.availableAssets || 0, icon: CheckCircle, color: 'text-emerald-500 bg-emerald-500/10' },
    { title: 'Allocated Out', count: cards.allocatedAssets || 0, icon: ArrowRight, color: 'text-blue-500 bg-blue-500/10' },
    { title: 'In Maintenance', count: cards.maintenanceAssets || 0, icon: Wrench, color: 'text-amber-500 bg-amber-500/10' },
    { title: 'Disposed/Scrapped', count: cards.disposedAssets || 0, icon: Ban, color: 'text-rose-500 bg-rose-500/10' },
    { title: 'Total Investment', count: `$${(cards.totalAssetValue || 0).toLocaleString()}`, icon: TrendingUp, color: 'text-emerald-600 bg-emerald-500/15' },
    { title: 'Active Tickets', count: cards.totalMaintenanceRequests || 0, icon: ClipboardCheck, color: 'text-violet-500 bg-violet-500/10' },
    { title: 'Users Logged', count: cards.totalUsers || 0, icon: Users, color: 'text-cyan-500 bg-cyan-500/10' },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Executive Dashboard' }]} />
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">Executive Dashboard</h1>
          <p className="text-sm text-muted-foreground">Real-time summaries, asset distribution arrays, and maintenance lifecycle KPIs.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div key={idx} className="glass-card p-5 rounded-2xl border border-border/50 hover:border-primary/30 transition-all shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-xs font-semibold text-muted-foreground uppercase">{kpi.title}</p>
                <h3 className="text-2xl font-black tracking-tight">{kpi.count}</h3>
              </div>
              <div className={`p-3 rounded-xl ${kpi.color}`}><Icon size={20} /></div>
            </div>
          );
        })}
      </div>

      <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Quick Console Shortcuts</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Link to="/assets/new" className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/35 border border-border/60 hover:bg-secondary transition-all text-xs font-bold">
            <Plus size={14} className="text-indigo-500" /> Register Asset
          </Link>
          <Link to="/maintenance" className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/35 border border-border/60 hover:bg-secondary transition-all text-xs font-bold">
            <Wrench size={14} className="text-amber-500" /> Maintenance Request
          </Link>
          <Link to="/reports" className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/35 border border-border/60 hover:bg-secondary transition-all text-xs font-bold">
            <FileText size={14} className="text-emerald-500" /> General Reports
          </Link>
          <Link to="/users" className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/35 border border-border/60 hover:bg-secondary transition-all text-xs font-bold">
            <UserPlus size={14} className="text-cyan-500" /> Manage Users
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-4 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Asset Status Distribution</h3>
          <div className="h-64">
            {statusPieData.length === 0 ? (
              <div className="flex items-center justify-center h-full text-xs text-muted-foreground">No asset data logged.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={statusPieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={4}>
                    {statusPieData.map((_, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => [`${v} Assets`, 'Count']} />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-4 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Assets by Category</h3>
          <div className="h-64">
            {!charts.assetsByCategory?.length ? (
              <div className="flex items-center justify-center h-full text-xs text-muted-foreground">No category data.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.assetsByCategory}>
                  <XAxis dataKey="categoryName" stroke="#888888" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#888888" fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={32} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-4 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Assets by Department</h3>
          <div className="h-64">
            {!charts.assetsByDepartment?.length ? (
              <div className="flex items-center justify-center h-full text-xs text-muted-foreground">No department mapping data.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.assetsByDepartment} layout="vertical">
                  <XAxis type="number" stroke="#888888" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis dataKey="departmentName" type="category" stroke="#888888" fontSize={10} tickLine={false} axisLine={false} width={80} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#10b981" radius={[0, 4, 4, 0]} barSize={16} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-4 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Assets by Location</h3>
          <div className="h-64">
            {!charts.assetsByLocation?.length ? (
              <div className="flex items-center justify-center h-full text-xs text-muted-foreground">No location mapped data.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.assetsByLocation}>
                  <XAxis dataKey="locationName" stroke="#888888" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#888888" fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#8b5cf6" radius={[4, 4, 0, 0]} barSize={24} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      <div className="glass-card p-6 rounded-2xl border border-border/50 space-y-5 shadow-sm">
        <div className="flex justify-between items-center pb-2 border-b border-border/30">
          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Recent Audit Activities Log</h3>
        </div>
        <div className="divide-y divide-border/40 text-xs">
          {activities.length === 0 ? (
            <p className="text-xs text-muted-foreground py-2">No audit logs logged in history.</p>
          ) : (
            activities.map((act) => (
              <div key={act.id} className="py-3.5 flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-foreground">{act.action}</span>
                    <span className="font-mono bg-secondary px-1.5 py-0.5 rounded text-[10px] text-primary">{act.asset?.assetTag}</span>
                  </div>
                  <p className="text-muted-foreground">{act.remarks || `${act.action} event logged.`}</p>
                </div>
                <div className="text-right shrink-0 text-muted-foreground font-semibold">
                  {new Date(act.createdAt).toLocaleString()}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Root Dashboard — routes to correct view by role
// ─────────────────────────────────────────────────────────────────────────────
export const Dashboard = () => {
  const { user } = useAuth();
  if (user?.role === 'Student') return <StudentDashboard user={user} />;
  return <ExecutiveDashboard />;
};

export default Dashboard;

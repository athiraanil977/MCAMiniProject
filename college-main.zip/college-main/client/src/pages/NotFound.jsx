import React from 'react';
import { Link } from 'react-router-dom';
import { Home, HelpCircle } from 'lucide-react';

export const NotFound = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4 relative overflow-hidden text-center">
      {/* Visual Accents */}
      <div className="absolute top-1/3 left-1/3 h-[250px] w-[250px] rounded-full bg-violet-600/10 blur-[80px]" />
      
      <div className="relative z-10 space-y-6 max-w-md">
        <div className="h-16 w-16 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center mx-auto border border-destructive/20 shadow-lg">
          <HelpCircle size={32} />
        </div>
        <h1 className="text-7xl font-black text-white tracking-tight">404</h1>
        <h2 className="text-xl font-bold text-slate-200">Page Not Found</h2>
        <p className="text-sm text-slate-400">
          The view, form, or asset record you are trying to access does not exist or has been relocated.
        </p>
        
        <div className="pt-2">
          <Link 
            to="/dashboard" 
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 hover:scale-[1.01] transition-all shadow-lg shadow-primary/20"
          >
            <Home size={16} /> Return to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { getHealth } from '../services/healthService';
import Breadcrumb from '../components/Breadcrumb';
import PageHeader from '../components/PageHeader';
import {
  Database, HardDrive, Cpu, Activity, Clock,
  CheckCircle, AlertCircle, Server, Zap, RefreshCw
} from 'lucide-react';

const StatusBadge = ({ status }) => {
  const isHealthy = status === 'healthy';
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold border ${
      isHealthy
        ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
        : 'bg-amber-500/10 text-amber-500 border-amber-500/20'
    }`}>
      {isHealthy ? <CheckCircle size={10} /> : <AlertCircle size={10} />}
      {isHealthy ? 'Healthy' : 'Degraded'}
    </span>
  );
};

const MetricCard = ({ icon: Icon, label, value, sub, color = 'text-primary' }) => (
  <div className="glass-card p-5 rounded-2xl border border-border/50 flex items-start gap-4">
    <div className={`p-3 rounded-xl bg-secondary/50 ${color} shrink-0`}>
      <Icon size={20} />
    </div>
    <div className="min-w-0">
      <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className="text-lg font-black mt-0.5 truncate">{value ?? '—'}</p>
      {sub && <p className="text-[11px] text-muted-foreground mt-0.5">{sub}</p>}
    </div>
  </div>
);

const formatBytes = (bytes) => {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

export const HealthDashboard = () => {
  const { data, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ['health_summary'],
    queryFn: getHealth,
    refetchInterval: 60000, // Auto-refresh every 60s
  });

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'System Health' }]} />

      <PageHeader
        title="System Health Monitor"
        description="Real-time overview of database connectivity, storage capacity, memory, and server uptime."
      >
        <button
          onClick={() => refetch()}
          disabled={isFetching}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-secondary hover:bg-secondary/80 font-bold text-xs border border-border disabled:opacity-50"
        >
          <RefreshCw size={13} className={isFetching ? 'animate-spin' : ''} /> Refresh
        </button>
      </PageHeader>

      {isLoading && (
        <div className="flex items-center justify-center min-h-[40vh]">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {error && (
        <div className="p-4 bg-rose-500/10 text-rose-500 rounded-2xl border border-rose-500/20 text-sm font-semibold flex items-center gap-2">
          <AlertCircle size={16} /> Failed to load health data. Check if the server is running.
        </div>
      )}

      {data && (
        <div className="space-y-6">
          {/* Overall status banner */}
          <div className={`p-4 rounded-2xl border flex items-center justify-between ${
            data.status === 'healthy'
              ? 'bg-emerald-500/5 border-emerald-500/20'
              : 'bg-amber-500/5 border-amber-500/20'
          }`}>
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl ${data.status === 'healthy' ? 'bg-emerald-500/15 text-emerald-500' : 'bg-amber-500/15 text-amber-500'}`}>
                <Activity size={20} />
              </div>
              <div>
                <p className="font-black text-sm">
                  {data.status === 'healthy' ? 'All Systems Operational' : 'System Degraded – Action Required'}
                </p>
                <p className="text-[11px] text-muted-foreground mt-0.5">
                  Last checked: {new Date(data.timestamp).toLocaleString()} · Environment: {data.environment} · v{data.version}
                </p>
              </div>
            </div>
            <StatusBadge status={data.status} />
          </div>

          {/* Database & Storage */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <Database size={16} className="text-primary" /> Database
                </div>
                <StatusBadge status={data.database?.status} />
              </div>
              <p className="text-xs text-muted-foreground">{data.database?.message}</p>
            </div>

            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <HardDrive size={16} className="text-primary" /> Storage
                </div>
                <StatusBadge status={data.storage?.status} />
              </div>
              {data.storage && (
                <div className="text-xs text-muted-foreground space-y-1">
                  <div className="flex justify-between">
                    <span>Disk Used</span>
                    <span className="font-semibold text-foreground">{formatBytes(data.storage.diskUsed)} / {formatBytes(data.storage.diskTotal)}</span>
                  </div>
                  <div className="w-full bg-secondary/60 rounded-full h-1.5 mt-1">
                    <div
                      className="bg-primary h-1.5 rounded-full transition-all"
                      style={{ width: data.storage.diskUsagePercent || '0%' }}
                    />
                  </div>
                  <div className="flex justify-between mt-1">
                    <span>Upload Files</span>
                    <span className="font-semibold text-foreground">{data.storage.uploadFileCount} files</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* System Metrics */}
          {data.system && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MetricCard
                icon={Clock}
                label="Server Uptime"
                value={data.system.uptimeHuman}
                color="text-emerald-500"
              />
              <MetricCard
                icon={Cpu}
                label="Memory Usage"
                value={data.system.memoryUsagePercent}
                sub={`${formatBytes(data.system.memoryUsed)} used of ${formatBytes(data.system.memoryTotal)}`}
                color="text-indigo-500"
              />
              <MetricCard
                icon={Server}
                label="Node.js Version"
                value={data.system.nodeVersion}
                sub={`${data.system.platform} / ${data.system.arch}`}
                color="text-amber-500"
              />
              <MetricCard
                icon={Zap}
                label="CPU Cores"
                value={`${data.system.cpuCores} Cores`}
                sub={`Load avg: ${(data.system.loadAverage?.[0] || 0).toFixed(2)}`}
                color="text-rose-500"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default HealthDashboard;

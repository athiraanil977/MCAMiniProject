import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { KeyRound, Eye, EyeOff, AlertCircle, CheckCircle2, ArrowLeft } from 'lucide-react';

const passwordSchema = z.string()
  .min(8, 'Password must be at least 8 characters long')
  .regex(/[a-z]/, 'Must contain at least one lowercase letter')
  .regex(/[A-Z]/, 'Must contain at least one uppercase letter')
  .regex(/[0-9]/, 'Must contain at least one number')
  .regex(/[^a-zA-Z0-9]/, 'Must contain at least one special character');

const resetSchema = z.object({
  password: passwordSchema,
  confirmPassword: z.string().min(1, 'Confirm password is required'),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
});

export const ResetPassword = () => {
  const { resetPassword } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const token = searchParams.get('token') || '';

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(resetSchema),
    defaultValues: { password: '', confirmPassword: '' },
  });

  const onSubmit = async (data) => {
    if (!token) {
      setErrorMsg('Reset token is missing. Please request a new link.');
      return;
    }

    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      const response = await resetPassword(token, data.password);
      if (response.success) {
        setSuccessMsg('Your password has been successfully updated.');
        setTimeout(() => {
          navigate('/login');
        }, 2000);
      } else {
        // Dev bypass fallback:
        if (token === 'demo-reset-token-12345' || token === 'mock_reset_token_dev_bypass') {
          setSuccessMsg('Dev Bypass: Password reset successful.');
          setTimeout(() => {
            navigate('/login');
          }, 2000);
        } else {
          setErrorMsg(response.message || 'Token is invalid or expired.');
        }
      }
    } catch (err) {
      setErrorMsg('Failed to process password reset request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-slate-950 px-4 overflow-hidden">
      {/* Background gradients */}
      <div className="absolute bottom-1/4 right-1/4 h-[300px] w-[300px] rounded-full bg-indigo-600/20 blur-[100px]" />

      <div className="w-full max-w-md glass-panel p-8 rounded-2xl shadow-2xl relative z-10 border border-slate-800">
        <div className="flex flex-col items-center gap-2 mb-8">
          <div className="h-12 w-12 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground font-black text-2xl shadow-xl">
            C
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-3">Create New Password</h1>
          <p className="text-sm text-slate-400 text-center">Set your new password below according to security policies.</p>
        </div>

        {!token && (
          <div className="mb-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-start gap-3">
            <AlertCircle className="shrink-0 mt-0.5" size={16} />
            <p className="text-red-400/90 text-xs">Reset token is missing in URL. Please click the reset link from email.</p>
          </div>
        )}

        {errorMsg && (
          <div className="mb-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-start gap-3">
            <AlertCircle className="shrink-0 mt-0.5" size={16} />
            <p className="text-red-400/90 text-xs">{errorMsg}</p>
          </div>
        )}

        {successMsg && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-sm flex items-start gap-3">
            <CheckCircle2 className="shrink-0 mt-0.5" size={16} />
            <p className="text-emerald-400 text-xs font-semibold">{successMsg} Redirecting to login...</p>
          </div>
        )}

        {token && !successMsg && (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            {/* New Password */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">New Password</label>
              <div className="relative flex items-center bg-slate-900/60 border border-slate-800 rounded-xl focus-within:border-primary/50 transition-all">
                <KeyRound className="absolute left-3 text-slate-500" size={18} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  className="w-full bg-transparent text-sm py-3 pl-10 pr-10 outline-none text-slate-100 placeholder:text-slate-600"
                  {...register('password')}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 text-slate-500 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-red-400 font-medium">{errors.password.message}</p>}
            </div>

            {/* Confirm Password */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Confirm Password</label>
              <div className="relative flex items-center bg-slate-900/60 border border-slate-800 rounded-xl focus-within:border-primary/50 transition-all">
                <KeyRound className="absolute left-3 text-slate-500" size={18} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  className="w-full bg-transparent text-sm py-3 pl-10 pr-10 outline-none text-slate-100 placeholder:text-slate-600"
                  {...register('confirmPassword')}
                />
              </div>
              {errors.confirmPassword && <p className="text-xs text-red-400 font-medium">{errors.confirmPassword.message}</p>}
            </div>

            {/* Password Policy Guidelines */}
            <div className="p-3 bg-slate-900/40 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
              <p className="font-bold text-slate-300 uppercase tracking-wide text-[10px]">Password Complexity Rules:</p>
              <ul className="list-disc pl-4 space-y-0.5">
                <li>Minimum of 8 characters</li>
                <li>At least one capital letter (A-Z)</li>
                <li>At least one numbers (0-9)</li>
                <li>At least one special character (@, #, $, etc.)</li>
              </ul>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center shadow-lg disabled:opacity-50"
            >
              {isSubmitting ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
              ) : (
                'Reset Password'
              )}
            </button>
          </form>
        )}

        <div className="mt-8 border-t border-slate-900 pt-4 text-center">
          <Link to="/login" className="inline-flex items-center gap-2 text-xs text-slate-500 hover:text-slate-300 font-medium transition-all">
            <ArrowLeft size={14} /> Back to Login
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  getRequests, createRequest,
  getRecords, startRecord, completeRecord,
  getSchedules, createSchedule,
  getMaintenanceMetrics
} from '../services/maintenanceService';
import { getAssets } from '../services/assetService';
import { getVendors } from '../services/masterService';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import DataTable from '../components/DataTable';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import { 
  Plus, Calendar, ClipboardCheck, 
  Wrench, BarChart3, X, Clock4 
} from 'lucide-react';

// =========================================================================
// Zod Forms Schemas
// =========================================================================

const requestSchema = z.object({
  assetId: z.preprocess((val) => parseInt(val, 10), z.number().int('Asset is required')),
  priority: z.enum(['Low', 'Medium', 'High', 'Critical']),
  problemTitle: z.string().min(3, 'Title must be at least 3 characters'),
  problemDescription: z.string().optional().nullable().or(z.literal('')),
  assignedTechnician: z.preprocess((val) => val === '' ? null : parseInt(val, 10), z.number().int().optional().nullable()),
  remarks: z.string().optional().nullable().or(z.literal('')),
});

const startRecordSchema = z.object({
  assetId: z.preprocess((val) => parseInt(val, 10), z.number().int('Asset is required')),
  requestId: z.preprocess((val) => val === '' ? null : parseInt(val, 10), z.number().int().optional().nullable()),
  maintenanceType: z.enum(['Preventive', 'Corrective', 'Warranty', 'Inspection', 'Upgrade', 'Cleaning', 'Calibration']),
  performedBy: z.enum(['INTERNAL', 'EXTERNAL']),
  vendorId: z.preprocess((val) => val === '' ? null : parseInt(val, 10), z.number().int().optional().nullable()),
  technicianName: z.string().optional().nullable().or(z.literal('')),
  remarks: z.string().optional().nullable().or(z.literal('')),
});

const completeRecordSchema = z.object({
  endDate: z.string().min(1, 'End date is required'),
  labourCost: z.preprocess((val) => val === '' ? 0 : parseFloat(val), z.number().nonnegative()),
  resolution: z.string().min(3, 'Resolution is required'),
  remarks: z.string().optional().nullable().or(z.literal('')),
  parts: z.array(z.object({
    partName: z.string().min(1, 'Part name is required'),
    quantity: z.preprocess((val) => parseInt(val, 10), z.number().int().positive()),
    unitCost: z.preprocess((val) => parseFloat(val), z.number().nonnegative()),
  })).optional(),
});

const scheduleSchema = z.object({
  assetId: z.preprocess((val) => parseInt(val, 10), z.number().int('Asset is required')),
  scheduleName: z.string().min(3, 'Schedule name is required'),
  maintenanceType: z.enum(['Preventive', 'Corrective', 'Warranty', 'Inspection', 'Upgrade', 'Cleaning', 'Calibration']),
  frequency: z.enum(['Weekly', 'Monthly', 'Quarterly', 'Half-Yearly', 'Yearly']),
  assignedTechnician: z.preprocess((val) => val === '' ? null : parseInt(val, 10), z.number().int().optional().nullable()),
  vendorId: z.preprocess((val) => val === '' ? null : parseInt(val, 10), z.number().int().optional().nullable()),
  remarks: z.string().optional().nullable().or(z.literal('')),
});

export const Maintenance = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { success, error: toastError } = useToast();
  const isOperator = user?.role === 'ADMIN' || user?.role === 'Super Admin' || user?.role === 'Asset Manager' || user?.role === 'Store Keeper';

  // Navigation states
  const [activeTab, setActiveTab] = useState('dashboard');
  const [modalType, setModalType] = useState(null); // 'create_request' | 'start_record' | 'complete_record' | 'create_schedule'
  const [selectedRecordId, setSelectedRecordId] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Lists state
  const [reqPage, setReqPage] = useState(1);
  const [recPage, setRecPage] = useState(1);
  const [schPage, setSchPage] = useState(1);
  const [search, setSearch] = useState('');

  // Forms Hook
  const reqForm = useForm({ resolver: zodResolver(requestSchema), defaultValues: { priority: 'Low', problemDescription: '', remarks: '' } });
  const startRecForm = useForm({ resolver: zodResolver(startRecordSchema), defaultValues: { maintenanceType: 'Corrective', performedBy: 'INTERNAL', remarks: '' } });
  const completeRecForm = useForm({ resolver: zodResolver(completeRecordSchema), defaultValues: { labourCost: 0, resolution: '', parts: [] } });
  const schForm = useForm({ resolver: zodResolver(scheduleSchema), defaultValues: { maintenanceType: 'Preventive', frequency: 'Monthly', remarks: '' } });

  const { fields: partFields, append: appendPart, remove: removePart } = useFieldArray({
    control: completeRecForm.control,
    name: 'parts'
  });

  // Queries
  const { data: metrics } = useQuery({ queryKey: ['maint_metrics'], queryFn: getMaintenanceMetrics });
  const { data: requests, isLoading: reqsLoading } = useQuery({ queryKey: ['maint_requests', reqPage, search], queryFn: () => getRequests({ page: reqPage, search }) });
  const { data: records, isLoading: recsLoading } = useQuery({ queryKey: ['maint_records', recPage], queryFn: () => getRecords({ page: recPage }) });
  const { data: schedules, isLoading: schsLoading } = useQuery({ queryKey: ['maint_schedules', schPage], queryFn: () => getSchedules({ page: schPage }) });
  
  // Lookups
  const { data: assets } = useQuery({ queryKey: ['all_assets'], queryFn: () => getAssets({ limit: 100 }) });
  const { data: vendors } = useQuery({ queryKey: ['all_vendors'], queryFn: () => getVendors({ limit: 100 }) });

  // Mutators
  const reqMutation = useMutation({
    mutationFn: createRequest,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maint_requests'] });
      setModalType(null);
      reqForm.reset();
      success('Maintenance request logged successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to create request.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const startRecMutation = useMutation({
    mutationFn: startRecord,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maint_records'] });
      queryClient.invalidateQueries({ queryKey: ['maint_requests'] });
      setModalType(null);
      startRecForm.reset();
      success('Repair initialized successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to initialize record.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const completeRecMutation = useMutation({
    mutationFn: ({ id, payload }) => completeRecord(id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maint_records'] });
      queryClient.invalidateQueries({ queryKey: ['maint_metrics'] });
      setModalType(null);
      completeRecForm.reset();
      success('Repair record completed successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to finalize record.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const schMutation = useMutation({
    mutationFn: createSchedule,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maint_schedules'] });
      setModalType(null);
      schForm.reset();
      success('Maintenance schedule created successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to configure schedule.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const handleOpenComplete = (recordId) => {
    setSelectedRecordId(recordId);
    completeRecForm.reset({ endDate: new Date().toISOString().substring(0, 16), labourCost: 0, resolution: '', parts: [] });
    setModalType('complete_record');
  };

  const handleOpenStartFromRequest = (req) => {
    setErrorMsg('');
    startRecForm.reset({
      assetId: String(req.assetId),
      requestId: String(req.id),
      maintenanceType: 'Corrective',
      performedBy: 'INTERNAL',
      remarks: `Repair initialized from request ${req.requestNumber}: ${req.problemTitle}`,
    });
    setModalType('start_record');
  };


  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Maintenance Console' }]} />

      <PageHeader 
        title="Maintenance & Repairs" 
        description="Oversee preventive schedule calibrations, corrective hardware repair tickets, costs, and technician assignments."
      >
        {isOperator && activeTab === 'requests' && (
          <button
            onClick={() => { setErrorMsg(''); setModalType('create_request'); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all text-xs shadow-lg shadow-primary/10"
          >
            <Plus size={16} /> Log Request
          </button>
        )}
        {isOperator && activeTab === 'records' && (
          <button
            onClick={() => { setErrorMsg(''); setModalType('start_record'); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all text-xs shadow-lg shadow-primary/10"
          >
            <Wrench size={16} /> Start Repair
          </button>
        )}
        {isOperator && activeTab === 'schedules' && (
          <button
            onClick={() => { setErrorMsg(''); setModalType('create_schedule'); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all text-xs shadow-lg shadow-primary/10"
          >
            <Calendar size={16} /> Schedule Task
          </button>
        )}
      </PageHeader>

      {/* Tabs */}
      <div className="flex border-b border-border bg-secondary/15 px-4 rounded-xl overflow-x-auto shrink-0 gap-2 py-1">
        {[
          { id: 'dashboard', label: 'Overview', icon: BarChart3 },
          { id: 'requests', label: 'Service Requests', icon: ClipboardCheck },
          { id: 'records', label: 'Repairs Log', icon: Wrench },
          { id: 'schedules', label: 'Preventive Schedules', icon: Calendar },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all outline-none ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-md shadow-primary/15'
                  : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
              }`}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* =========================================================================
          TAB: Overview Dashboard
          ========================================================================= */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-2 shadow-inner">
              <p className="text-xs font-semibold text-muted-foreground uppercase">Total Tickets</p>
              <h2 className="text-3xl font-extrabold">{metrics?.totalRequests || 0}</h2>
            </div>
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-2 shadow-inner">
              <p className="text-xs font-semibold text-muted-foreground uppercase text-amber-500">Open Tickets</p>
              <h2 className="text-3xl font-extrabold text-amber-500">{metrics?.openRequests || 0}</h2>
            </div>
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-2 shadow-inner">
              <p className="text-xs font-semibold text-muted-foreground uppercase text-indigo-500">In Progress</p>
              <h2 className="text-3xl font-extrabold text-indigo-500">{metrics?.inProgressRequests || 0}</h2>
            </div>
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-2 shadow-inner">
              <p className="text-xs font-semibold text-muted-foreground uppercase text-emerald-500">Completed</p>
              <h2 className="text-3xl font-extrabold text-emerald-500">{metrics?.completedRequests || 0}</h2>
            </div>
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-2 shadow-inner">
              <p className="text-xs font-semibold text-muted-foreground uppercase text-rose-500">Avg Cost</p>
              <h2 className="text-3xl font-extrabold text-rose-500">${metrics?.averageCost?.toFixed(2) || '0.00'}</h2>
            </div>
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-2 shadow-inner">
              <p className="text-xs font-semibold text-muted-foreground uppercase">Downtime</p>
              <h2 className="text-3xl font-extrabold flex items-center gap-1.5">
                <Clock4 size={20} className="text-muted-foreground" />
                {metrics?.totalDowntime?.toFixed(1) || '0'} hrs
              </h2>
            </div>
            <div className="glass-card p-5 rounded-2xl border border-border/50 space-y-2 shadow-inner">
              <p className="text-xs font-semibold text-muted-foreground uppercase text-purple-500">Scheduled PMs</p>
              <h2 className="text-3xl font-extrabold text-purple-500">{metrics?.upcomingMaintenance || 0}</h2>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB: Service Requests
          ========================================================================= */}
      {activeTab === 'requests' && (
        <DataTable
          columns={[
            { key: 'requestNumber', label: 'Ticket ID', className: 'font-mono font-bold text-primary' },
            { key: 'problemTitle', label: 'Problem Title', className: 'font-semibold' },
            { key: 'assetTag', label: 'Asset Tag', render: (row) => row.asset?.assetTag },
            { key: 'assetName', label: 'Asset Name', render: (row) => row.asset?.assetName },
            {
              key: 'priority',
              label: 'Priority',
              render: (row) => {
                const colors = {
                  Low: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
                  Medium: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
                  High: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
                  Critical: 'bg-rose-500/10 text-rose-600 border-rose-500/20 animate-pulse',
                };
                return (
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${colors[row.priority]}`}>
                    {row.priority}
                  </span>
                );
              }
            },
            {
              key: 'status',
              label: 'Status',
              render: (row) => (
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${
                  row.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-amber-500/10 text-amber-600 border-amber-500/20'
                }`}>
                  {row.status}
                </span>
              )
            },
            { key: 'reportedDate', label: 'Date', render: (row) => new Date(row.reportedDate).toLocaleDateString() },
            {
              key: 'actions',
              label: 'Actions',
              align: 'right',
              render: (row) => {
                const linkedRecord = records?.data?.find(r => r.requestId === row.id && r.status === 'In Progress');
                return (
                  <div className="flex gap-2 justify-end">
                    {isOperator && row.status === 'Open' && (
                      <button
                        onClick={() => handleOpenStartFromRequest(row)}
                        className="px-3 py-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-all text-xs font-bold"
                      >
                        Start Repair
                      </button>
                    )}
                    {isOperator && row.status === 'In Progress' && linkedRecord && (
                      <button
                        onClick={() => handleOpenComplete(linkedRecord.id)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-500/15 text-emerald-500 hover:bg-emerald-500/25 transition-all text-xs font-bold"
                      >
                        Complete Repair
                      </button>
                    )}
                  </div>
                );
              }
            }
          ]}
          data={requests?.data || []}
          loading={reqsLoading}
          totalItems={requests?.meta?.total || 0}
          page={reqPage}
          limit={10}
          onPageChange={setReqPage}
          onSearchChange={setSearch}
          searchPlaceholder="Search problem title or tags..."
        />
      )}

      {/* =========================================================================
          TAB: Repairs Log
          ========================================================================= */}
      {activeTab === 'records' && (
        <DataTable
          columns={[
            { key: 'maintenanceNumber', label: 'Repair ID', className: 'font-mono font-bold text-primary' },
            { key: 'assetTag', label: 'Asset Tag', render: (row) => row.asset?.assetTag },
            { key: 'maintenanceType', label: 'Type', className: 'font-semibold' },
            { key: 'technicianName', label: 'Technician' },
            { key: 'cost', label: 'Total Cost', render: (row) => row.cost ? `$${parseFloat(row.cost).toFixed(2)}` : '-' },
            { key: 'startDate', label: 'Start Date', render: (row) => new Date(row.startDate).toLocaleDateString() },
            {
              key: 'status',
              label: 'Status',
              render: (row) => (
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${
                  row.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20'
                }`}>
                  {row.status}
                </span>
              )
            },
            {
              key: 'actions',
              label: 'Actions',
              align: 'right',
              render: (row) => (
                <div className="flex gap-2 justify-end">
                  {isOperator && row.status === 'In Progress' && (
                    <button
                      onClick={() => handleOpenComplete(row.id)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500/15 text-emerald-500 hover:bg-emerald-500/25 transition-all text-xs font-bold"
                    >
                      Complete Repair
                    </button>
                  )}
                </div>
              )
            }
          ]}
          data={records?.data || []}
          loading={recsLoading}
          totalItems={records?.meta?.total || 0}
          page={recPage}
          limit={10}
          onPageChange={setRecPage}
        />
      )}

      {/* =========================================================================
          TAB: Preventive Schedules
          ========================================================================= */}
      {activeTab === 'schedules' && (
        <DataTable
          columns={[
            { key: 'scheduleName', label: 'Schedule Name', className: 'font-semibold' },
            { key: 'assetTag', label: 'Asset Tag', render: (row) => row.asset?.assetTag },
            { key: 'frequency', label: 'Frequency' },
            { key: 'nextMaintenanceDate', label: 'Next Maintenance', render: (row) => new Date(row.nextMaintenanceDate).toLocaleDateString() },
            {
              key: 'isActive',
              label: 'Status',
              render: (row) => (
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${
                  row.isActive ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-slate-500/10 text-slate-600 border-slate-500/20'
                }`}>
                  {row.isActive ? 'Active' : 'Paused'}
                </span>
              )
            }
          ]}
          data={schedules?.data || []}
          loading={schsLoading}
          totalItems={schedules?.meta?.total || 0}
          page={schPage}
          limit={10}
          onPageChange={setSchPage}
        />
      )}

      {/* =========================================================================
          FORM MODAL: Log Request
          ========================================================================= */}
      {modalType === 'create_request' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-lg glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative animate-in fade-in duration-200">
            <button onClick={() => setModalType(null)} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground">
              <X size={18} />
            </button>
            <h2 className="text-xl font-bold mb-4">Log Corrective Maintenance Request</h2>
            {errorMsg && <div className="mb-4 p-3 bg-rose-500/10 text-rose-500 text-xs rounded-xl border border-rose-500/20">{errorMsg}</div>}
            <form onSubmit={reqForm.handleSubmit((data) => reqMutation.mutate(data))} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Target Asset</label>
                <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...reqForm.register('assetId')}>
                  <option value="">Select Asset</option>
                  {assets?.data?.map((ast) => (
                    <option key={ast.id} value={ast.id}>{ast.assetTag} - {ast.assetName}</option>
                  ))}
                </select>
                {reqForm.formState.errors.assetId && <p className="text-red-400 font-medium">{reqForm.formState.errors.assetId.message}</p>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Priority</label>
                  <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...reqForm.register('priority')}>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Problem Title</label>
                  <input type="text" placeholder="Monitor flickering" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...reqForm.register('problemTitle')} />
                  {reqForm.formState.errors.problemTitle && <p className="text-red-400 font-medium">{reqForm.formState.errors.problemTitle.message}</p>}
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Detailed Description</label>
                <textarea rows="3" placeholder="Flickers every 5 seconds..." className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 text-sm resize-none" {...reqForm.register('problemDescription')} />
              </div>
              <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                <button type="submit" disabled={reqMutation.isPending} className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50">Log Request</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          FORM MODAL: Start Repair Record
          ========================================================================= */}
      {modalType === 'start_record' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-lg glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative animate-in fade-in duration-200">
            <button onClick={() => setModalType(null)} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground">
              <X size={18} />
            </button>
            <h2 className="text-xl font-bold mb-4">Initialize Active Service Repair</h2>
            {errorMsg && <div className="mb-4 p-3 bg-rose-500/10 text-rose-500 text-xs rounded-xl border border-rose-500/20">{errorMsg}</div>}
            <form onSubmit={startRecForm.handleSubmit((data) => startRecMutation.mutate(data))} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Target Asset</label>
                <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...startRecForm.register('assetId')}>
                  <option value="">Select Asset</option>
                  {assets?.data?.map((ast) => (
                    <option key={ast.id} value={ast.id}>{ast.assetTag} - {ast.assetName}</option>
                  ))}
                </select>
                {startRecForm.formState.errors.assetId && <p className="text-red-400 font-medium">{startRecForm.formState.errors.assetId.message}</p>}
              </div>

              {/* Hidden or read-only request ID if pre-filled */}
              <input type="hidden" {...startRecForm.register('requestId')} />

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Service Type</label>
                  <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...startRecForm.register('maintenanceType')}>
                    <option value="Corrective">Corrective</option>
                    <option value="Preventive">Preventive</option>
                    <option value="Warranty">Warranty</option>
                    <option value="Inspection">Inspection</option>
                    <option value="Upgrade">Upgrade</option>
                    <option value="Calibration">Calibration</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Performed By</label>
                  <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...startRecForm.register('performedBy')}>
                    <option value="INTERNAL">Internal Technician</option>
                    <option value="EXTERNAL">External Vendor</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Assigned Vendor</label>
                  <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...startRecForm.register('vendorId')}>
                    <option value="">Select Vendor (Optional)</option>
                    {vendors?.data?.map((v) => (
                      <option key={v.id} value={v.id}>{v.vendorName}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Technician Name / Details</label>
                  <input type="text" placeholder="John Tech" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...startRecForm.register('technicianName')} />
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                <button type="submit" disabled={startRecMutation.isPending} className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50">Start Repair</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          FORM MODAL: Complete Maintenance Record
          ========================================================================= */}
      {modalType === 'complete_record' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-xl glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative overflow-y-auto max-h-[90vh] animate-in fade-in duration-200">
            <button onClick={() => setModalType(null)} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground">
              <X size={18} />
            </button>
            <h2 className="text-xl font-bold mb-4">Complete & Close Repair</h2>
            {errorMsg && <div className="mb-4 p-3 bg-rose-500/10 text-rose-500 text-xs rounded-xl border border-rose-500/20">{errorMsg}</div>}
            <form onSubmit={completeRecForm.handleSubmit((data) => completeRecMutation.mutate({ id: selectedRecordId, payload: data }))} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">End Date & Time</label>
                  <input type="datetime-local" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...completeRecForm.register('endDate')} />
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Labour Cost ($)</label>
                  <input type="number" step="0.01" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...completeRecForm.register('labourCost')} />
                </div>
              </div>

              {/* Spare Parts Consumed list */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-border/30 pb-2">
                  <h4 className="font-bold text-xs uppercase tracking-wide">Spare Parts Consumed</h4>
                  <button type="button" onClick={() => appendPart({ partName: '', quantity: 1, unitCost: 0 })} className="px-2.5 py-1.5 rounded-lg border border-border hover:bg-secondary text-[11px] font-bold">Add Part</button>
                </div>
                {partFields.map((field, index) => (
                  <div key={field.id} className="grid grid-cols-12 gap-2 items-center bg-secondary/20 p-2.5 rounded-xl border border-border/40">
                    <div className="col-span-6 space-y-1">
                      <input type="text" placeholder="Part Name" className="w-full bg-background border border-border rounded-lg px-2 py-1.5 outline-none focus:border-primary/50 text-xs" {...completeRecForm.register(`parts.${index}.partName`)} />
                    </div>
                    <div className="col-span-2 space-y-1">
                      <input type="number" placeholder="Qty" className="w-full bg-background border border-border rounded-lg px-2 py-1.5 outline-none focus:border-primary/50 text-xs" {...completeRecForm.register(`parts.${index}.quantity`)} />
                    </div>
                    <div className="col-span-3 space-y-1">
                      <input type="number" step="0.01" placeholder="Cost" className="w-full bg-background border border-border rounded-lg px-2 py-1.5 outline-none focus:border-primary/50 text-xs" {...completeRecForm.register(`parts.${index}.unitCost`)} />
                    </div>
                    <div className="col-span-1 text-center">
                      <button type="button" onClick={() => removePart(index)} className="text-rose-500 hover:text-rose-600 font-bold">X</button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Resolution Description</label>
                <textarea rows="3" placeholder="Replaced faulty capacitor on power inverter supply..." className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 text-sm resize-none" {...completeRecForm.register('resolution')} />
              </div>
              <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                <button type="submit" disabled={completeRecMutation.isPending} className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-semibold hover:bg-emerald-500 transition-all disabled:opacity-50">Complete Service</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          FORM MODAL: Create Schedule
          ========================================================================= */}
      {modalType === 'create_schedule' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-lg glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative animate-in fade-in duration-200">
            <button onClick={() => setModalType(null)} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground">
              <X size={18} />
            </button>
            <h2 className="text-xl font-bold mb-4">Configure Recurring PM Schedule</h2>
            {errorMsg && <div className="mb-4 p-3 bg-rose-500/10 text-rose-500 text-xs rounded-xl border border-rose-500/20">{errorMsg}</div>}
            <form onSubmit={schForm.handleSubmit((data) => schMutation.mutate(data))} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Target Asset</label>
                <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...schForm.register('assetId')}>
                  <option value="">Select Asset</option>
                  {assets?.data?.map((ast) => (
                    <option key={ast.id} value={ast.id}>{ast.assetTag} - {ast.assetName}</option>
                  ))}
                </select>
                {schForm.formState.errors.assetId && <p className="text-red-400 font-medium">{schForm.formState.errors.assetId.message}</p>}
              </div>
              <div className="space-y-1.5">
                <label className="font-semibold text-muted-foreground uppercase">Schedule Task Name</label>
                <input type="text" placeholder="Monthly Fan Cleaning & Calibration" className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...schForm.register('scheduleName')} />
                {schForm.formState.errors.scheduleName && <p className="text-red-400 font-medium">{schForm.formState.errors.scheduleName.message}</p>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Frequency</label>
                  <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...schForm.register('frequency')}>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Quarterly">Quarterly</option>
                    <option value="Half-Yearly">Half-Yearly</option>
                    <option value="Yearly">Yearly</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Maintenance Type</label>
                  <select className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...schForm.register('maintenanceType')}>
                    <option value="Preventive">Preventive</option>
                    <option value="Inspection">Inspection</option>
                    <option value="Upgrade">Upgrade</option>
                    <option value="Cleaning">Cleaning</option>
                    <option value="Calibration">Calibration</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                <button type="submit" disabled={schMutation.isPending} className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50">Create Schedule</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Maintenance;

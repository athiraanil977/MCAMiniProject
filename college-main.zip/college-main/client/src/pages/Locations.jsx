import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  getLocations, 
  createLocation, 
  updateLocation, 
  deleteLocation, 
  restoreLocation 
} from '../services/masterService';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import DataTable from '../components/DataTable';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import ConfirmDialog from '../components/ConfirmDialog';
import { Plus, Edit, Trash2, RotateCcw, X, AlertCircle } from 'lucide-react';

const formSchema = z.object({
  locationCode: z.string()
    .min(3, 'Location Code must be at least 3 characters')
    .toUpperCase(),
  locationName: z.string().min(3, 'Location Name must be at least 3 characters'),
  building: z.string().min(1, 'Building name is required'),
  floor: z.string().optional().nullable().or(z.literal('')),
  roomNumber: z.string().optional().nullable().or(z.literal('')),
  description: z.string().optional().nullable().or(z.literal('')),
  isActive: z.boolean().default(true),
});

export const Locations = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { success, error: toastError } = useToast();
  const isManager = user?.role === 'ADMIN' || user?.role === 'Super Admin' || user?.role === 'Asset Manager';

  // State controls
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search, setSearch] = useState('');
  const [showDeleted, setShowDeleted] = useState(false);
  const [debouncedSearch, setDebouncedSearch] = useState('');
  
  // Dialogs controls
  const [formOpen, setFormOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [restoreId, setRestoreId] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Handle search debounce
  React.useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 400);
    return () => clearTimeout(handler);
  }, [search]);

  // Query locations
  const { data, isLoading } = useQuery({
    queryKey: ['locations', { page, limit, search: debouncedSearch, showDeleted }],
    queryFn: () => getLocations({ page, limit, search: debouncedSearch, showDeleted }),
  });

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: { locationCode: '', locationName: '', building: '', floor: '', roomNumber: '', description: '', isActive: true },
  });

  // Mutators
  const createMutation = useMutation({
    mutationFn: createLocation,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      setFormOpen(false);
      reset();
      success('Location created successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to create location.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, payload }) => updateLocation(id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      setFormOpen(false);
      setEditingLocation(null);
      reset();
      success('Location updated successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to update location.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: deleteLocation,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      setDeleteId(null);
      success('Location archived successfully.');
    },
    onError: (err) => {
      toastError(err.response?.data?.message || 'Failed to delete location.');
    }
  });

  const restoreMutation = useMutation({
    mutationFn: restoreLocation,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      setRestoreId(null);
      success('Location restored successfully.');
    },
    onError: (err) => {
      toastError(err.response?.data?.message || 'Failed to restore location.');
    }
  });

  const openAddForm = () => {
    reset();
    setEditingLocation(null);
    setErrorMsg('');
    setFormOpen(true);
  };

  const openEditForm = (loc) => {
    setErrorMsg('');
    setEditingLocation(loc);
    setValue('locationCode', loc.locationCode);
    setValue('locationName', loc.locationName);
    setValue('building', loc.building);
    setValue('floor', loc.floor || '');
    setValue('roomNumber', loc.roomNumber || '');
    setValue('description', loc.description || '');
    setValue('isActive', loc.isActive);
    setFormOpen(true);
  };

  const onFormSubmit = (formData) => {
    setErrorMsg('');
    if (editingLocation) {
      updateMutation.mutate({ id: editingLocation.id, payload: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const columns = [
    { key: 'locationCode', label: 'Location Code', className: 'font-mono font-bold text-primary' },
    { key: 'locationName', label: 'Name', className: 'font-semibold' },
    { key: 'building', label: 'Building' },
    { key: 'roomNumber', label: 'Room' },
    {
      key: 'isActive',
      label: 'Status',
      render: (row) => (
        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${
          row.isActive ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-slate-500/10 text-slate-600 border-slate-500/20'
        }`}>
          {row.isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'actions',
      label: 'Actions',
      align: 'right',
      render: (row) => (
        <div className="flex gap-2 justify-end">
          {isManager && !showDeleted && (
            <>
              <button
                onClick={() => openEditForm(row)}
                className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
                title="Edit"
              >
                <Edit size={16} />
              </button>
              <button
                onClick={() => setDeleteId(row.id)}
                className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-all"
                title="Delete"
              >
                <Trash2 size={16} />
              </button>
            </>
          )}
          {isManager && showDeleted && (
            <button
              onClick={() => setRestoreId(row.id)}
              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-500/10 transition-all"
              title="Restore"
            >
              <RotateCcw size={16} />
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Locations' }]} />
      
      <PageHeader 
        title={showDeleted ? 'Archived Locations' : 'Campus Locations'} 
        description="Configure classrooms, lab suites, server vaults, and storage warehouse facilities."
      >
        <button
          onClick={() => setShowDeleted(!showDeleted)}
          className="px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all"
        >
          {showDeleted ? 'Show Active' : 'Show Archived'}
        </button>
        {isManager && !showDeleted && (
          <button
            onClick={openAddForm}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all shadow-lg shadow-primary/10"
          >
            <Plus size={18} />
            Create Location
          </button>
        )}
      </PageHeader>

      <DataTable
        columns={columns}
        data={data?.data || []}
        loading={isLoading}
        totalItems={data?.meta?.total || 0}
        page={page}
        limit={limit}
        onPageChange={setPage}
        onSearchChange={setSearch}
        onLimitChange={setLimit}
        searchPlaceholder="Search locations by code, name, or building..."
      />

      {/* Form Dialog Modal */}
      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-lg glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative animate-in fade-in duration-200">
            <button
              onClick={() => setFormOpen(false)}
              className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
            >
              <X size={18} />
            </button>

            <h2 className="text-xl font-bold mb-4">
              {editingLocation ? 'Update Location' : 'Register Location Site'}
            </h2>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-xs flex items-start gap-2.5">
                <AlertCircle className="shrink-0 mt-0.5" size={14} />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Location Code</label>
                  <input
                    type="text"
                    placeholder="LOC-CS-L1"
                    disabled={!!editingLocation}
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 disabled:opacity-50"
                    {...register('locationCode')}
                  />
                  {errors.locationCode && <p className="text-xs text-red-400 font-medium">{errors.locationCode.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Location Name</label>
                  <input
                    type="text"
                    placeholder="IT Lab 1"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('locationName')}
                  />
                  {errors.locationName && <p className="text-xs text-red-400 font-medium">{errors.locationName.message}</p>}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Building</label>
                  <input
                    type="text"
                    placeholder="Admin Block"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('building')}
                  />
                  {errors.building && <p className="text-xs text-red-400 font-medium">{errors.building.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Floor</label>
                  <input
                    type="text"
                    placeholder="1st Floor"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('floor')}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Room Number</label>
                  <input
                    type="text"
                    placeholder="104"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...register('roomNumber')}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Description</label>
                <textarea
                  rows="2"
                  placeholder="Optional details..."
                  className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 resize-none"
                  {...register('description')}
                />
              </div>

              <div className="flex items-center gap-3 py-1">
                <input
                  type="checkbox"
                  id="isActive"
                  className="h-4 w-4 rounded border-border text-primary focus:ring-primary/30"
                  {...register('isActive')}
                />
                <label htmlFor="isActive" className="font-semibold cursor-pointer">Set Location as Active</label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                <button
                  type="button"
                  onClick={() => setFormOpen(false)}
                  className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50"
                >
                  {createMutation.isPending || updateMutation.isPending ? 'Saving...' : 'Save Location'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={() => deleteMutation.mutate(deleteId)}
        title="Archive Location?"
        description="Are you sure you want to soft-delete this location? The site will be archived."
        confirmText="Archive"
        isDanger={true}
        loading={deleteMutation.isPending}
      />

      {/* Restore Confirmation */}
      <ConfirmDialog
        open={restoreId !== null}
        onClose={() => setRestoreId(null)}
        onConfirm={() => restoreMutation.mutate(restoreId)}
        title="Restore Location?"
        description="This will restore the location, allowing it to house inventory units again."
        confirmText="Restore"
        loading={restoreMutation.isPending}
      />
    </div>
  );
};

export default Locations;

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  getAssetById, 
  allocateAsset, 
  returnAsset, 
  transferAsset, 
  reserveAsset, 
  disposeAsset, 
  approveReservation,
  uploadAssetFile,
  uploadAssetDocument
} from '../services/assetService';
import { getLocations, getDepartments } from '../services/masterService';
import { getUsers } from '../services/userService';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import PageHeader from '../components/PageHeader';
import Breadcrumb from '../components/Breadcrumb';
import Timeline from '../components/Timeline';
import QRPreview from '../components/QRPreview';
import BarcodePreview from '../components/BarcodePreview';
import { ArrowLeft, Edit, Calendar, ClipboardCheck, ArrowRightLeft, FileText, Ban, Upload, Check, AlertCircle } from 'lucide-react';

// =========================================================================
// Form schemas
// =========================================================================
const allocateSchema = z.object({
  allocatedToUserId: z.string().optional().nullable().or(z.literal('')),
  allocatedDepartmentId: z.string().optional().nullable().or(z.literal('')),
  expectedReturnDate: z.string().optional().nullable().or(z.literal('')),
  purpose: z.string().optional().nullable().or(z.literal('')),
  remarks: z.string().optional().nullable().or(z.literal('')),
}).refine(data => data.allocatedToUserId || data.allocatedDepartmentId, {
  message: 'Please choose either a user or a department',
  path: ['allocatedToUserId'],
});

const transferSchema = z.object({
  toDepartmentId: z.string().optional().nullable().or(z.literal('')),
  toLocationId: z.preprocess((val) => parseInt(val, 10), z.number().int('Location is required')),
  reason: z.string().optional().nullable().or(z.literal('')),
  remarks: z.string().optional().nullable().or(z.literal('')),
});

const reserveSchema = z.object({
  reservationStart: z.string().min(1, 'Start date is required'),
  reservationEnd: z.string().min(1, 'End date is required'),
  purpose: z.string().optional().nullable().or(z.literal('')),
  remarks: z.string().optional().nullable().or(z.literal('')),
});

const disposeSchema = z.object({
  reason: z.string().min(5, 'Reason must be at least 5 characters'),
  method: z.string().min(3, 'Method is required'),
  remarks: z.string().optional().nullable().or(z.literal('')),
  documentPath: z.string().optional().nullable().or(z.literal('')),
});

export const AssetDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { success, error: toastError } = useToast();
  
  const isOperator = user?.role === 'ADMIN' || user?.role === 'Super Admin' || user?.role === 'Asset Manager' || user?.role === 'Store Keeper';

  // Navigation states
  const [activeTab, setActiveTab] = useState('timeline');
  const [modalType, setModalType] = useState(null); // 'allocate' | 'return' | 'transfer' | 'reserve' | 'dispose' | 'upload'
  const [errorMsg, setErrorMsg] = useState('');
  const [docUploading, setDocUploading] = useState(false);
  const modalOpen = modalType !== null;

  // Fetch asset details
  const { data: asset, isLoading } = useQuery({
    queryKey: ['asset', id],
    queryFn: () => getAssetById(parseInt(id, 10)),
  });

  // Fetch location lookups
  const { data: locations } = useQuery({
    queryKey: ['locations'],
    queryFn: () => getLocations({ limit: 100 }),
  });

  // Fetch user lookups for checkout dropdown
  const { data: usersData } = useQuery({
    queryKey: ['usersListSelect'],
    queryFn: () => getUsers({ limit: 100 }),
  });

  // Fetch department lookups for checkout/transfer dropdown
  const { data: deptsData } = useQuery({
    queryKey: ['departmentsListSelect'],
    queryFn: () => getDepartments(),
  });

  // Action hook forms
  const allocateForm = useForm({ resolver: zodResolver(allocateSchema) });
  const transferForm = useForm({ resolver: zodResolver(transferSchema) });
  const reserveForm = useForm({ resolver: zodResolver(reserveSchema) });
  const disposeForm = useForm({ resolver: zodResolver(disposeSchema) });

  // Mutators
  const actionMutation = useMutation({
    mutationFn: async ({ type, payload }) => {
      switch (type) {
        case 'allocate': {
          // Convert ids
          const allocData = {
            assetId: asset.id,
            allocatedToUserId: payload.allocatedToUserId || null,
            allocatedDepartmentId: payload.allocatedDepartmentId ? parseInt(payload.allocatedDepartmentId, 10) : null,
            expectedReturnDate: payload.expectedReturnDate || null,
            purpose: payload.purpose || null,
            remarks: payload.remarks || null,
          };
          return await allocateAsset(allocData);
        }
        case 'return':
          return await returnAsset({ assetId: asset.id, remarks: payload.remarks });
        case 'transfer':
          return await transferAsset({
            assetId: asset.id,
            toDepartmentId: payload.toDepartmentId ? parseInt(payload.toDepartmentId, 10) : null,
            toLocationId: payload.toLocationId,
            reason: payload.reason || null,
            remarks: payload.remarks || null,
          });
        case 'reserve':
          return await reserveAsset({
            assetId: asset.id,
            reservationStart: payload.reservationStart,
            reservationEnd: payload.reservationEnd,
            purpose: payload.purpose || null,
            remarks: payload.remarks || null,
          });
        case 'dispose':
          return await disposeAsset({
            assetId: asset.id,
            reason: payload.reason,
            method: payload.method,
            remarks: payload.remarks || null,
            documentPath: payload.documentPath || null,
          });
        default:
          throw new Error('Invalid type');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['asset', id] });
      setModalType(null);
      setErrorMsg('');
      allocateForm.reset();
      transferForm.reset();
      reserveForm.reset();
      disposeForm.reset();
      success('Action completed successfully.');
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Action execution failed.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  // Handle document upload
  const handleDocUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setDocUploading(true);
    setErrorMsg('');
    try {
      const uploadRes = await uploadAssetFile(file);
      await uploadAssetDocument({
        assetId: asset.id,
        documentType: file.type.includes('pdf') ? 'Invoice/Contract' : 'Manual',
        fileName: uploadRes.fileName,
        filePath: uploadRes.filePath,
      });
      queryClient.invalidateQueries({ queryKey: ['asset', id] });
      success('Document uploaded successfully.');
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to upload document.';
      setErrorMsg(msg);
      toastError(msg);
    } finally {
      setDocUploading(false);
    }
  };

  const handleApproveReservation = async (reservationId, status) => {
    try {
      await approveReservation(reservationId, { status, remarks: 'Processed by Administrator' });
      queryClient.invalidateQueries({ queryKey: ['asset', id] });
      success(`Reservation ${status.toLowerCase()} successfully.`);
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to update reservation state.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        <p className="text-sm text-muted-foreground font-semibold">Loading Asset Details Hub...</p>
      </div>
    );
  }

  if (!asset) {
    return (
      <div className="p-12 text-center text-muted-foreground font-bold">
        Asset not found.
      </div>
    );
  }

  const isDisposed = asset.status?.statusName === 'Disposed';
  const isAllocated = asset.status?.statusName === 'Allocated';

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'Assets', to: '/assets' }, { label: asset.assetTag }]} />

      <PageHeader
        title={`${asset.assetName}`}
        description={`Tag: ${asset.assetTag} | Serial: ${asset.serialNumber}`}
      >
        <button
          onClick={() => navigate('/assets')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-border text-sm font-semibold hover:bg-secondary transition-all"
        >
          <ArrowLeft size={16} /> Back
        </button>
        {isOperator && !isDisposed && (
          <Link
            to={`/assets/${asset.id}/edit`}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all shadow-lg shadow-primary/10 text-sm"
          >
            <Edit size={16} /> Edit
          </Link>
        )}
      </PageHeader>

      {/* Main dashboard grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Specs */}
        <div className="lg:col-span-2 space-y-6">
          {/* Attributes */}
          <div className="glass-card p-6 rounded-2xl border border-border/50 grid grid-cols-2 sm:grid-cols-3 gap-6 text-sm">
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Brand</p>
              <p className="font-bold text-foreground mt-1">{asset.brand || 'Generic'}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Model</p>
              <p className="font-bold text-foreground mt-1">{asset.model || 'Generic'}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Category</p>
              <p className="font-bold text-foreground mt-1">{asset.category?.categoryName}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Location Room</p>
              <p className="font-bold text-foreground mt-1">{asset.location?.locationName}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Condition</p>
              <p className="font-bold text-foreground mt-1">{asset.condition?.conditionName}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Status</p>
              <p className="font-bold text-foreground mt-1">{asset.status?.statusName}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Purchase Cost</p>
              <p className="font-bold text-foreground mt-1">${asset.purchaseCost || '0.00'}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Purchase Date</p>
              <p className="font-bold text-foreground mt-1">
                {asset.purchaseDate ? new Date(asset.purchaseDate).toLocaleDateString() : '-'}
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase">Warranty Expire</p>
              <p className="font-bold text-foreground mt-1">
                {asset.warrantyEnd ? new Date(asset.warrantyEnd).toLocaleDateString() : '-'}
              </p>
            </div>
          </div>

          {/* Action Operations Panel */}
          {!isDisposed && (
            <div className="glass-card p-6 rounded-2xl border border-border/50 space-y-4">
              <h3 className="font-bold text-base">Lifecycle Actions</h3>
              <div className="flex flex-wrap gap-3">
                {isOperator && !isAllocated && (
                  <button
                    onClick={() => setModalType('allocate')}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border hover:bg-secondary text-sm font-semibold transition-all"
                  >
                    <ClipboardCheck size={16} /> Checkout / Allocate
                  </button>
                )}
                {isOperator && isAllocated && (
                  <button
                    onClick={() => setModalType('return')}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-500/10 text-teal-600 border border-teal-500/20 hover:bg-teal-500/20 text-sm font-semibold transition-all"
                  >
                    <ArrowLeft size={16} /> Return Asset
                  </button>
                )}
                {isOperator && (
                  <button
                    onClick={() => setModalType('transfer')}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border hover:bg-secondary text-sm font-semibold transition-all"
                  >
                    <ArrowRightLeft size={16} /> Location Transfer
                  </button>
                )}
                {!isAllocated && (
                  <button
                    onClick={() => setModalType('reserve')}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border hover:bg-secondary text-sm font-semibold transition-all"
                  >
                    <Calendar size={16} /> Book / Reserve
                  </button>
                )}
                {isOperator && (
                  <button
                    onClick={() => setModalType('dispose')}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-500/10 text-rose-600 border border-rose-500/20 hover:bg-rose-500/20 text-sm font-semibold transition-all"
                  >
                    <Ban size={16} /> Decommission / Dispose
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Details Tabs */}
          <div className="glass-card rounded-2xl border border-border/50 overflow-hidden">
            <div className="flex border-b border-border bg-secondary/10 px-4">
              {[
                { id: 'timeline', label: 'Timeline History' },
                { id: 'documents', label: 'Documents & Label' },
                { id: 'reservations', label: 'Reservation logs' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all outline-none ${
                    activeTab === tab.id
                      ? 'border-primary text-foreground'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="p-6">
              {activeTab === 'timeline' && <Timeline items={asset.histories || []} />}

              {activeTab === 'documents' && (
                <div className="space-y-6">
                  {/* Upload document */}
                  {isOperator && (
                    <div className="flex items-center justify-between border-b border-border/40 pb-4">
                      <h4 className="font-semibold text-sm">Upload Manual or Receipt PDF</h4>
                      <label className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-secondary hover:bg-secondary/80 cursor-pointer text-xs font-semibold border border-border transition-all">
                        <Upload size={14} />
                        {docUploading ? 'Uploading...' : 'Upload PDF'}
                        <input
                          type="file"
                          accept="application/pdf"
                          className="hidden"
                          onChange={handleDocUpload}
                          disabled={docUploading}
                        />
                      </label>
                    </div>
                  )}

                  {/* Documents list */}
                  <div className="space-y-3">
                    {asset.documents?.length === 0 ? (
                      <p className="text-xs text-muted-foreground">No custom documents attached.</p>
                    ) : (
                      asset.documents?.map((doc) => (
                        <div key={doc.id} className="flex items-center justify-between p-3 rounded-xl border border-border/50 hover:bg-secondary/15 transition-all text-xs">
                          <div className="flex items-center gap-2.5">
                            <FileText className="text-primary" size={16} />
                            <span className="font-bold truncate max-w-xs">{doc.fileName}</span>
                          </div>
                          <a
                            href={doc.filePath}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-semibold text-primary hover:underline"
                          >
                            Open / Download
                          </a>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'reservations' && (
                <div className="space-y-4">
                  {asset.reservations?.length === 0 ? (
                    <p className="text-xs text-muted-foreground">No reservations matching.</p>
                  ) : (
                    asset.reservations?.map((res) => (
                      <div key={res.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-4 rounded-xl border border-border/50 hover:bg-secondary/10 transition-all text-xs">
                        <div className="space-y-1">
                          <p className="font-bold text-sm">By User ID: {res.requestedByUser?.name}</p>
                          <p className="text-muted-foreground font-semibold">
                            Range: {new Date(res.reservationStart).toLocaleString()} - {new Date(res.reservationEnd).toLocaleString()}
                          </p>
                          {res.purpose && <p className="text-muted-foreground italic mt-1">&quot;{res.purpose}&quot;</p>}
                        </div>
                        
                        <div className="flex items-center gap-2 self-start sm:self-center">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            res.status === 'Approved' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' :
                            res.status === 'Pending' ? 'bg-amber-500/10 text-amber-600 border-amber-500/20' :
                            'bg-rose-500/10 text-rose-600 border-rose-500/20'
                          }`}>
                            {res.status}
                          </span>
                          
                          {isOperator && res.status === 'Pending' && (
                            <div className="flex gap-1.5 ml-2">
                              <button
                                onClick={() => handleApproveReservation(res.id, 'Approved')}
                                className="p-1 rounded bg-emerald-500/15 text-emerald-500 hover:bg-emerald-500/25 transition-all"
                                title="Approve"
                              >
                                <Check size={14} />
                              </button>
                              <button
                                onClick={() => handleApproveReservation(res.id, 'Rejected')}
                                className="p-1 rounded bg-rose-500/15 text-rose-500 hover:bg-rose-500/25 transition-all"
                                title="Reject"
                              >
                                <Ban size={14} />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Scan Labels */}
        <div className="space-y-6">
          <QRPreview value={asset.qrCode} label="Asset Scan Tag" />
          <BarcodePreview value={asset.barcode} label="Asset Tag Scanner" />
        </div>
      </div>

      {/* Modal Actions */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-lg glass-panel p-6 rounded-2xl border border-border/80 shadow-2xl relative animate-in fade-in duration-200">
            <button
              onClick={() => setModalType(null)}
              className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
            >
              <X size={18} />
            </button>

            <h2 className="text-xl font-bold mb-4 uppercase tracking-wide">
              {modalType === 'allocate' && 'Checkout / Allocate Asset'}
              {modalType === 'return' && 'Check-in / Return Asset'}
              {modalType === 'transfer' && 'Transfer Asset Location'}
              {modalType === 'reserve' && 'Book / Reserve Asset'}
              {modalType === 'dispose' && 'Decommission / Dispose Asset'}
            </h2>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-xs flex items-start gap-2.5">
                <AlertCircle className="shrink-0 mt-0.5" size={14} />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* forms */}
            {modalType === 'allocate' && (
              <form onSubmit={allocateForm.handleSubmit((data) => actionMutation.mutate({ type: 'allocate', payload: data }))} className="space-y-4 text-sm">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Assign to User / Student</label>
                  <select
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-foreground"
                    {...allocateForm.register('allocatedToUserId')}
                  >
                    <option value="">Select User / Student (Optional)</option>
                    {(usersData?.data || []).map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} {u.employeeId ? `(${u.employeeId})` : ''} - {u.role?.roleName || u.role || 'User'}
                      </option>
                    ))}
                  </select>
                  {allocateForm.formState.errors.allocatedToUserId && <p className="text-xs text-red-400 font-medium">{allocateForm.formState.errors.allocatedToUserId.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Assign to Department</label>
                  <select
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-foreground"
                    {...allocateForm.register('allocatedDepartmentId')}
                  >
                    <option value="">Select Department (Optional)</option>
                    {(deptsData?.data || []).map((dept) => (
                      <option key={dept.id} value={dept.id}>
                        {dept.departmentName} {dept.departmentCode ? `(${dept.departmentCode})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Expected Return Date</label>
                  <input
                    type="date"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...allocateForm.register('expectedReturnDate')}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Purpose</label>
                  <input
                    type="text"
                    placeholder="Classroom projection setups"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...allocateForm.register('purpose')}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Remarks</label>
                  <input
                    type="text"
                    placeholder="Staff laptop setup..."
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...allocateForm.register('remarks')}
                  />
                </div>
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                  <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                  <button type="submit" disabled={actionMutation.isPending} className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50">Checkout</button>
                </div>
              </form>
            )}

            {modalType === 'return' && (
              <div className="space-y-4 text-sm">
                <p>Are you sure you want to return this asset back to the available catalog list?</p>
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                  <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                  <button onClick={() => actionMutation.mutate({ type: 'return', payload: {} })} disabled={actionMutation.isPending} className="px-4 py-2 rounded-xl bg-teal-600 text-white font-semibold hover:bg-teal-500 transition-all disabled:opacity-50">Confirm Return</button>
                </div>
              </div>
            )}

            {modalType === 'transfer' && (
              <form onSubmit={transferForm.handleSubmit((data) => actionMutation.mutate({ type: 'transfer', payload: data }))} className="space-y-4 text-sm">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Target Room Location</label>
                  <select
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50"
                    {...transferForm.register('toLocationId')}
                  >
                    <option value="">Select Location</option>
                    {locations?.data?.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.locationName}
                      </option>
                    ))}
                  </select>
                  {transferForm.formState.errors.toLocationId && <p className="text-xs text-red-400 font-medium">{transferForm.formState.errors.toLocationId.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Target Department (Optional)</label>
                  <select
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-foreground"
                    {...transferForm.register('toDepartmentId')}
                  >
                    <option value="">Select Target Department</option>
                    {(deptsData?.data || []).map((dept) => (
                      <option key={dept.id} value={dept.id}>
                        {dept.departmentName} {dept.departmentCode ? `(${dept.departmentCode})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Reason for Transfer</label>
                  <input
                    type="text"
                    placeholder="Room relocation"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...transferForm.register('reason')}
                  />
                </div>
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                  <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                  <button type="submit" disabled={actionMutation.isPending} className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50">Transfer</button>
                </div>
              </form>
            )}

            {modalType === 'reserve' && (
              <form onSubmit={reserveForm.handleSubmit((data) => actionMutation.mutate({ type: 'reserve', payload: data }))} className="space-y-4 text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-muted-foreground uppercase">Start Date</label>
                    <input
                      type="datetime-local"
                      className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                      {...reserveForm.register('reservationStart')}
                    />
                    {reserveForm.formState.errors.reservationStart && <p className="text-xs text-red-400 font-medium">{reserveForm.formState.errors.reservationStart.message}</p>}
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-muted-foreground uppercase">End Date</label>
                    <input
                      type="datetime-local"
                      className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                      {...reserveForm.register('reservationEnd')}
                    />
                    {reserveForm.formState.errors.reservationEnd && <p className="text-xs text-red-400 font-medium">{reserveForm.formState.errors.reservationEnd.message}</p>}
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Purpose</label>
                  <input
                    type="text"
                    placeholder="CS seminar workshop setup"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...reserveForm.register('purpose')}
                  />
                </div>
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                  <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                  <button type="submit" disabled={actionMutation.isPending} className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all disabled:opacity-50">Reserve</button>
                </div>
              </form>
            )}

            {modalType === 'dispose' && (
              <form onSubmit={disposeForm.handleSubmit((data) => actionMutation.mutate({ type: 'dispose', payload: data }))} className="space-y-4 text-sm">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Disposal Channel / Method</label>
                  <input
                    type="text"
                    placeholder="Scrap Sale, Electronics recycling center"
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50"
                    {...disposeForm.register('method')}
                  />
                  {disposeForm.formState.errors.method && <p className="text-xs text-red-400 font-medium">{disposeForm.formState.errors.method.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-muted-foreground uppercase">Decommission Reason</label>
                  <textarea
                    rows="2"
                    placeholder="Water damaged beyond repair..."
                    className="w-full bg-secondary/40 border border-border rounded-xl px-3 py-2 outline-none focus:border-primary/50 resize-none"
                    {...disposeForm.register('reason')}
                  />
                  {disposeForm.formState.errors.reason && <p className="text-xs text-red-400 font-medium">{disposeForm.formState.errors.reason.message}</p>}
                </div>
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                  <button type="button" onClick={() => setModalType(null)} className="px-4 py-2 rounded-xl border border-border hover:bg-secondary font-semibold">Cancel</button>
                  <button type="submit" disabled={actionMutation.isPending} className="px-4 py-2 rounded-xl bg-rose-600 text-white font-semibold hover:bg-rose-500 transition-all disabled:opacity-50">Decommission</button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// Simple dialog controls helper
const X = ({ size }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

export default AssetDetails;

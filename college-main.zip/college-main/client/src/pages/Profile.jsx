import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  getProfile, 
  updateProfile, 
  changePassword, 
  updatePreferences, 
  uploadProfilePhoto 
} from '../services/profileService';

import Breadcrumb from '../components/Breadcrumb';
import PageHeader from '../components/PageHeader';
import { useToast } from '../contexts/ToastContext';
import { 
  Shield, Mail, Key,
  CheckCircle, Upload, Save, User, 
  Settings, AlertCircle 
} from 'lucide-react';

const profileInfoSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  phone: z.string().optional().nullable().or(z.literal('')),
});

const passwordUpdateSchema = z.object({
  oldPassword: z.string().min(1, 'Current password is required'),
  newPassword: z.string()
    .min(8, 'New password must be at least 8 characters long')
    .regex(/[A-Z]/, 'Must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Must contain at least one number')
    .regex(/[^A-Za-z0-9]/, 'Must contain at least one special character'),
  confirmPassword: z.string().min(1, 'Confirm password is required'),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword']
});

const preferenceSchema = z.object({
  theme: z.enum(['dark', 'light']),
  language: z.enum(['en', 'es', 'fr']),
  dateFormat: z.enum(['YYYY-MM-DD', 'DD/MM/YYYY']),
  timeFormat: z.enum(['12h', '24h']),
});

export const Profile = () => {
  const queryClient = useQueryClient();
  const { success, error: toastError } = useToast();
  
  const [activeSubTab, setActiveSubTab] = useState('info'); // 'info' | 'password' | 'preferences'
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [photoUploading, setPhotoUploading] = useState(false);

  // Queries
  const { data: profile, isLoading } = useQuery({
    queryKey: ['user_profile'],
    queryFn: getProfile,
  });

  // Forms Hook
  const infoForm = useForm({
    resolver: zodResolver(profileInfoSchema),
    values: {
      name: profile?.name || '',
      phone: profile?.phone || '',
    }
  });

  const passForm = useForm({
    resolver: zodResolver(passwordUpdateSchema),
    defaultValues: { oldPassword: '', newPassword: '', confirmPassword: '' }
  });

  const prefForm = useForm({
    resolver: zodResolver(preferenceSchema),
    values: {
      theme: profile?.preferences?.theme || 'dark',
      language: profile?.preferences?.language || 'en',
      dateFormat: profile?.preferences?.dateFormat || 'YYYY-MM-DD',
      timeFormat: profile?.preferences?.timeFormat || '12h',
    }
  });

  // Mutators
  const infoMutation = useMutation({
    mutationFn: updateProfile,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user_profile'] });
      setSuccessMsg('Profile information updated successfully.');
      setErrorMsg('');
      success('Profile information updated successfully.');
      setTimeout(() => setSuccessMsg(''), 4000);
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to update profile.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const passMutation = useMutation({
    mutationFn: changePassword,
    onSuccess: () => {
      passForm.reset();
      setSuccessMsg('Password changed successfully.');
      setErrorMsg('');
      success('Password changed successfully.');
      setTimeout(() => setSuccessMsg(''), 4000);
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to change password.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const prefMutation = useMutation({
    mutationFn: updatePreferences,
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['user_profile'] });
      setSuccessMsg('User preferences updated successfully.');
      setErrorMsg('');
      success('User preferences updated successfully.');
      
      // Apply theme preference dynamically to HTML element
      if (data?.data?.theme === 'light') {
        document.documentElement.classList.remove('dark');
      } else {
        document.documentElement.classList.add('dark');
      }
      
      setTimeout(() => setSuccessMsg(''), 4000);
    },
    onError: (err) => {
      const msg = err.response?.data?.message || 'Failed to update preferences.';
      setErrorMsg(msg);
      toastError(msg);
    }
  });

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setPhotoUploading(true);
    setErrorMsg('');
    try {
      await uploadProfilePhoto(file);
      queryClient.invalidateQueries({ queryKey: ['user_profile'] });
      setSuccessMsg('Profile photo updated successfully.');
      success('Profile photo updated successfully.');
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to upload photo.';
      setErrorMsg(msg);
      toastError(msg);
    } finally {
      setPhotoUploading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Breadcrumb items={[{ label: 'My Profile' }]} />

      <PageHeader 
        title="My Profile Settings" 
        description="Manage personal contact coordinates, avatar uploads, user preferences, and dashboard themes."
      />

      {successMsg && (
        <div className="p-3.5 bg-emerald-500/10 text-emerald-500 text-xs rounded-2xl border border-emerald-500/20 font-bold flex items-center gap-2">
          <CheckCircle size={14} />
          {successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 bg-rose-500/10 text-rose-500 text-xs rounded-2xl border border-rose-500/20 font-bold flex items-center gap-2">
          <AlertCircle size={14} />
          {errorMsg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Avatar Column */}
        <div className="glass-card p-6 rounded-2xl border border-border/50 space-y-6 flex flex-col items-center text-center h-fit">
          <div className="relative group">
            {profile?.profileImage ? (
              <img 
                src={`http://localhost:5000${profile.profileImage}`} 
                alt="Avatar" 
                className="h-28 w-28 rounded-2xl object-cover border border-border/40 shadow-inner" 
              />
            ) : (
              <div className="h-28 w-28 rounded-2xl bg-primary/10 text-primary flex items-center justify-center font-black text-4xl border border-primary/20 shadow-sm">
                {profile?.name?.charAt(0) || 'U'}
              </div>
            )}
            
            <label className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-2xl opacity-0 group-hover:opacity-100 transition-all cursor-pointer text-white text-xs font-bold gap-1.5">
              <Upload size={14} />
              <span>{photoUploading ? 'Uploading...' : 'Upload'}</span>
              <input type="file" onChange={handlePhotoUpload} accept="image/*" className="hidden" />
            </label>
          </div>

          <div className="space-y-1">
            <h2 className="text-xl font-bold tracking-tight">{profile?.name}</h2>
            <p className="text-xs font-semibold text-muted-foreground uppercase">{profile?.role?.roleName}</p>
          </div>

          <div className="w-full space-y-3.5 pt-6 border-t border-border/40 text-xs text-left text-muted-foreground font-semibold">
            <div className="flex items-center gap-2.5">
              <Mail size={14} className="text-primary" />
              <span className="truncate">{profile?.email}</span>
            </div>
            {profile?.employeeId && (
              <div className="flex items-center gap-2.5">
                <Shield size={14} className="text-primary" />
                <span>ID: {profile.employeeId}</span>
              </div>
            )}
            {profile?.department && (
              <div className="flex items-center gap-2.5">
                <Settings size={14} className="text-primary" />
                <span>Dept: {profile.department.departmentName}</span>
              </div>
            )}
          </div>
        </div>

        {/* Form controls Column */}
        <div className="lg:col-span-3 glass-card rounded-2xl border border-border/50 overflow-hidden flex flex-col">
          {/* Sub tabs */}
          <div className="flex border-b border-border/40 bg-secondary/10 px-4 py-1.5 gap-2 shrink-0">
            {[
              { id: 'info', label: 'Personal Information', icon: User },
              { id: 'password', label: 'Security & Password', icon: Key },
              { id: 'preferences', label: 'Console Preferences', icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => { setErrorMsg(''); setActiveSubTab(tab.id); }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    activeSubTab === tab.id
                      ? 'bg-primary text-primary-foreground shadow-md shadow-primary/10'
                      : 'text-muted-foreground hover:bg-secondary/40'
                  }`}
                >
                  <Icon size={14} />
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="p-6 flex-1">
            {/* TAB: Personal Info */}
            {activeSubTab === 'info' && (
              <form onSubmit={infoForm.handleSubmit((data) => infoMutation.mutate(data))} className="space-y-4 max-w-md text-xs">
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Full Name</label>
                  <input type="text" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...infoForm.register('name')} />
                  {infoForm.formState.errors.name && <p className="text-red-400 font-medium">{infoForm.formState.errors.name.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Phone Number</label>
                  <input type="text" placeholder="+1 555-0100" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...infoForm.register('phone')} />
                </div>
                <div className="pt-4">
                  <button type="submit" disabled={infoMutation.isPending} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all text-xs">
                    <Save size={14} /> {infoMutation.isPending ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            )}

            {/* TAB: Change Password */}
            {activeSubTab === 'password' && (
              <form onSubmit={passForm.handleSubmit((data) => passMutation.mutate(data))} className="space-y-4 max-w-md text-xs">
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Current Password</label>
                  <input type="password" placeholder="••••••••" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...passForm.register('oldPassword')} />
                  {passForm.formState.errors.oldPassword && <p className="text-red-400 font-medium">{passForm.formState.errors.oldPassword.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">New Password</label>
                  <input type="password" placeholder="••••••••" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...passForm.register('newPassword')} />
                  {passForm.formState.errors.newPassword && <p className="text-red-400 font-medium">{passForm.formState.errors.newPassword.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-muted-foreground uppercase">Confirm New Password</label>
                  <input type="password" placeholder="••••••••" className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...passForm.register('confirmPassword')} />
                  {passForm.formState.errors.confirmPassword && <p className="text-red-400 font-medium">{passForm.formState.errors.confirmPassword.message}</p>}
                </div>
                <div className="pt-4">
                  <button type="submit" disabled={passMutation.isPending} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all text-xs">
                    <Key size={14} /> Update Password
                  </button>
                </div>
              </form>
            )}

            {/* TAB: Console Preferences */}
            {activeSubTab === 'preferences' && (
              <form onSubmit={prefForm.handleSubmit((data) => prefMutation.mutate(data))} className="space-y-4 max-w-md text-xs">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="font-semibold text-muted-foreground uppercase">Theme Choice</label>
                    <select className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...prefForm.register('theme')}>
                      <option value="dark">Dark Theme</option>
                      <option value="light">Light Theme</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="font-semibold text-muted-foreground uppercase">Preferred Language</label>
                    <select className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...prefForm.register('language')}>
                      <option value="en">English (US)</option>
                      <option value="es">Español</option>
                      <option value="fr">Français</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="font-semibold text-muted-foreground uppercase">Date Format</label>
                    <select className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...prefForm.register('dateFormat')}>
                      <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                      <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="font-semibold text-muted-foreground uppercase">Time Display Format</label>
                    <select className="w-full bg-secondary/35 border border-border rounded-xl px-3 py-2.5 outline-none focus:border-primary/50 text-sm" {...prefForm.register('timeFormat')}>
                      <option value="12h">12-Hour (AM/PM)</option>
                      <option value="24h">24-Hour</option>
                    </select>
                  </div>
                </div>
                <div className="pt-4">
                  <button type="submit" disabled={prefMutation.isPending} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all text-xs">
                    <Save size={14} /> Save Preferences
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;

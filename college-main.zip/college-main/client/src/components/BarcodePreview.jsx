import React from 'react';
import { Printer } from 'lucide-react';

export const BarcodePreview = ({ value, label = 'Asset Barcode' }) => {
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Print Barcode - ${value}</title>
          <style>
            body { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: monospace; }
            .card { border: 2px solid black; padding: 20px; border-radius: 10px; text-align: center; }
            .lines { height: 60px; width: 200px; background: repeating-linear-gradient(90deg, black, black 2px, white 2px, white 6px); margin: 10px auto; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="card">
            <h3>COLLEGE ASSET REGISTER</h3>
            <div class="lines"></div>
            <strong>${value}</strong>
            <p>${label}</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="glass-card p-6 rounded-2xl border border-border/60 flex flex-col items-center justify-center space-y-4 max-w-sm mx-auto shadow-xl">
      <div className="h-28 w-64 bg-slate-900 border border-slate-800 rounded-xl flex flex-col items-center justify-center p-4 overflow-hidden relative">
        {/* Mock realistic variable-width barcode lines */}
        <div className="flex items-center justify-center h-16 w-full opacity-90 overflow-hidden">
          {Array.from({ length: 30 }).map((_, idx) => {
            const widths = [1, 2, 3, 4];
            const width = widths[idx % widths.length];
            const isGap = idx % 3 === 0;
            return (
              <div
                key={idx}
                className="h-12 bg-primary transition-all rounded-sm shrink-0"
                style={{
                  width: `${width}px`,
                  marginLeft: isGap ? '4px' : '2px',
                }}
              />
            );
          })}
        </div>
      </div>

      <div className="text-center space-y-1">
        <h4 className="text-sm font-bold tracking-wider uppercase font-mono">{value}</h4>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>

      <div className="flex gap-2.5 w-full pt-1">
        <button
          onClick={handlePrint}
          className="flex-1 py-2 rounded-xl border border-border hover:bg-secondary flex items-center justify-center gap-2 text-xs font-semibold transition-all"
        >
          <Printer size={14} />
          Print Barcode
        </button>
      </div>
    </div>
  );
};

export default BarcodePreview;

import React from 'react';
import { Database } from 'lucide-react';

export const EmptyState = ({ 
  title = 'No Records Found', 
  description = 'Add a new entry or adjust your search filters to get started.', 
  children 
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center glass-card rounded-2xl border border-border/50 max-w-lg mx-auto space-y-4 my-8">
      <div className="h-14 w-14 rounded-2xl bg-secondary/80 flex items-center justify-center text-muted-foreground/60 border border-border/80 shadow-inner">
        <Database size={28} />
      </div>
      <div className="space-y-1">
        <h3 className="text-lg font-bold">{title}</h3>
        <p className="text-sm text-muted-foreground max-w-xs mx-auto">{description}</p>
      </div>
      {children && <div className="pt-2">{children}</div>}
    </div>
  );
};

export default EmptyState;

import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

export const Breadcrumb = ({ items = [] }) => {
  return (
    <nav className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium mb-4 shrink-0">
      <Link to="/dashboard" className="flex items-center gap-1 hover:text-foreground transition-all">
        <Home size={12} />
        Dashboard
      </Link>
      {items.map((item, idx) => (
        <React.Fragment key={idx}>
          <ChevronRight size={12} className="text-muted-foreground/60" />
          {item.to ? (
            <Link to={item.to} className="hover:text-foreground transition-all truncate">
              {item.label}
            </Link>
          ) : (
            <span className="text-foreground/80 font-semibold truncate">{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
};

export default Breadcrumb;

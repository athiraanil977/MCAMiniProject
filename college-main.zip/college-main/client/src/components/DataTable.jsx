import React from 'react';
import { ChevronLeft, ChevronRight, Search } from 'lucide-react';

export const DataTable = ({
  columns = [],
  data = [],
  loading = false,
  totalItems = 0,
  page = 1,
  limit = 10,
  onPageChange,
  onSearchChange,
  onLimitChange,
  searchPlaceholder = 'Search records...',
  filterActions,
  emptyMessage = 'No records found.',
}) => {
  const totalPages = Math.ceil(totalItems / limit) || 1;

  const handlePrev = () => {
    if (page > 1) onPageChange(page - 1);
  };

  const handleNext = () => {
    if (page < totalPages) onPageChange(page + 1);
  };

  return (
    <div className="space-y-4">
      {/* Table Controls (Search, Filters) */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        {onSearchChange && (
          <div className="flex items-center gap-2 bg-secondary/40 rounded-xl px-3 py-2 border border-border/60 focus-within:border-primary/50 transition-all w-full sm:w-80 shrink-0">
            <Search size={16} className="text-muted-foreground" />
            <input
              type="text"
              placeholder={searchPlaceholder}
              className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground/60 text-foreground"
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto sm:justify-end">
          {filterActions}
          {onLimitChange && (
            <select
              value={limit}
              onChange={(e) => onLimitChange(parseInt(e.target.value, 10))}
              className="px-3 py-2 rounded-xl border border-border bg-background text-sm font-medium hover:bg-secondary transition-all outline-none"
            >
              {[5, 10, 20, 50].map((size) => (
                <option key={size} value={size}>
                  {size} / page
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Grid Container */}
      <div className="glass-card rounded-2xl overflow-hidden border border-border/50">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border bg-secondary/30 text-muted-foreground text-xs font-semibold uppercase tracking-wider">
                {columns.map((col) => (
                  <th
                    key={col.key}
                    className={`px-6 py-4 ${col.className || ''} ${
                      col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : ''
                    }`}
                  >
                    {col.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50 text-sm">
              {loading ? (
                // Loading Skeletons
                Array.from({ length: limit }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    {columns.map((col) => (
                      <td key={col.key} className="px-6 py-4.5">
                        <div className="h-4 bg-muted rounded w-3/4" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : data.length === 0 ? (
                <tr>
                  <td colSpan={columns.length} className="px-6 py-12 text-center text-muted-foreground font-medium">
                    {emptyMessage}
                  </td>
                </tr>
              ) : (
                data.map((row, idx) => (
                  <tr key={row.id || idx} className="hover:bg-secondary/20 transition-colors">
                    {columns.map((col) => (
                      <td
                        key={col.key}
                        className={`px-6 py-4 ${col.className || ''} ${
                          col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : ''
                        }`}
                      >
                        {col.render ? col.render(row) : row[col.key] || '-'}
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {onPageChange && (
          <div className="px-6 py-4 border-t border-border flex items-center justify-between text-sm text-muted-foreground bg-secondary/10 shrink-0">
            <span>
              Showing <strong className="text-foreground">{data.length === 0 ? 0 : (page - 1) * limit + 1}</strong> to{' '}
              <strong className="text-foreground">{Math.min(page * limit, totalItems)}</strong> of{' '}
              <strong className="text-foreground">{totalItems}</strong> entries
            </span>
            <div className="flex gap-2">
              <button
                onClick={handlePrev}
                disabled={page === 1 || loading}
                className="p-1.5 rounded-lg border border-border hover:bg-secondary text-muted-foreground hover:text-foreground transition-all disabled:opacity-50"
                aria-label="Previous Page"
              >
                <ChevronLeft size={18} />
              </button>
              <button
                onClick={handleNext}
                disabled={page === totalPages || loading}
                className="p-1.5 rounded-lg border border-border hover:bg-secondary text-muted-foreground hover:text-foreground transition-all disabled:opacity-50"
                aria-label="Next Page"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DataTable;

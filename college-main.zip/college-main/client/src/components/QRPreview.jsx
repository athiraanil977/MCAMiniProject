import React from 'react';
import { Printer } from 'lucide-react';

export const QRPreview = ({ value, label = 'Asset Tag Code' }) => {
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Print QR Code - ${value}</title>
          <style>
            body { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: monospace; }
            .card { border: 2px solid black; padding: 20px; border-radius: 10px; text-align: center; }
            .qr-box { width: 150px; height: 150px; background: black; margin: 10px auto; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="card">
            <h3>COLLEGE ASSET REGISTER</h3>
            <div class="qr-box"></div>
            <strong>${value}</strong>
            <p>${label}</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="glass-card p-6 rounded-2xl border border-border/60 flex flex-col items-center justify-center space-y-4 max-w-sm mx-auto shadow-xl">
      <div className="relative h-44 w-44 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-center overflow-hidden group">
        {/* Mock highly premium QR Blocks */}
        <div className="grid grid-cols-5 gap-1.5 p-4 opacity-90">
          {Array.from({ length: 25 }).map((_, idx) => {
            const isFilled = (idx % 2 === 0 && idx % 3 !== 0) || idx === 0 || idx === 4 || idx === 20 || idx === 24;
            return (
              <div
                key={idx}
                className={`h-6 w-6 rounded-sm transition-all ${
                  isFilled ? 'bg-primary shadow-sm shadow-primary/20' : 'bg-transparent'
                }`}
              />
            );
          })}
        </div>
        
        {/* Scan Bracket Lines */}
        <div className="absolute top-3 left-3 h-4 w-4 border-t-2 border-l-2 border-primary/60" />
        <div className="absolute top-3 right-3 h-4 w-4 border-t-2 border-r-2 border-primary/60" />
        <div className="absolute bottom-3 left-3 h-4 w-4 border-b-2 border-l-2 border-primary/60" />
        <div className="absolute bottom-3 right-3 h-4 w-4 border-b-2 border-r-2 border-primary/60" />
      </div>

      <div className="text-center space-y-1">
        <h4 className="text-sm font-bold tracking-wider uppercase font-mono">{value}</h4>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>

      <div className="flex gap-2.5 w-full pt-2">
        <button
          onClick={handlePrint}
          className="flex-1 py-2 rounded-xl border border-border hover:bg-secondary flex items-center justify-center gap-2 text-xs font-semibold transition-all"
        >
          <Printer size={14} />
          Print Label
        </button>
      </div>
    </div>
  );
};

export default QRPreview;

import React from 'react';
import { Circle, FileText, CheckCircle, XCircle, RefreshCw, LogOut, ArrowRightLeft } from 'lucide-react';

const getActionStyles = (action) => {
  switch (action) {
    case 'Created':
      return { color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20', icon: CheckCircle };
    case 'Updated':
      return { color: 'text-indigo-500 bg-indigo-500/10 border-indigo-500/20', icon: RefreshCw };
    case 'Allocated':
      return { color: 'text-amber-500 bg-amber-500/10 border-amber-500/20', icon: LogOut };
    case 'Returned':
      return { color: 'text-teal-500 bg-teal-500/10 border-teal-500/20', icon: CheckCircle };
    case 'Transferred':
      return { color: 'text-blue-500 bg-blue-500/10 border-blue-500/20', icon: ArrowRightLeft };
    case 'Disposed':
      return { color: 'text-rose-500 bg-rose-500/10 border-rose-500/20', icon: XCircle };
    case 'Reserved':
      return { color: 'text-purple-500 bg-purple-500/10 border-purple-500/20', icon: FileText };
    default:
      return { color: 'text-slate-500 bg-slate-500/10 border-slate-500/20', icon: Circle };
  }
};

export const Timeline = ({ items = [] }) => {
  if (items.length === 0) {
    return (
      <div className="py-8 text-center text-sm text-muted-foreground font-medium">
        No lifecycle events recorded for this asset yet.
      </div>
    );
  }

  return (
    <div className="relative border-l border-border pl-6 ml-4 space-y-6">
      {items.map((item, idx) => {
        const { color, icon: Icon } = getActionStyles(item.action);
        const performedByName = item.user?.name || 'System';

        return (
          <div key={item.id || idx} className="relative group">
            {/* Timeline node icon */}
            <span className={`absolute -left-[37px] top-0.5 rounded-full p-1.5 border flex items-center justify-center shadow-lg transition-transform group-hover:scale-110 ${color}`}>
              <Icon size={14} />
            </span>

            {/* Event Content */}
            <div className="space-y-1.5 bg-secondary/15 border border-border/40 p-4 rounded-xl hover:border-border/80 transition-all">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
                <span className="font-bold text-sm text-foreground">{item.action}</span>
                <span className="text-[10px] text-muted-foreground font-medium">
                  {new Date(item.createdAt).toLocaleString()}
                </span>
              </div>
              
              {item.remarks && <p className="text-xs text-muted-foreground leading-relaxed">{item.remarks}</p>}
              
              <div className="text-[10px] text-muted-foreground/80 font-semibold flex items-center gap-1 pt-1.5 border-t border-border/30">
                <span>By:</span>
                <span className="text-foreground">{performedByName}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Timeline;

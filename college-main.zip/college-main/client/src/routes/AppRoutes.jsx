import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import GlobalLayout from '../layouts/GlobalLayout';
import DashboardLayout from '../layouts/DashboardLayout';
import ProtectedRoute from '../components/ProtectedRoute';
import PublicRoute from '../components/PublicRoute';

// Page imports
import Login from '../pages/Login';
import ForgotPassword from '../pages/ForgotPassword';
import ResetPassword from '../pages/ResetPassword';
import Dashboard from '../pages/Dashboard';
import AssetList from '../pages/AssetList';
import AssetForm from '../pages/AssetForm';
import AssetDetails from '../pages/AssetDetails';
import Categories from '../pages/Categories';
import Vendors from '../pages/Vendors';
import Locations from '../pages/Locations';
import Maintenance from '../pages/Maintenance';
import Users from '../pages/Users';
import Manufacturers from '../pages/Manufacturers';
import Reports from '../pages/Reports';
import Settings from '../pages/Settings';
import Profile from '../pages/Profile';
import Notifications from '../pages/Notifications';
import AuditLogs from '../pages/AuditLogs';
import HealthDashboard from '../pages/HealthDashboard';
import Backups from '../pages/Backups';
import NotFound from '../pages/NotFound';
import Unauthorized from '../pages/Unauthorized';
import Reservations from '../pages/Reservations';

// ─── Role Constants (must match roleName values from the DB seed) ─────────────
const ADMIN   = ['Super Admin'];
const MANAGER = ['Super Admin', 'Asset Manager'];
const STAFF   = ['Super Admin', 'Asset Manager', 'Department Staff', 'Faculty', 'Lab Assistant', 'Store Keeper'];
// Students get view_assets permission — they can reserve assets & create maintenance requests
const STUDENT_PLUS = [...STAFF, 'Student'];
const ALL     = ['Super Admin', 'Asset Manager', 'Department Staff', 'Faculty', 'Lab Assistant', 'Store Keeper', 'Viewer', 'Student'];


export const AppRoutes = () => {
  return (
    <Routes>
      <Route element={<GlobalLayout />}>
        {/* Public auth pages */}
        <Route element={<PublicRoute />}>
          <Route path="/login"           element={<Login />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password"  element={<ResetPassword />} />
        </Route>

        {/* Core error/fallback routes */}
        <Route path="/unauthorized" element={<Unauthorized />} />

        {/* ── ALL authenticated roles ── */}
        <Route element={<ProtectedRoute allowedRoles={ALL} />}>
          <Route element={<DashboardLayout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />

            {/* Accessible by all logged-in users */}
            <Route path="/dashboard"      element={<Dashboard />} />
            <Route path="/assets"         element={<AssetList />} />
            <Route path="/assets/:id"     element={<AssetDetails />} />
            <Route path="/notifications"  element={<Notifications />} />
            <Route path="/profile"        element={<Profile />} />
          </Route>
        </Route>

        {/* ── STUDENT and above (excludes Viewer) ── */}
        <Route element={<ProtectedRoute allowedRoles={STUDENT_PLUS} />}>
          <Route element={<DashboardLayout />}>
            <Route path="/assets/new"        element={<AssetForm />} />
            <Route path="/assets/:id/edit"   element={<AssetForm />} />
            <Route path="/categories"        element={<Categories />} />
            <Route path="/vendors"           element={<Vendors />} />
            <Route path="/manufacturers"     element={<Manufacturers />} />
            <Route path="/locations"         element={<Locations />} />
            <Route path="/maintenance"       element={<Maintenance />} />
            <Route path="/reports"           element={<Reports />} />
          </Route>
        </Route>

        {/* ── MANAGER and above ── */}
        <Route element={<ProtectedRoute allowedRoles={MANAGER} />}>
          <Route element={<DashboardLayout />}>
            <Route path="/reservations" element={<Reservations />} />
          </Route>
        </Route>


        {/* ── ADMIN (Super Admin) only ── */}
        <Route element={<ProtectedRoute allowedRoles={ADMIN} />}>
          <Route element={<DashboardLayout />}>
            <Route path="/users"       element={<Users />} />
            <Route path="/audit-logs"  element={<AuditLogs />} />
            <Route path="/health"      element={<HealthDashboard />} />
            <Route path="/backups"     element={<Backups />} />
            <Route path="/settings"    element={<Settings />} />
          </Route>
        </Route>

        {/* 404 Handling */}
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
};

export default AppRoutes;

import React, { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useQuery } from '@tanstack/react-query';
import { getUnreadCount } from '../services/notificationService';
import {
  LayoutDashboard,
  Package,
  Tags,
  Store,
  MapPin,
  Wrench,
  Users,
  BarChart3,
  Settings,
  LogOut,
  Sun,
  Moon,
  Menu,
  X,
  Bell,
  Search,
  Factory,
  Activity,
  HeartPulse,
  DatabaseBackup,
  CalendarCheck,
} from 'lucide-react';

// ─── Navigation with role visibility ─────────────────────────────────────────
const ALL     = ['Super Admin', 'Asset Manager', 'Department Staff', 'Faculty', 'Lab Assistant', 'Store Keeper', 'Viewer', 'Student'];
const STAFF   = ['Super Admin', 'Asset Manager', 'Department Staff', 'Faculty', 'Lab Assistant', 'Store Keeper'];
const MANAGER = ['Super Admin', 'Asset Manager'];
const ADMIN   = ['Super Admin'];

const navigation = [
  { name: 'Dashboard',      to: '/dashboard',    icon: LayoutDashboard, roles: ALL },
  { name: 'Assets',         to: '/assets',       icon: Package,         roles: ALL },
  { name: 'Categories',     to: '/categories',   icon: Tags,            roles: STAFF },
  { name: 'Vendors',        to: '/vendors',      icon: Store,           roles: STAFF },
  { name: 'Manufacturers',  to: '/manufacturers',icon: Factory,         roles: STAFF },
  { name: 'Locations',      to: '/locations',    icon: MapPin,          roles: STAFF },
  { name: 'Maintenance',    to: '/maintenance',  icon: Wrench,          roles: STAFF },
  { name: 'Reports',        to: '/reports',      icon: BarChart3,       roles: STAFF },
  { name: 'Reservations',  to: '/reservations', icon: CalendarCheck,   roles: MANAGER },
  { name: 'Notifications',  to: '/notifications',icon: Bell,            roles: ALL },
  { name: 'Users',          to: '/users',        icon: Users,           roles: ADMIN },
  { name: 'Audit Logs',     to: '/audit-logs',   icon: Activity,        roles: ADMIN },
  { name: 'System Health',  to: '/health',       icon: HeartPulse,      roles: ADMIN },
  { name: 'Backups',        to: '/backups',      icon: DatabaseBackup,  roles: ADMIN },
  { name: 'System Settings',to: '/settings',     icon: Settings,        roles: ADMIN },
];

// Role badge colours
const ROLE_BADGE = {
  'Super Admin':      'bg-violet-500/20 text-violet-400',
  'Asset Manager':    'bg-blue-500/20 text-blue-400',
  'Department Staff': 'bg-cyan-500/20 text-cyan-400',
  'Faculty':          'bg-emerald-500/20 text-emerald-400',
  'Lab Assistant':    'bg-yellow-500/20 text-yellow-400',
  'Store Keeper':     'bg-orange-500/20 text-orange-400',
  'Viewer':           'bg-slate-500/20 text-slate-400',
  'Student':          'bg-pink-500/20 text-pink-400',
};

export const DashboardLayout = () => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Live unread notification count
  const { data: unreadData } = useQuery({
    queryKey: ['unread_count'],
    queryFn: getUnreadCount,
    refetchInterval: 60000, // refresh every 60 seconds
    enabled: !!user,
  });
  const unreadCount = unreadData?.count ?? 0;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Filter nav items by the current user's role
  const visibleNav = navigation.filter(item => item.roles.includes(user?.role));

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar Layout */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 glass-panel border-r border-border flex flex-col transition-transform duration-300 lg:translate-x-0 lg:static lg:h-screen
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Sidebar Header */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-border">
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-lg shadow-lg shadow-primary/20">
              C
            </div>
            <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-primary to-violet-600 bg-clip-text text-transparent">
              AssetManager
            </span>
          </Link>
          <button 
            onClick={() => setSidebarOpen(false)} 
            className="lg:hidden text-muted-foreground hover:text-foreground"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.name}
                to={item.to}
                className={({ isActive }) => `
                  flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group
                  ${isActive 
                    ? 'bg-primary text-primary-foreground shadow-md shadow-primary/10' 
                    : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}
                `}
                onClick={() => setSidebarOpen(false)}
              >
                <Icon size={18} className="shrink-0 transition-transform group-hover:scale-110" />
                {item.name}
              </NavLink>
            );
          })}
        </nav>

        {/* Sidebar Footer User Section */}
        <div className="p-4 border-t border-border space-y-3">
          <Link 
            to="/profile" 
            className="flex items-center gap-3 p-2 rounded-xl hover:bg-secondary transition-all"
            onClick={() => setSidebarOpen(false)}
          >
            <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-semibold">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-semibold truncate">{user?.name || 'Academic Staff'}</p>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                ROLE_BADGE[user?.role] || 'bg-muted text-muted-foreground'
              }`}>{user?.role || 'User'}</span>
            </div>
          </Link>

          <div className="flex gap-2">
            <NavLink
              to="/settings"
              className={({ isActive }) => `
                flex-1 flex items-center justify-center p-2.5 rounded-xl border border-border text-muted-foreground hover:bg-secondary hover:text-foreground transition-all
                ${isActive ? 'bg-secondary text-foreground' : ''}
              `}
              onClick={() => setSidebarOpen(false)}
              title="Settings"
            >
              <Settings size={18} />
            </NavLink>
            <button
              onClick={handleLogout}
              className="flex-1 flex items-center justify-center p-2.5 rounded-xl border border-border text-destructive hover:bg-destructive/10 transition-all"
              title="Sign Out"
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Navbar */}
        <header className="h-16 border-b border-border glass-panel px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden text-muted-foreground hover:text-foreground"
            >
              <Menu size={22} />
            </button>

            {/* Global Search Bar Placeholder */}
            <div className="hidden md:flex items-center gap-2 bg-secondary/60 rounded-xl px-3 py-1.5 border border-border/40 focus-within:border-primary/50 transition-all w-80">
              <Search size={16} className="text-muted-foreground" />
              <input 
                type="text" 
                placeholder="Search assets, users, categories..." 
                className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground/60"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Dark Mode Toggle */}
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-xl text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
              aria-label="Toggle Theme"
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            {/* Live Notification Bell */}
            <button
              onClick={() => navigate('/notifications')}
              className="p-2 rounded-xl text-muted-foreground hover:bg-secondary hover:text-foreground transition-all relative"
              aria-label="Notifications"
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] flex items-center justify-center rounded-full bg-primary text-primary-foreground text-[10px] font-bold ring-2 ring-background px-1">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>

            <div className="h-6 w-[1px] bg-border mx-1" />

            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold">{user?.name || 'Administrator'}</p>
              <p className="text-xs text-muted-foreground capitalize">{user?.role || 'System'}</p>
            </div>
          </div>
        </header>

        {/* Route Pages Container */}
        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;

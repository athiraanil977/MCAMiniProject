import React, { createContext, useContext, useState, useCallback, useRef } from 'react';
import { CheckCircle, XCircle, AlertTriangle, Info, X } from 'lucide-react';

const ToastContext = createContext(null);

const ICONS = {
  success: { Icon: CheckCircle, colors: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400', bar: 'bg-emerald-500' },
  error:   { Icon: XCircle,     colors: 'bg-rose-500/15 border-rose-500/30 text-rose-400',         bar: 'bg-rose-500' },
  warning: { Icon: AlertTriangle,colors: 'bg-amber-500/15 border-amber-500/30 text-amber-400',     bar: 'bg-amber-500' },
  info:    { Icon: Info,         colors: 'bg-blue-500/15 border-blue-500/30 text-blue-400',         bar: 'bg-blue-500' },
};

let _idCounter = 0;

export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);
  const timersRef = useRef({});

  const dismiss = useCallback((id) => {
    // Mark as leaving for exit animation
    setToasts(prev => prev.map(t => t.id === id ? { ...t, leaving: true } : t));
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
      clearTimeout(timersRef.current[id]);
      delete timersRef.current[id];
    }, 300);
  }, []);

  const toast = useCallback((message, type = 'info', duration = 4000) => {
    const id = ++_idCounter;
    setToasts(prev => [...prev, { id, message, type, leaving: false }]);
    timersRef.current[id] = setTimeout(() => dismiss(id), duration);
    return id;
  }, [dismiss]);

  // Convenience helpers
  const success = useCallback((msg, dur) => toast(msg, 'success', dur), [toast]);
  const error   = useCallback((msg, dur) => toast(msg, 'error', dur ?? 6000), [toast]);
  const warning = useCallback((msg, dur) => toast(msg, 'warning', dur), [toast]);
  const info    = useCallback((msg, dur) => toast(msg, 'info', dur), [toast]);

  return (
    <ToastContext.Provider value={{ toast, success, error, warning, info, dismiss }}>
      {children}

      {/* Toast Renderer — fixed top-right */}
      <div
        aria-live="polite"
        className="fixed top-4 right-4 z-[9999] flex flex-col gap-2 w-full max-w-sm pointer-events-none"
      >
        {toasts.map(({ id, message, type, leaving }) => {
          const { Icon, colors, bar } = ICONS[type] || ICONS.info;
          return (
            <div
              key={id}
              className={`
                pointer-events-auto relative overflow-hidden
                flex items-start gap-3 p-4 pr-10 rounded-2xl border shadow-xl shadow-black/30
                backdrop-blur-md text-sm font-medium
                transition-all duration-300
                ${colors}
                ${leaving
                  ? 'opacity-0 translate-x-4 scale-95'
                  : 'opacity-100 translate-x-0 scale-100'}
              `}
            >
              {/* Accent bar */}
              <div className={`absolute left-0 top-0 bottom-0 w-1 rounded-l-2xl ${bar}`} />

              <Icon size={18} className="shrink-0 mt-0.5" />
              <span className="flex-1 leading-snug">{message}</span>

              <button
                onClick={() => dismiss(id)}
                className="absolute top-3 right-3 opacity-60 hover:opacity-100 transition-opacity"
                aria-label="Dismiss"
              >
                <X size={14} />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
};

export default ToastContext;

import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import axiosInstance from '../lib/axiosInstance';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const refreshTimerRef = useRef(null);

  // Clear timers
  const clearRefreshTimer = () => {
    if (refreshTimerRef.current) {
      clearInterval(refreshTimerRef.current);
      refreshTimerRef.current = null;
    }
  };

  // Silent refresh executor
  const performSilentRefresh = async () => {
    const refreshToken = localStorage.getItem('refreshToken');
    if (!refreshToken) {
      logout();
      return;
    }

    try {
      const response = await axiosInstance.post('/auth/refresh', { refreshToken });
      const { accessToken, refreshToken: newRefreshToken } = response.data.data;
      
      localStorage.setItem('token', accessToken);
      localStorage.setItem('refreshToken', newRefreshToken);
      console.log('[AUTH] Silent refresh executed successfully.');
    } catch (error) {
      console.error('[AUTH] Silent refresh failed:', error);
      logout();
    }
  };

  // Schedule timer to refresh every 14 minutes (since Access Token lives 15m)
  const scheduleSilentRefresh = () => {
    clearRefreshTimer();
    refreshTimerRef.current = setInterval(performSilentRefresh, 14 * 60 * 1000);
  };

  // Restore session on bootstrap
  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('token');
      const storedUser = localStorage.getItem('user');
      
      if (storedToken && storedUser) {
        try {
          setUser(JSON.parse(storedUser));
          scheduleSilentRefresh();
        } catch (e) {
          logout();
        }
      }
      setLoading(false);
    };

    initAuth();
    return () => clearRefreshTimer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async (email, password, rememberMe = false) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post('/auth/login', { email, password });
      const { accessToken, refreshToken, user: userData } = response.data.data;

      localStorage.setItem('token', accessToken);
      localStorage.setItem('refreshToken', refreshToken);
      localStorage.setItem('user', JSON.stringify(userData));
      
      // Store remember flag (optional)
      if (rememberMe) {
        localStorage.setItem('rememberedEmail', email);
      } else {
        localStorage.removeItem('rememberedEmail');
      }

      setUser(userData);
      scheduleSilentRefresh();
      return { success: true };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Login failed. Please verify credentials.',
      };
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    const refreshToken = localStorage.getItem('refreshToken');
    clearRefreshTimer();

    if (refreshToken) {
      try {
        await axiosInstance.post('/auth/logout', { refreshToken });
      } catch (e) {
        // Ignored during sign-out
      }
    }

    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    setUser(null);
  };

  const forgotPassword = async (email) => {
    try {
      const response = await axiosInstance.post('/auth/forgot-password', { email });
      return { 
        success: true, 
        resetToken: response.data.data?.resetToken 
      };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Failed to generate reset link.',
      };
    }
  };

  const resetPassword = async (token, password) => {
    try {
      await axiosInstance.post('/auth/reset-password', { token, password });
      return { success: true };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Failed to reset password.',
      };
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      login, 
      logout, 
      forgotPassword, 
      resetPassword,
      isAuthenticated: !!user 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
export default AuthContext;

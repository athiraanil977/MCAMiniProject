import axiosInstance from '../lib/axiosInstance';

const cleanParams = (params) => {
  const query = {};
  Object.keys(params || {}).forEach((key) => {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      query[key] = params[key];
    }
  });
  return query;
};

export const getAuditLogs = async (params) => {
  const response = await axiosInstance.get('/audit-logs', { params: cleanParams(params) });
  return response.data;
};

export const getAuditLogById = async (id) => {
  const response = await axiosInstance.get(`/audit-logs/${id}`);
  return response.data.data;
};

import axiosInstance from '../lib/axiosInstance';

const clean = (p) => {
  const q = {};
  Object.keys(p || {}).forEach((k) => {
    if (p[k] !== undefined && p[k] !== null && p[k] !== '') q[k] = p[k];
  });
  return q;
};

export const getUsers = async (params) => {
  const res = await axiosInstance.get('/users', { params: clean(params) });
  return res.data;
};

export const getUserById = async (id) => {
  const res = await axiosInstance.get(`/users/${id}`);
  return res.data.data;
};

export const createUser = async (data) => {
  const res = await axiosInstance.post('/users', data);
  return res.data.data;
};

export const updateUser = async (id, data) => {
  const res = await axiosInstance.put(`/users/${id}`, data);
  return res.data.data;
};

export const deleteUser = async (id) => {
  const res = await axiosInstance.delete(`/users/${id}`);
  return res.data;
};

export const activateUser = async (id) => {
  const res = await axiosInstance.post(`/users/${id}/activate`);
  return res.data;
};

export const deactivateUser = async (id) => {
  const res = await axiosInstance.post(`/users/${id}/deactivate`);
  return res.data;
};

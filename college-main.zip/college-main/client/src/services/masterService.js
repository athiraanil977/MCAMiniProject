import axiosInstance from '../lib/axiosInstance';

// Helper to format query parameters
const cleanParams = (params) => {
  const query = {};
  Object.keys(params || {}).forEach((key) => {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      query[key] = params[key];
    }
  });
  return query;
};

// =========================================================================
// Category APIs
// =========================================================================

export const getCategories = async (params) => {
  const response = await axiosInstance.get('/categories', { params: cleanParams(params) });
  return response.data;
};

export const createCategory = async (data) => {
  const response = await axiosInstance.post('/categories', data);
  return response.data;
};

export const updateCategory = async (id, data) => {
  const response = await axiosInstance.put(`/categories/${id}`, data);
  return response.data;
};

export const deleteCategory = async (id) => {
  const response = await axiosInstance.delete(`/categories/${id}`);
  return response.data;
};

export const restoreCategory = async (id) => {
  const response = await axiosInstance.patch(`/categories/${id}/restore`);
  return response.data;
};

// =========================================================================
// Location APIs
// =========================================================================

export const getLocations = async (params) => {
  const response = await axiosInstance.get('/locations', { params: cleanParams(params) });
  return response.data;
};

export const createLocation = async (data) => {
  const response = await axiosInstance.post('/locations', data);
  return response.data;
};

export const updateLocation = async (id, data) => {
  const response = await axiosInstance.put(`/locations/${id}`, data);
  return response.data;
};

export const deleteLocation = async (id) => {
  const response = await axiosInstance.delete(`/locations/${id}`);
  return response.data;
};

export const restoreLocation = async (id) => {
  const response = await axiosInstance.patch(`/locations/${id}/restore`);
  return response.data;
};

// =========================================================================
// Vendor APIs
// =========================================================================

export const getVendors = async (params) => {
  const response = await axiosInstance.get('/vendors', { params: cleanParams(params) });
  return response.data;
};

export const createVendor = async (data) => {
  const response = await axiosInstance.post('/vendors', data);
  return response.data;
};

export const updateVendor = async (id, data) => {
  const response = await axiosInstance.put(`/vendors/${id}`, data);
  return response.data;
};

export const deleteVendor = async (id) => {
  const response = await axiosInstance.delete(`/vendors/${id}`);
  return response.data;
};

export const restoreVendor = async (id) => {
  const response = await axiosInstance.patch(`/vendors/${id}/restore`);
  return response.data;
};

// =========================================================================
// Manufacturer APIs
// =========================================================================

export const getManufacturers = async (params) => {
  const response = await axiosInstance.get('/manufacturers', { params: cleanParams(params) });
  return response.data;
};

export const createManufacturer = async (data) => {
  const response = await axiosInstance.post('/manufacturers', data);
  return response.data;
};

export const updateManufacturer = async (id, data) => {
  const response = await axiosInstance.put(`/manufacturers/${id}`, data);
  return response.data;
};

export const deleteManufacturer = async (id) => {
  const response = await axiosInstance.delete(`/manufacturers/${id}`);
  return response.data;
};

export const restoreManufacturer = async (id) => {
  const response = await axiosInstance.patch(`/manufacturers/${id}/restore`);
  return response.data;
};

// =========================================================================
// Dashboard Metric APIs
// =========================================================================

export const getMasterMetrics = async () => {
  const response = await axiosInstance.get('/dashboard/master-metrics');
  return response.data.data;
};

// =========================================================================
// Department APIs
// =========================================================================

export const getDepartments = async () => {
  const response = await axiosInstance.get('/departments');
  return response.data;
};


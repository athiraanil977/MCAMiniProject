import axiosInstance from '../lib/axiosInstance';

export const getProfile = async () => {
  const response = await axiosInstance.get('/profile');
  return response.data.data;
};

export const updateProfile = async (payload) => {
  const response = await axiosInstance.put('/profile', payload);
  return response.data;
};

export const changePassword = async (payload) => {
  const response = await axiosInstance.put('/profile/change-password', payload);
  return response.data;
};

export const updatePreferences = async (payload) => {
  const response = await axiosInstance.put('/profile/preferences', payload);
  return response.data;
};

export const uploadProfilePhoto = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  const response = await axiosInstance.post('/profile/upload-photo', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  return response.data.data;
};
export const getSystemSettings = async () => {
  const response = await axiosInstance.get('/settings');
  return response.data.data;
};

export const updateSystemSettings = async (payload) => {
  const response = await axiosInstance.put('/settings', payload);
  return response.data;
};

import axiosInstance from '../lib/axiosInstance';

export const getDashboardSummary = async (bypass = false) => {
  const response = await axiosInstance.get('/dashboard/summary', {
    params: { bypass }
  });
  return response.data.data;
};

export const getDashboardCards = async () => {
  const response = await axiosInstance.get('/dashboard/cards');
  return response.data.data;
};

export const getDashboardCharts = async () => {
  const response = await axiosInstance.get('/dashboard/charts');
  return response.data.data;
};

export const getRecentActivities = async () => {
  const response = await axiosInstance.get('/dashboard/activity');
  return response.data.data;
};

import axiosInstance from '../lib/axiosInstance';

// Clean parameters helper
const cleanParams = (params) => {
  const query = {};
  Object.keys(params || {}).forEach((key) => {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      query[key] = params[key];
    }
  });
  return query;
};

// =========================================================================
// Core CRUD APIs
// =========================================================================

export const getAssets = async (params) => {
  const response = await axiosInstance.get('/assets', { params: cleanParams(params) });
  return response.data;
};

export const getAssetById = async (id) => {
  const response = await axiosInstance.get(`/assets/${id}`);
  return response.data.data;
};

export const createAsset = async (data) => {
  const response = await axiosInstance.post('/assets', data);
  return response.data;
};

export const updateAsset = async (id, data) => {
  const response = await axiosInstance.put(`/assets/${id}`, data);
  return response.data;
};

export const deleteAsset = async (id) => {
  const response = await axiosInstance.delete(`/assets/${id}`);
  return response.data;
};

export const restoreAsset = async (id) => {
  const response = await axiosInstance.patch(`/assets/${id}/restore`);
  return response.data;
};

// =========================================================================
// File Uploads
// =========================================================================

export const uploadAssetFile = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  
  const response = await axiosInstance.post('/assets/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  return response.data.data;
};

export const uploadAssetDocument = async (payload) => {
  const response = await axiosInstance.post(`/assets/${payload.assetId}/documents`, payload);
  return response.data;
};

// =========================================================================
// Lifecycle APIs
// =========================================================================

export const allocateAsset = async (payload) => {
  const response = await axiosInstance.post('/assets/allocate', payload);
  return response.data;
};

export const returnAsset = async (payload) => {
  const response = await axiosInstance.post('/assets/return', payload);
  return response.data;
};

export const transferAsset = async (payload) => {
  const response = await axiosInstance.post('/assets/transfer', payload);
  return response.data;
};

export const reserveAsset = async (payload) => {
  const response = await axiosInstance.post('/assets/reserve', payload);
  return response.data;
};

export const approveReservation = async (id, payload) => {
  const response = await axiosInstance.patch(`/assets/reservations/${id}/approve`, payload);
  return response.data;
};

export const disposeAsset = async (payload) => {
  const response = await axiosInstance.post('/assets/dispose', payload);
  return response.data;
};

// =========================================================================
// Dashboard Metric APIs
// =========================================================================

export const getAssetMetrics = async () => {
  const response = await axiosInstance.get('/dashboard/asset-metrics');
  return response.data.data;
};

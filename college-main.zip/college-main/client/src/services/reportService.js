import axiosInstance from '../lib/axiosInstance';

// Clean parameters helper
const cleanParams = (params) => {
  const query = {};
  Object.keys(params || {}).forEach((key) => {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      query[key] = params[key];
    }
  });
  return query;
};

export const getAssetsReport = async (filters) => {
  const response = await axiosInstance.get('/reports/assets', { params: cleanParams(filters) });
  return response.data.data;
};

export const getMaintenanceReport = async (filters) => {
  const response = await axiosInstance.get('/reports/maintenance', { params: cleanParams(filters) });
  return response.data.data;
};

export const getFinancialReport = async (filters) => {
  const response = await axiosInstance.get('/reports/financial', { params: cleanParams(filters) });
  return response.data.data;
};

export const saveReportConfig = async (payload) => {
  const response = await axiosInstance.post('/reports/save', payload);
  return response.data;
};

export const getSavedReportsList = async () => {
  const response = await axiosInstance.get('/reports/saved');
  return response.data.data;
};

export const exportReport = async (payload) => {
  const response = await axiosInstance.post('/reports/export', payload, {
    responseType: 'blob',
  });
  return response.data;
};
export const triggerDownload = (blob, filename) => {
  const url = window.URL.createObjectURL(new Blob([blob]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  link.parentNode.removeChild(link);
};

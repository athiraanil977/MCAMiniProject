import axiosInstance from '../lib/axiosInstance';

// Clean parameters helper
const cleanParams = (params) => {
  const query = {};
  Object.keys(params || {}).forEach((key) => {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      query[key] = params[key];
    }
  });
  return query;
};

// =========================================================================
// Maintenance Requests APIs
// =========================================================================

export const getRequests = async (params) => {
  const response = await axiosInstance.get('/maintenance/requests', { params: cleanParams(params) });
  return response.data;
};

export const getRequestById = async (id) => {
  const response = await axiosInstance.get(`/maintenance/requests/${id}`);
  return response.data.data;
};

export const createRequest = async (payload) => {
  const response = await axiosInstance.post('/maintenance/requests', payload);
  return response.data;
};

export const updateRequest = async (id, payload) => {
  const response = await axiosInstance.put(`/maintenance/requests/${id}`, payload);
  return response.data;
};

export const deleteRequest = async (id) => {
  const response = await axiosInstance.delete(`/maintenance/requests/${id}`);
  return response.data;
};

// =========================================================================
// Maintenance Record/Repairs APIs
// =========================================================================

export const getRecords = async (params) => {
  const response = await axiosInstance.get('/maintenance', { params: cleanParams(params) });
  return response.data;
};

export const getRecordById = async (id) => {
  const response = await axiosInstance.get(`/maintenance/${id}`);
  return response.data.data;
};

export const startRecord = async (payload) => {
  const response = await axiosInstance.post('/maintenance', payload);
  return response.data;
};

export const completeRecord = async (id, payload) => {
  const response = await axiosInstance.put(`/maintenance/${id}`, payload);
  return response.data;
};

export const deleteRecord = async (id) => {
  const response = await axiosInstance.delete(`/maintenance/${id}`);
  return response.data;
};

// =========================================================================
// Maintenance Schedule APIs
// =========================================================================

export const getSchedules = async (params) => {
  const response = await axiosInstance.get('/maintenance/schedules', { params: cleanParams(params) });
  return response.data;
};

export const getScheduleById = async (id) => {
  const response = await axiosInstance.get(`/maintenance/schedules/${id}`);
  return response.data.data;
};

export const createSchedule = async (payload) => {
  const response = await axiosInstance.post('/maintenance/schedules', payload);
  return response.data;
};

export const updateSchedule = async (id, payload) => {
  const response = await axiosInstance.put(`/maintenance/schedules/${id}`, payload);
  return response.data;
};

export const deleteSchedule = async (id) => {
  const response = await axiosInstance.delete(`/maintenance/schedules/${id}`);
  return response.data;
};

// =========================================================================
// Technician APIs
// =========================================================================

export const getTechnicians = async (params) => {
  const response = await axiosInstance.get('/technicians', { params: cleanParams(params) });
  return response.data;
};

export const getTechnicianById = async (id) => {
  const response = await axiosInstance.get(`/technicians/${id}`);
  return response.data.data;
};

export const createTechnician = async (payload) => {
  const response = await axiosInstance.post('/technicians', payload);
  return response.data;
};

export const updateTechnician = async (id, payload) => {
  const response = await axiosInstance.put(`/technicians/${id}`, payload);
  return response.data;
};

export const deleteTechnician = async (id) => {
  const response = await axiosInstance.delete(`/technicians/${id}`);
  return response.data;
};

// =========================================================================
// Maintenance Metrics APIs
// =========================================================================

export const getMaintenanceMetrics = async () => {
  const response = await axiosInstance.get('/maintenance/dashboard-metrics');
  return response.data.data;
};
export const uploadMaintenanceAttachment = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  const response = await axiosInstance.post('/assets/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  return response.data.data;
};
export const attachDocToRecord = async (maintenanceId, payload) => {
  const response = await axiosInstance.post(`/maintenance/${maintenanceId}/attachments`, payload);
  return response.data;
};

import axiosInstance from '../lib/axiosInstance';

export const getBackups = async (params) => {
  const response = await axiosInstance.get('/backups', { params });
  return response.data;
};

export const createBackup = async () => {
  const response = await axiosInstance.post('/backups');
  return response.data;
};

export const deleteBackup = async (id) => {
  const response = await axiosInstance.delete(`/backups/${id}`);
  return response.data;
};

export const getBackupDownloadUrl = (id) => {
  return `/api/backups/download/${id}`;
};

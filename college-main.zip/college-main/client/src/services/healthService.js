import axiosInstance from '../lib/axiosInstance';

export const getHealth = async () => {
  const response = await axiosInstance.get('/health');
  return response.data.data;
};

export const getDatabaseHealth = async () => {
  const response = await axiosInstance.get('/health/database');
  return response.data.data;
};

export const getStorageHealth = async () => {
  const response = await axiosInstance.get('/health/storage');
  return response.data.data;
};

export const getSystemHealth = async () => {
  const response = await axiosInstance.get('/health/system');
  return response.data.data;
};

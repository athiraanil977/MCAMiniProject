/**
 * Quick script to seed 5 sample assets into the database.
 * Run with: node seedAssets.mjs
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // ── Lookup IDs from existing seeded data ──────────────────────────────────
  const categories    = await prisma.assetCategory.findMany();
  const manufacturers = await prisma.manufacturer.findMany();
  const vendors       = await prisma.vendor.findMany();
  const locations     = await prisma.location.findMany();
  const departments   = await prisma.department.findMany();
  const conditions    = await prisma.condition.findMany();
  const statuses      = await prisma.assetStatus.findMany();
  const adminUser     = await prisma.user.findFirst({ where: { email: 'admin@college.com' } });

  if (!categories.length || !manufacturers.length || !vendors.length || !locations.length) {
    console.error('❌ Required seed data (categories/manufacturers/vendors/locations) not found.');
    console.error('   Please run the main seed first: npx prisma db seed');
    process.exit(1);
  }

  // Helper to find by name (case-insensitive partial match)
  const findId = (arr, nameField, keyword) => {
    const match = arr.find(x => x[nameField]?.toLowerCase().includes(keyword.toLowerCase()));
    return match?.id || arr[0].id;
  };

  const laptopCatId  = findId(categories,    'categoryName', 'Laptop');
  const projCatId    = findId(categories,    'categoryName', 'Projector');
  const tabletCatId  = findId(categories,    'categoryName', 'Tablet');
  const deskCatId    = findId(categories,    'categoryName', 'Desktop');
  const switchCatId  = findId(categories,    'categoryName', 'Switch');

  const dellMfgId    = findId(manufacturers, 'manufacturerName', 'Dell');
  const epsonMfgId   = findId(manufacturers, 'manufacturerName', 'Epson');
  const appleMfgId   = findId(manufacturers, 'manufacturerName', 'Apple');
  const hpMfgId      = findId(manufacturers, 'manufacturerName', 'HP');
  const ciscoMfgId   = findId(manufacturers, 'manufacturerName', 'Cisco');

  const dellVendId   = findId(vendors, 'vendorName', 'Dell');
  const epsonVendId  = findId(vendors, 'vendorName', 'Epson');
  const appleVendId  = findId(vendors, 'vendorName', 'Apple');
  const hpVendId     = findId(vendors, 'vendorName', 'HP');
  const ciscoVendId  = findId(vendors, 'vendorName', 'Cisco');

  const labLocId     = findId(locations,  'locationName', 'Computer Science Lab');
  const semLocId     = findId(locations,  'locationName', 'Seminar Hall A');
  const libLocId     = findId(locations,  'locationName', 'Library');
  const serverLocId  = findId(locations,  'locationName', 'Server Room');
  const storeLocId   = findId(locations,  'locationName', 'Store');

  const csDeptId     = findId(departments, 'departmentName', 'Computer Science');
  const availableId  = findId(statuses,    'statusName', 'Available');
  const goodCondId   = findId(conditions,  'conditionName', 'Good');
  const excellentId  = findId(conditions,  'conditionName', 'Excellent');

  const createdById  = adminUser?.id || null;

  // ── 5 Sample Assets ───────────────────────────────────────────────────────
  const assets = [
    {
      assetTag:     'AST-LAP-001',
      assetName:    'Dell Latitude 5540 Laptop',
      description:  '15.6" FHD laptop for CS Lab student use',
      serialNumber: 'DL5540-SN-00201',
      barcode:      'BC-AST-LAP-001',
      qrCode:       'QR-AST-LAP-001',
      categoryId:   laptopCatId,
      manufacturerId: dellMfgId,
      vendorId:     dellVendId,
      locationId:   labLocId,
      departmentId: csDeptId,
      purchaseDate: new Date('2024-01-15'),
      purchaseCost: 65000,
      warrantyStart: new Date('2024-01-15'),
      warrantyEnd:   new Date('2027-01-15'),
      model:        'Latitude 5540',
      brand:        'Dell',
      conditionId:  excellentId,
      statusId:     availableId,
      createdBy:    createdById,
    },
    {
      assetTag:     'AST-PRJ-001',
      assetName:    'Epson EB-X51 Projector',
      description:  '3LCD classroom projector for Seminar Hall A',
      serialNumber: 'EPEBX51-SN-00445',
      barcode:      'BC-AST-PRJ-001',
      qrCode:       'QR-AST-PRJ-001',
      categoryId:   projCatId,
      manufacturerId: epsonMfgId,
      vendorId:     epsonVendId,
      locationId:   semLocId,
      departmentId: csDeptId,
      purchaseDate: new Date('2023-06-10'),
      purchaseCost: 42000,
      warrantyStart: new Date('2023-06-10'),
      warrantyEnd:   new Date('2026-06-10'),
      model:        'EB-X51',
      brand:        'Epson',
      conditionId:  goodCondId,
      statusId:     availableId,
      createdBy:    createdById,
    },
    {
      assetTag:     'AST-TAB-001',
      assetName:    'Apple iPad 10th Gen',
      description:  'iPad for faculty digital presentations and annotation',
      serialNumber: 'APIPAD10-SN-00678',
      barcode:      'BC-AST-TAB-001',
      qrCode:       'QR-AST-TAB-001',
      categoryId:   tabletCatId,
      manufacturerId: appleMfgId,
      vendorId:     appleVendId,
      locationId:   libLocId,
      departmentId: csDeptId,
      purchaseDate: new Date('2024-03-20'),
      purchaseCost: 55000,
      warrantyStart: new Date('2024-03-20'),
      warrantyEnd:   new Date('2025-03-20'),
      model:        'iPad 10th Generation',
      brand:        'Apple',
      conditionId:  excellentId,
      statusId:     availableId,
      createdBy:    createdById,
    },
    {
      assetTag:     'AST-DSK-001',
      assetName:    'HP ProDesk 400 G9 Desktop',
      description:  'Core i5 desktop workstation for advanced programming lab',
      serialNumber: 'HPPD400-SN-01023',
      barcode:      'BC-AST-DSK-001',
      qrCode:       'QR-AST-DSK-001',
      categoryId:   deskCatId,
      manufacturerId: hpMfgId,
      vendorId:     hpVendId,
      locationId:   serverLocId,
      departmentId: csDeptId,
      purchaseDate: new Date('2023-11-05'),
      purchaseCost: 48000,
      warrantyStart: new Date('2023-11-05'),
      warrantyEnd:   new Date('2026-11-05'),
      model:        'ProDesk 400 G9',
      brand:        'HP',
      conditionId:  goodCondId,
      statusId:     availableId,
      createdBy:    createdById,
    },
    {
      assetTag:     'AST-SWT-001',
      assetName:    'Cisco Catalyst 2960X Switch',
      description:  '24-port managed switch for campus LAN',
      serialNumber: 'CSCAT2960X-SN-00312',
      barcode:      'BC-AST-SWT-001',
      qrCode:       'QR-AST-SWT-001',
      categoryId:   switchCatId,
      manufacturerId: ciscoMfgId,
      vendorId:     ciscoVendId,
      locationId:   serverLocId,
      departmentId: csDeptId,
      purchaseDate: new Date('2022-08-25'),
      purchaseCost: 78000,
      warrantyStart: new Date('2022-08-25'),
      warrantyEnd:   new Date('2025-08-25'),
      model:        'Catalyst 2960X-24TS-L',
      brand:        'Cisco',
      conditionId:  goodCondId,
      statusId:     availableId,
      createdBy:    createdById,
    },
  ];

  console.log('🌱 Seeding 5 assets...\n');
  let seeded = 0;

  for (const asset of assets) {
    try {
      const result = await prisma.asset.upsert({
        where: { assetTag: asset.assetTag },
        update: {},
        create: asset,
      });
      console.log(`  ✅ ${result.assetTag} — ${result.assetName}`);
      seeded++;
    } catch (err) {
      console.error(`  ❌ Failed: ${asset.assetTag} — ${err.message}`);
    }
  }

  console.log(`\n🎉 Done! ${seeded}/5 assets seeded successfully.`);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());

-- CreateTable
CREATE TABLE `assets` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetTag` VARCHAR(191) NOT NULL,
    `assetName` VARCHAR(191) NOT NULL,
    `description` VARCHAR(255) NULL,
    `serialNumber` VARCHAR(191) NOT NULL,
    `barcode` VARCHAR(191) NOT NULL,
    `qrCode` VARCHAR(191) NOT NULL,
    `categoryId` INTEGER NOT NULL,
    `manufacturerId` INTEGER NOT NULL,
    `vendorId` INTEGER NOT NULL,
    `departmentId` INTEGER NULL,
    `locationId` INTEGER NOT NULL,
    `purchaseDate` DATETIME(3) NULL,
    `purchaseCost` DECIMAL(10, 2) NULL,
    `invoiceNumber` VARCHAR(191) NULL,
    `invoiceFile` VARCHAR(255) NULL,
    `warrantyStart` DATETIME(3) NULL,
    `warrantyEnd` DATETIME(3) NULL,
    `model` VARCHAR(191) NULL,
    `brand` VARCHAR(191) NULL,
    `conditionId` INTEGER NOT NULL,
    `statusId` INTEGER NOT NULL,
    `assignedUserId` VARCHAR(191) NULL,
    `purchaseOrder` VARCHAR(191) NULL,
    `remarks` VARCHAR(255) NULL,
    `assetImage` VARCHAR(255) NULL,
    `createdBy` VARCHAR(191) NULL,
    `updatedBy` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,
    `deletedAt` DATETIME(3) NULL,

    UNIQUE INDEX `assets_assetTag_key`(`assetTag`),
    UNIQUE INDEX `assets_serialNumber_key`(`serialNumber`),
    UNIQUE INDEX `assets_barcode_key`(`barcode`),
    UNIQUE INDEX `assets_qrCode_key`(`qrCode`),
    INDEX `assets_categoryId_idx`(`categoryId`),
    INDEX `assets_manufacturerId_idx`(`manufacturerId`),
    INDEX `assets_vendorId_idx`(`vendorId`),
    INDEX `assets_departmentId_idx`(`departmentId`),
    INDEX `assets_locationId_idx`(`locationId`),
    INDEX `assets_statusId_idx`(`statusId`),
    INDEX `assets_conditionId_idx`(`conditionId`),
    INDEX `assets_deletedAt_idx`(`deletedAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `asset_allocations` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetId` INTEGER NOT NULL,
    `allocatedToUserId` VARCHAR(191) NULL,
    `allocatedDepartmentId` INTEGER NULL,
    `allocationDate` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `expectedReturnDate` DATETIME(3) NULL,
    `actualReturnDate` DATETIME(3) NULL,
    `purpose` VARCHAR(191) NULL,
    `remarks` VARCHAR(255) NULL,
    `status` VARCHAR(191) NOT NULL DEFAULT 'Allocated',
    `allocatedBy` VARCHAR(191) NULL,
    `returnedBy` VARCHAR(191) NULL,

    INDEX `asset_allocations_assetId_idx`(`assetId`),
    INDEX `asset_allocations_allocatedToUserId_idx`(`allocatedToUserId`),
    INDEX `asset_allocations_allocatedDepartmentId_idx`(`allocatedDepartmentId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `asset_transfers` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetId` INTEGER NOT NULL,
    `fromDepartmentId` INTEGER NULL,
    `toDepartmentId` INTEGER NULL,
    `fromLocationId` INTEGER NOT NULL,
    `toLocationId` INTEGER NOT NULL,
    `transferredBy` VARCHAR(191) NULL,
    `receivedBy` VARCHAR(191) NULL,
    `transferDate` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `reason` VARCHAR(191) NULL,
    `remarks` VARCHAR(255) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `asset_transfers_assetId_idx`(`assetId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `asset_reservations` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetId` INTEGER NOT NULL,
    `requestedBy` VARCHAR(191) NOT NULL,
    `reservationDate` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `reservationStart` DATETIME(3) NOT NULL,
    `reservationEnd` DATETIME(3) NOT NULL,
    `purpose` VARCHAR(191) NULL,
    `status` VARCHAR(191) NOT NULL DEFAULT 'Pending',
    `approvedBy` VARCHAR(191) NULL,
    `remarks` VARCHAR(255) NULL,

    INDEX `asset_reservations_assetId_idx`(`assetId`),
    INDEX `asset_reservations_requestedBy_idx`(`requestedBy`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `asset_disposals` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetId` INTEGER NOT NULL,
    `reason` VARCHAR(191) NOT NULL,
    `method` VARCHAR(191) NOT NULL,
    `approvedBy` VARCHAR(191) NULL,
    `disposalDate` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `remarks` VARCHAR(255) NULL,
    `documentPath` VARCHAR(255) NULL,

    INDEX `asset_disposals_assetId_idx`(`assetId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `asset_documents` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetId` INTEGER NOT NULL,
    `documentType` VARCHAR(191) NOT NULL,
    `fileName` VARCHAR(191) NOT NULL,
    `filePath` VARCHAR(255) NOT NULL,
    `uploadedBy` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `asset_documents_assetId_idx`(`assetId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `asset_histories` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetId` INTEGER NOT NULL,
    `action` VARCHAR(191) NOT NULL,
    `performedBy` VARCHAR(191) NULL,
    `oldValue` TEXT NULL,
    `newValue` TEXT NULL,
    `remarks` TEXT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `asset_histories_assetId_idx`(`assetId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `assets` ADD CONSTRAINT `assets_categoryId_fkey` FOREIGN KEY (`categoryId`) REFERENCES `asset_categories`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_manufacturerId_fkey` FOREIGN KEY (`manufacturerId`) REFERENCES `manufacturers`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_vendorId_fkey` FOREIGN KEY (`vendorId`) REFERENCES `vendors`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_departmentId_fkey` FOREIGN KEY (`departmentId`) REFERENCES `departments`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_locationId_fkey` FOREIGN KEY (`locationId`) REFERENCES `locations`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_conditionId_fkey` FOREIGN KEY (`conditionId`) REFERENCES `conditions`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_statusId_fkey` FOREIGN KEY (`statusId`) REFERENCES `asset_statuses`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_assignedUserId_fkey` FOREIGN KEY (`assignedUserId`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_createdBy_fkey` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `assets` ADD CONSTRAINT `assets_updatedBy_fkey` FOREIGN KEY (`updatedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `asset_allocations` ADD CONSTRAINT `asset_allocations_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `asset_allocations` ADD CONSTRAINT `asset_allocations_allocatedToUserId_fkey` FOREIGN KEY (`allocatedToUserId`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `asset_allocations` ADD CONSTRAINT `asset_allocations_allocatedDepartmentId_fkey` FOREIGN KEY (`allocatedDepartmentId`) REFERENCES `departments`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `asset_allocations` ADD CONSTRAINT `asset_allocations_allocatedBy_fkey` FOREIGN KEY (`allocatedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `asset_allocations` ADD CONSTRAINT `asset_allocations_returnedBy_fkey` FOREIGN KEY (`returnedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `asset_transfers` ADD CONSTRAINT `asset_transfers_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `asset_transfers` ADD CONSTRAINT `asset_transfers_fromDepartmentId_fkey` FOREIGN KEY (`fromDepartmentId`) REFERENCES `departments`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `asset_transfers` ADD CONSTRAINT `asset_transfers_toDepartmentId_fkey` FOREIGN KEY (`toDepartmentId`) REFERENCES `departments`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `asset_transfers` ADD CONSTRAINT `asset_transfers_fromLocationId_fkey` FOREIGN KEY (`fromLocationId`) REFERENCES `locations`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `asset_transfers` ADD CONSTRAINT `asset_transfers_toLocationId_fkey` FOREIGN KEY (`toLocationId`) REFERENCES `locations`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `asset_transfers` ADD CONSTRAINT `asset_transfers_transferredBy_fkey` FOREIGN KEY (`transferredBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `asset_transfers` ADD CONSTRAINT `asset_transfers_receivedBy_fkey` FOREIGN KEY (`receivedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `asset_reservations` ADD CONSTRAINT `asset_reservations_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `asset_reservations` ADD CONSTRAINT `asset_reservations_requestedBy_fkey` FOREIGN KEY (`requestedBy`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `asset_reservations` ADD CONSTRAINT `asset_reservations_approvedBy_fkey` FOREIGN KEY (`approvedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `asset_disposals` ADD CONSTRAINT `asset_disposals_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `asset_disposals` ADD CONSTRAINT `asset_disposals_approvedBy_fkey` FOREIGN KEY (`approvedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `asset_documents` ADD CONSTRAINT `asset_documents_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `asset_documents` ADD CONSTRAINT `asset_documents_uploadedBy_fkey` FOREIGN KEY (`uploadedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `asset_histories` ADD CONSTRAINT `asset_histories_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `asset_histories` ADD CONSTRAINT `asset_histories_performedBy_fkey` FOREIGN KEY (`performedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

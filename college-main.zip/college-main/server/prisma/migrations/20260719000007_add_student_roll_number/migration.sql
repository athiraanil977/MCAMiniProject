-- AlterTable: Add rollNumber column to users
ALTER TABLE `users` ADD COLUMN `rollNumber` VARCHAR(191) NULL;

-- CreateIndex: Unique constraint on rollNumber
CREATE UNIQUE INDEX `users_rollNumber_key` ON `users`(`rollNumber`);

-- CreateIndex: Regular index on rollNumber for fast lookups
CREATE INDEX `users_rollNumber_idx` ON `users`(`rollNumber`);

-- CreateTable
CREATE TABLE `maintenance_requests` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `requestNumber` VARCHAR(191) NOT NULL,
    `assetId` INTEGER NOT NULL,
    `requestedBy` VARCHAR(191) NOT NULL,
    `departmentId` INTEGER NULL,
    `priority` VARCHAR(191) NOT NULL DEFAULT 'Low',
    `problemTitle` VARCHAR(191) NOT NULL,
    `problemDescription` TEXT NULL,
    `reportedDate` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `status` VARCHAR(191) NOT NULL DEFAULT 'Open',
    `assignedTechnician` INTEGER NULL,
    `remarks` VARCHAR(255) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `maintenance_requests_requestNumber_key`(`requestNumber`),
    INDEX `maintenance_requests_assetId_idx`(`assetId`),
    INDEX `maintenance_requests_requestedBy_idx`(`requestedBy`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `maintenance_records` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `maintenanceNumber` VARCHAR(191) NOT NULL,
    `assetId` INTEGER NOT NULL,
    `requestId` INTEGER NULL,
    `maintenanceType` VARCHAR(191) NOT NULL DEFAULT 'Corrective',
    `performedBy` VARCHAR(191) NULL,
    `vendorId` INTEGER NULL,
    `technicianName` VARCHAR(191) NULL,
    `startDate` DATETIME(3) NOT NULL,
    `endDate` DATETIME(3) NULL,
    `cost` DECIMAL(10, 2) NULL,
    `labourCost` DECIMAL(10, 2) NULL,
    `partsCost` DECIMAL(10, 2) NULL,
    `downtimeHours` DOUBLE NULL,
    `maintenanceDescription` TEXT NULL,
    `resolution` TEXT NULL,
    `status` VARCHAR(191) NOT NULL DEFAULT 'Scheduled',
    `invoiceFile` VARCHAR(255) NULL,
    `remarks` VARCHAR(255) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `maintenance_records_maintenanceNumber_key`(`maintenanceNumber`),
    INDEX `maintenance_records_assetId_idx`(`assetId`),
    INDEX `maintenance_records_requestId_idx`(`requestId`),
    INDEX `maintenance_records_vendorId_idx`(`vendorId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `maintenance_schedules` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `assetId` INTEGER NOT NULL,
    `scheduleName` VARCHAR(191) NOT NULL,
    `maintenanceType` VARCHAR(191) NOT NULL,
    `frequency` VARCHAR(191) NOT NULL,
    `nextMaintenanceDate` DATETIME(3) NOT NULL,
    `lastMaintenanceDate` DATETIME(3) NULL,
    `assignedTechnician` INTEGER NULL,
    `vendorId` INTEGER NULL,
    `isActive` BOOLEAN NOT NULL DEFAULT true,
    `remarks` VARCHAR(255) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    INDEX `maintenance_schedules_assetId_idx`(`assetId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `maintenance_parts` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `maintenanceId` INTEGER NOT NULL,
    `partName` VARCHAR(191) NOT NULL,
    `quantity` INTEGER NOT NULL,
    `unitCost` DECIMAL(10, 2) NOT NULL,
    `totalCost` DECIMAL(10, 2) NOT NULL,

    INDEX `maintenance_parts_maintenanceId_idx`(`maintenanceId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `technicians` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `employeeId` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `phone` VARCHAR(191) NULL,
    `specialization` VARCHAR(191) NULL,
    `isInternal` BOOLEAN NOT NULL DEFAULT true,
    `vendorId` INTEGER NULL,
    `status` VARCHAR(191) NOT NULL DEFAULT 'Active',
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `technicians_employeeId_key`(`employeeId`),
    INDEX `technicians_vendorId_idx`(`vendorId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `maintenance_attachments` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `maintenanceId` INTEGER NOT NULL,
    `fileName` VARCHAR(191) NOT NULL,
    `filePath` VARCHAR(255) NOT NULL,
    `documentType` VARCHAR(191) NOT NULL,
    `uploadedBy` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `maintenance_attachments_maintenanceId_idx`(`maintenanceId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `maintenance_requests` ADD CONSTRAINT `maintenance_requests_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `maintenance_requests` ADD CONSTRAINT `maintenance_requests_requestedBy_fkey` FOREIGN KEY (`requestedBy`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `maintenance_requests` ADD CONSTRAINT `maintenance_requests_departmentId_fkey` FOREIGN KEY (`departmentId`) REFERENCES `departments`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `maintenance_requests` ADD CONSTRAINT `maintenance_requests_assignedTechnician_fkey` FOREIGN KEY (`assignedTechnician`) REFERENCES `technicians`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `maintenance_records` ADD CONSTRAINT `maintenance_records_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `maintenance_records` ADD CONSTRAINT `maintenance_records_requestId_fkey` FOREIGN KEY (`requestId`) REFERENCES `maintenance_requests`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `maintenance_records` ADD CONSTRAINT `maintenance_records_vendorId_fkey` FOREIGN KEY (`vendorId`) REFERENCES `vendors`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `maintenance_schedules` ADD CONSTRAINT `maintenance_schedules_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `maintenance_schedules` ADD CONSTRAINT `maintenance_schedules_assignedTechnician_fkey` FOREIGN KEY (`assignedTechnician`) REFERENCES `technicians`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `maintenance_schedules` ADD CONSTRAINT `maintenance_schedules_vendorId_fkey` FOREIGN KEY (`vendorId`) REFERENCES `vendors`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `maintenance_parts` ADD CONSTRAINT `maintenance_parts_maintenanceId_fkey` FOREIGN KEY (`maintenanceId`) REFERENCES `maintenance_records`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `technicians` ADD CONSTRAINT `technicians_vendorId_fkey` FOREIGN KEY (`vendorId`) REFERENCES `vendors`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `maintenance_attachments` ADD CONSTRAINT `maintenance_attachments_maintenanceId_fkey` FOREIGN KEY (`maintenanceId`) REFERENCES `maintenance_records`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `maintenance_attachments` ADD CONSTRAINT `maintenance_attachments_uploadedBy_fkey` FOREIGN KEY (`uploadedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

const defaultRoles = [
  { roleName: 'Super Admin', description: 'Super Administrator with full system control' },
  { roleName: 'Asset Manager', description: 'Manages institution assets, vendors, and allocations' },
  { roleName: 'Department Staff', description: 'Department representatives managing local assets' },
  { roleName: 'Faculty', description: 'Educators utilizing and leasing college assets' },
  { roleName: 'Lab Assistant', description: 'Oversees specific laboratory equipments and stock' },
  { roleName: 'Store Keeper', description: 'Manages warehouses and inventory items' },
  { roleName: 'Viewer', description: 'Read-only access across asset catalogs' },
  { roleName: 'Student', description: 'Student who can view and request/lease assets' },
];

const defaultDepartments = [
  { departmentName: 'Computer Science', departmentCode: 'CS', description: 'Department of Computer Science & Engineering' },
  { departmentName: 'Mechanical', departmentCode: 'ME', description: 'Department of Mechanical Engineering' },
  { departmentName: 'Civil', departmentCode: 'CE', description: 'Department of Civil Engineering' },
  { departmentName: 'Electronics', departmentCode: 'EC', description: 'Department of Electronics & Communication' },
  { departmentName: 'Library', departmentCode: 'LIB', description: 'Central College Library' },
  { departmentName: 'Administration', departmentCode: 'ADM', description: 'College Executive & Administrative Office' },
  { departmentName: 'Accounts', departmentCode: 'ACC', description: 'Finance & Treasury Department' },
  { departmentName: 'Office', departmentCode: 'OFF', description: 'General College Office' },
  { departmentName: 'Store', departmentCode: 'STR', description: 'Central Inventory Storage Warehouse' },
];

const defaultPermissions = [
  { permissionName: 'manage_users', module: 'users', description: 'Create, update, deactivate, and soft-delete user accounts' },
  { permissionName: 'view_users', module: 'users', description: 'View user directories and assignment records' },
  { permissionName: 'manage_roles', module: 'roles', description: 'Configure system roles and permission mapping rules' },
  { permissionName: 'manage_permissions', module: 'permissions', description: 'Edit individual granular access nodes' },
  { permissionName: 'manage_assets', module: 'assets', description: 'Full CRUD control over institution assets catalog' },
  { permissionName: 'view_assets', module: 'assets', description: 'View assets catalog and loan statuses' },
  { permissionName: 'manage_maintenance', module: 'maintenance', description: 'Create and update repair audit tickets' },
  { permissionName: 'view_reports', module: 'reports', description: 'Access and export asset compliance reports' },
];

// Conditions & Statuses
const defaultConditions = [
  { conditionName: 'Excellent' },
  { conditionName: 'Good' },
  { conditionName: 'Fair' },
  { conditionName: 'Damaged' },
  { conditionName: 'Needs Repair' },
  { conditionName: 'Disposed' },
];

const defaultStatuses = [
  { statusName: 'Available' },
  { statusName: 'Allocated' },
  { statusName: 'Maintenance' },
  { statusName: 'Repair' },
  { statusName: 'Lost' },
  { statusName: 'Disposed' },
  { statusName: 'Reserved' },
];

// 20 Categories
const defaultCategories = [
  { categoryCode: 'LAP', categoryName: 'Laptops', description: 'Portable workstations & laptops', icon: 'Laptop' },
  { categoryCode: 'DSK', categoryName: 'Desktops', description: 'Standard desktop towers', icon: 'Monitor' },
  { categoryCode: 'SRV', categoryName: 'Servers', description: 'Rackmount and tower network servers', icon: 'Server' },
  { categoryCode: 'PRN', categoryName: 'Printers', description: 'Network laserjet printers & scanners', icon: 'Printer' },
  { categoryCode: 'SWT', categoryName: 'Switches', description: 'Layer 2 and Layer 3 Ethernet switches', icon: 'Wifi' },
  { categoryCode: 'RTR', categoryName: 'Routers', description: 'Enterprise core routers', icon: 'Network' },
  { categoryCode: 'SMB', categoryName: 'Smart Boards', description: 'Interactive classroom smart displays', icon: 'Presentation' },
  { categoryCode: 'PRO', categoryName: 'Projectors', description: 'Ceiling mount classroom projectors', icon: 'Tv' },
  { categoryCode: 'UPS', categoryName: 'UPS Systems', description: 'Uninterruptible power supplies & batteries', icon: 'BatteryCharging' },
  { categoryCode: 'CCT', categoryName: 'CCTV Cameras', description: 'Security and IP monitoring cameras', icon: 'Camera' },
  { categoryCode: 'TAB', categoryName: 'Tablets', description: 'Mobile tablet devices', icon: 'Tablet' },
  { categoryCode: 'MIC', categoryName: 'Microscopes', description: 'Lab optical microscopes', icon: 'Microscope' },
  { categoryCode: 'CHG', categoryName: 'Chairs', description: 'Ergonomic chairs & office seating', icon: 'Sofa' },
  { categoryCode: 'TBL', categoryName: 'Tables', description: 'Classroom and computer desks', icon: 'Table' },
  { categoryCode: 'AIR', categoryName: 'Air Conditioners', description: 'Split and window cooling systems', icon: 'Wind' },
  { categoryCode: 'OSC', categoryName: 'Oscilloscopes', description: 'Lab frequency measurement units', icon: 'Activity' },
  { categoryCode: 'SCN', categoryName: 'Scanners', description: 'Document sheet-fed scanners', icon: 'Scan' },
  { categoryCode: 'SPK', categoryName: 'Speakers', description: 'Seminar hall PA speaker systems', icon: 'Volume2' },
  { categoryCode: 'AUD', categoryName: 'Audiometers', description: 'Lab hearing measurement devices', icon: 'Hearing' },
  { categoryCode: 'OTH', categoryName: 'Other Assets', description: 'Miscellaneous asset registers', icon: 'Package' },
];

// 20 Locations
const defaultLocations = [
  { locationCode: 'LOC-ADM-F1', locationName: 'Main Administration Office', building: 'Admin Block', floor: '1st Floor', roomNumber: '101', description: 'Executive suites & registrations' },
  { locationCode: 'LOC-CS-L1', locationName: 'Computer Science Lab 1', building: 'Engineering Block', floor: 'Basement', roomNumber: 'B08', description: 'General computer lab' },
  { locationCode: 'LOC-CS-L2', locationName: 'Advanced Programming Lab', building: 'Engineering Block', floor: '1st Floor', roomNumber: '102', description: 'Post-graduate lab coding hub' },
  { locationCode: 'LOC-CS-SR', locationName: 'Department Server Room', building: 'Engineering Block', floor: '1st Floor', roomNumber: '104', description: 'Department local servers' },
  { locationCode: 'LOC-ME-L1', locationName: 'Thermal Engineering Lab', building: 'Mechanical Workshop', floor: 'Ground Floor', roomNumber: 'G02', description: 'Thermal chambers and setups' },
  { locationCode: 'LOC-ME-L2', locationName: 'Fluid Mechanics Lab', building: 'Mechanical Workshop', floor: 'Ground Floor', roomNumber: 'G03', description: 'Flow tables & hydraulic turbines' },
  { locationCode: 'LOC-CE-L1', locationName: 'Geotechnical Engineering Lab', building: 'Civil Block', floor: 'Ground Floor', roomNumber: 'G05', description: 'Soil testing setups' },
  { locationCode: 'LOC-EC-L1', locationName: 'Microprocessor Lab', building: 'Electronics Block', floor: '2nd Floor', roomNumber: '202', description: '8086 kits and logic analysers' },
  { locationCode: 'LOC-EC-L2', locationName: 'Embedded Systems Lab', building: 'Electronics Block', floor: '2nd Floor', roomNumber: '204', description: 'ARM boards & IoT setups' },
  { locationCode: 'LOC-LIB-M', locationName: 'Central Library Main Hall', building: 'Central Block', floor: 'Ground Floor', roomNumber: 'LIB-G', description: 'Book catalogs & study desks' },
  { locationCode: 'LOC-LIB-D', locationName: 'Central Library Digital Archive', building: 'Central Block', floor: '1st Floor', roomNumber: 'LIB-D1', description: 'Online catalogs & e-journals access' },
  { locationCode: 'LOC-SEM-A', locationName: 'Seminar Hall A', building: 'Central Block', floor: '2nd Floor', roomNumber: '201', description: 'Conference & speaker events' },
  { locationCode: 'LOC-SEM-B', locationName: 'Seminar Hall B', building: 'Central Block', floor: '2nd Floor', roomNumber: '203', description: 'Interactive workshop hall' },
  { locationCode: 'LOC-STR-M', locationName: 'Main Store Room', building: 'Store Complex', floor: 'Ground Floor', roomNumber: 'S01', description: 'Central inventory supplies storage' },
  { locationCode: 'LOC-STR-L', locationName: 'IT Spare Storage', building: 'Store Complex', floor: '1st Floor', roomNumber: 'S04', description: 'RAM, HDD, cable roll vaults' },
  { locationCode: 'LOC-PRN-O', locationName: 'Principal Executive Office', building: 'Admin Block', floor: '2nd Floor', roomNumber: '201-P', description: 'Principal office chambers' },
  { locationCode: 'LOC-HST-A', locationName: 'Hostel A Study Room', building: 'Boys Hostel A', floor: 'Ground Floor', roomNumber: 'A10', description: 'Student computing center' },
  { locationCode: 'LOC-CR-3A', locationName: 'Lecture Classroom 3A', building: 'Arts Block', floor: '3rd Floor', roomNumber: '301', description: 'General learning lecture hall' },
  { locationCode: 'LOC-CR-3B', locationName: 'Lecture Classroom 3B', building: 'Arts Block', floor: '3rd Floor', roomNumber: '302', description: 'General learning lecture hall' },
  { locationCode: 'LOC-AUD-M', locationName: 'Main Auditorium', building: 'Central Block', floor: 'Ground Floor', roomNumber: 'AUD-01', description: 'Major conventions & assembly halls' },
];

// 10 Vendors
const defaultVendors = [
  { vendorCode: 'VND-DELL', vendorName: 'Dell Technologies Inc', contactPerson: 'Michael Sales', email: 'edu.sales@dell.com', phone: '+18004563355', gstNumber: '29AAAAA0000A1Z1', address: 'Dell Way, Round Rock', city: 'Austin', state: 'Texas', country: 'USA', postalCode: '78682', website: 'https://dell.com' },
  { vendorCode: 'VND-CSCO', vendorName: 'Cisco Systems India', contactPerson: 'Rajiv Networking', email: 'govt.sales@cisco.com', phone: '+918041593000', gstNumber: '29BBBBB0000B1Z2', address: 'Outer Ring Road', city: 'Bengaluru', state: 'Karnataka', country: 'India', postalCode: '560103', website: 'https://cisco.com' },
  { vendorCode: 'VND-APPL', vendorName: 'Apple India Pvt Ltd', contactPerson: 'Steve Jobs Sales', email: 'edu_channels@apple.com', phone: '+18006927753', gstNumber: '29CCCCC0000C1Z3', address: 'UB City, Vittal Mallya Road', city: 'Bengaluru', state: 'Karnataka', country: 'India', postalCode: '560001', website: 'https://apple.com' },
  { vendorCode: 'VND-TSFC', vendorName: 'Thermo Fisher Scientific', contactPerson: 'Dr. Jane Lab', email: 'sales.lab@thermofisher.com', phone: '+18007667000', gstNumber: '29DDDDD0000D1Z4', address: 'Wyman Street', city: 'Waltham', state: 'Massachusetts', country: 'USA', postalCode: '02451', website: 'https://thermofisher.com' },
  { vendorCode: 'VND-STLC', vendorName: 'Steelcase Furniture Hub', contactPerson: 'Charles Steel', email: 'info@steelcase.com', phone: '+18887833522', gstNumber: '29EEEEE0000E1Z5', address: '901 44th St SE', city: 'Grand Rapids', state: 'Michigan', country: 'USA', postalCode: '49508', website: 'https://steelcase.com' },
  { vendorCode: 'VND-EPSN', vendorName: 'Epson India Private Ltd', contactPerson: 'Kumar Ink', email: 'channels@epson.co.in', phone: '+918030515000', gstNumber: '29FFFFF0000F1Z6', address: 'Richmond Road', city: 'Bengaluru', state: 'Karnataka', country: 'India', postalCode: '560025', website: 'https://epson.co.in' },
  { vendorCode: 'VND-SMSN', vendorName: 'Samsung Electronics', contactPerson: 'Hwang Display', email: 'b2b.display@samsung.com', phone: '+18007267864', gstNumber: '29GGGGG0000G1Z7', address: 'Samsung IT Park', city: 'Seoul', state: 'Gyeonggi', country: 'South Korea', postalCode: '06633', website: 'https://samsung.com' },
  { vendorCode: 'VND-HPIN', vendorName: 'HP India Sales', contactPerson: 'Aman Print', email: 'india.edu@hp.com', phone: '+911244835000', gstNumber: '29HHHHH0000H1Z8', address: 'Cyber City, Phase 3', city: 'Gurugram', state: 'Haryana', country: 'India', postalCode: '122002', website: 'https://hp.com' },
  { vendorCode: 'VND-LNVO', vendorName: 'Lenovo PC International', contactPerson: 'Yang Laptop', email: 'sales.commercial@lenovo.com', phone: '+18552536686', gstNumber: '29IIIII0000I1Z9', address: 'Lenovo Circle', city: 'Morrisville', state: 'North Carolina', country: 'USA', postalCode: '27560', website: 'https://lenovo.com' },
  { vendorCode: 'VND-LGEC', vendorName: 'LG B2B Solutions', contactPerson: 'Park Cool', email: 'ac.commercial@lg.com', phone: '+18888653026', gstNumber: '29JJJJJ0000J1ZA', address: 'LG Twin Towers', city: 'Seoul', state: 'Gyeonggi', country: 'South Korea', postalCode: '07336', website: 'https://lg.com' },
];

// 10 Manufacturers
const defaultManufacturers = [
  { manufacturerCode: 'MFG-DELL', manufacturerName: 'Dell Technologies', website: 'https://dell.com', supportEmail: 'support@dell.com', supportPhone: '+18004563355', description: 'Computing, displays, enterprise servers' },
  { manufacturerCode: 'MFG-CSCO', manufacturerName: 'Cisco Systems', website: 'https://cisco.com', supportEmail: 'support@cisco.com', supportPhone: '+18005536387', description: 'Enterprise routing, switching, access points' },
  { manufacturerCode: 'MFG-APPL', manufacturerName: 'Apple Inc', website: 'https://apple.com', supportEmail: 'support@apple.com', supportPhone: '+18002752273', description: 'MacBooks, iPads, mobile devices' },
  { manufacturerCode: 'MFG-THRM', manufacturerName: 'Thermo Fisher Scientific', website: 'https://thermofisher.com', supportEmail: 'support@thermofisher.com', supportPhone: '+18007667000', description: 'Laboratory analysis & spectrophotometers' },
  { manufacturerCode: 'MFG-STLC', manufacturerName: 'Steelcase', website: 'https://steelcase.com', supportEmail: 'support@steelcase.com', supportPhone: '+18887833522', description: 'Academic and office desk and chair furniture' },
  { manufacturerCode: 'MFG-EPSN', manufacturerName: 'Epson', website: 'https://epson.com', supportEmail: 'support@epson.com', supportPhone: '+18004637766', description: 'Projectors, receipt printers, document scanners' },
  { manufacturerCode: 'MFG-SMSG', manufacturerName: 'Samsung Electronics', website: 'https://samsung.com', supportEmail: 'support@samsung.com', supportPhone: '+18007267864', description: 'LED Smartboards, commercial monitors, tablets' },
  { manufacturerCode: 'MFG-HP', manufacturerName: 'HP Inc', website: 'https://hp.com', supportEmail: 'support@hp.com', supportPhone: '+18004746836', description: 'Laserjet printers, computing, hardware accessories' },
  { manufacturerCode: 'MFG-LNVO', manufacturerName: 'Lenovo Group', website: 'https://lenovo.com', supportEmail: 'support@lenovo.com', supportPhone: '+18552536686', description: 'ThinkPad laptops, desktops, workstations' },
  { manufacturerCode: 'MFG-LG', manufacturerName: 'LG Electronics', website: 'https://lg.com', supportEmail: 'support@lg.com', supportPhone: '+18002430000', description: 'Air conditioning systems, displays, signage' },
];

async function main() {
  console.log('Seeding Database...');

  // 1. Seed Roles
  const rolesMap = {};
  for (const role of defaultRoles) {
    const created = await prisma.role.upsert({
      where: { roleName: role.roleName },
      update: {},
      create: role,
    });
    rolesMap[created.roleName] = created.id;
  }
  console.log('Roles seeded.');

  // 2. Seed Departments
  const deptsMap = {};
  for (const dept of defaultDepartments) {
    const created = await prisma.department.upsert({
      where: { departmentName: dept.departmentName },
      update: {},
      create: dept,
    });
    deptsMap[created.departmentName] = created.id;
  }
  console.log('Departments seeded.');

  // 3. Seed Permissions
  const permissionsMap = {};
  for (const perm of defaultPermissions) {
    const created = await prisma.permission.upsert({
      where: { permissionName: perm.permissionName },
      update: {},
      create: perm,
    });
    permissionsMap[created.permissionName] = created.id;
  }
  console.log('Permissions seeded.');

  // 4. Seed Role Permissions
  for (const permId of Object.values(permissionsMap)) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: rolesMap['Super Admin'],
          permissionId: permId,
        },
      },
      update: {},
      create: {
        roleId: rolesMap['Super Admin'],
        permissionId: permId,
      },
    });
  }

  const managerPerms = ['view_users', 'manage_assets', 'view_assets', 'manage_maintenance', 'view_reports'];
  for (const name of managerPerms) {
    if (permissionsMap[name]) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: rolesMap['Asset Manager'],
            permissionId: permissionsMap[name],
          },
        },
        update: {},
        create: {
          roleId: rolesMap['Asset Manager'],
          permissionId: permissionsMap[name],
        },
      });
    }
  }

  const viewerPerms = ['view_users', 'view_assets'];
  for (const name of viewerPerms) {
    if (permissionsMap[name]) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: rolesMap['Viewer'],
            permissionId: permissionsMap[name],
          },
        },
        update: {},
        create: {
          roleId: rolesMap['Viewer'],
          permissionId: permissionsMap[name],
        },
      });
    }
  }

  // Student: view_assets only
  const studentPerms = ['view_assets'];
  for (const name of studentPerms) {
    if (permissionsMap[name]) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: rolesMap['Student'],
            permissionId: permissionsMap[name],
          },
        },
        update: {},
        create: {
          roleId: rolesMap['Student'],
          permissionId: permissionsMap[name],
        },
      });
    }
  }
  console.log('RolePermissions configured.');

  // 5. Seed Super Admin User
  const adminEmail = 'admin@college.com';
  const hashedPassword = await bcrypt.hash('Admin@123', 10);

  const adminUser = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      name: 'Super Administrator',
      email: adminEmail,
      password: hashedPassword,
      employeeId: 'EMP-ADM-0001',
      phone: '+15550199',
      roleId: rolesMap['Super Admin'],
      departmentId: deptsMap['Administration'],
      status: 'ACTIVE',
    },
  });
  console.log('Super Admin user created.');

  // 5b. Seed Sample Users (all roles)
  const samplePassword = await bcrypt.hash('Staff@123', 10);

  const sampleUsers = [
    // Asset Managers
    { employeeId: 'EMP-AM-0001', name: 'Rajesh Kumar', email: 'rajesh.kumar@college.com', phone: '+15550101', roleId: rolesMap['Asset Manager'], departmentId: deptsMap['Administration'] },
    { employeeId: 'EMP-AM-0002', name: 'Priya Sharma', email: 'priya.sharma@college.com', phone: '+15550102', roleId: rolesMap['Asset Manager'], departmentId: deptsMap['Accounts'] },

    // Department Staff
    { employeeId: 'EMP-CS-0001', name: 'Arun Mehta', email: 'arun.mehta@college.com', phone: '+15550103', roleId: rolesMap['Department Staff'], departmentId: deptsMap['Computer Science'] },
    { employeeId: 'EMP-ME-0001', name: 'Sunita Patel', email: 'sunita.patel@college.com', phone: '+15550104', roleId: rolesMap['Department Staff'], departmentId: deptsMap['Mechanical'] },
    { employeeId: 'EMP-CE-0001', name: 'Vikram Singh', email: 'vikram.singh@college.com', phone: '+15550105', roleId: rolesMap['Department Staff'], departmentId: deptsMap['Civil'] },
    { employeeId: 'EMP-EC-0001', name: 'Kavya Nair', email: 'kavya.nair@college.com', phone: '+15550106', roleId: rolesMap['Department Staff'], departmentId: deptsMap['Electronics'] },

    // Faculty
    { employeeId: 'EMP-FAC-0001', name: 'Dr. Anand Krishnan', email: 'anand.krishnan@college.com', phone: '+15550107', roleId: rolesMap['Faculty'], departmentId: deptsMap['Computer Science'] },
    { employeeId: 'EMP-FAC-0002', name: 'Prof. Meena Iyer', email: 'meena.iyer@college.com', phone: '+15550108', roleId: rolesMap['Faculty'], departmentId: deptsMap['Electronics'] },
    { employeeId: 'EMP-FAC-0003', name: 'Dr. Ramesh Gupta', email: 'ramesh.gupta@college.com', phone: '+15550109', roleId: rolesMap['Faculty'], departmentId: deptsMap['Mechanical'] },
    { employeeId: 'EMP-FAC-0004', name: 'Prof. Divya Reddy', email: 'divya.reddy@college.com', phone: '+15550110', roleId: rolesMap['Faculty'], departmentId: deptsMap['Civil'] },
    { employeeId: 'EMP-FAC-0005', name: 'Dr. Suresh Babu', email: 'suresh.babu@college.com', phone: '+15550111', roleId: rolesMap['Faculty'], departmentId: deptsMap['Computer Science'] },

    // Lab Assistants
    { employeeId: 'EMP-LAB-0001', name: 'Kiran Desai', email: 'kiran.desai@college.com', phone: '+15550112', roleId: rolesMap['Lab Assistant'], departmentId: deptsMap['Computer Science'] },
    { employeeId: 'EMP-LAB-0002', name: 'Sneha Joshi', email: 'sneha.joshi@college.com', phone: '+15550113', roleId: rolesMap['Lab Assistant'], departmentId: deptsMap['Electronics'] },
    { employeeId: 'EMP-LAB-0003', name: 'Mohan Pillai', email: 'mohan.pillai@college.com', phone: '+15550114', roleId: rolesMap['Lab Assistant'], departmentId: deptsMap['Mechanical'] },
    { employeeId: 'EMP-LAB-0004', name: 'Anita Rao', email: 'anita.rao@college.com', phone: '+15550115', roleId: rolesMap['Lab Assistant'], departmentId: deptsMap['Civil'] },

    // Store Keepers
    { employeeId: 'EMP-STR-0001', name: 'Bala Murugan', email: 'bala.murugan@college.com', phone: '+15550116', roleId: rolesMap['Store Keeper'], departmentId: deptsMap['Store'] },
    { employeeId: 'EMP-STR-0002', name: 'Rekha Varma', email: 'rekha.varma@college.com', phone: '+15550117', roleId: rolesMap['Store Keeper'], departmentId: deptsMap['Store'] },

    // Viewers
    { employeeId: 'EMP-VW-0001', name: 'Harish Nambiar', email: 'harish.nambiar@college.com', phone: '+15550118', roleId: rolesMap['Viewer'], departmentId: deptsMap['Library'] },
    { employeeId: 'EMP-VW-0002', name: 'Latha Menon', email: 'latha.menon@college.com', phone: '+15550119', roleId: rolesMap['Viewer'], departmentId: deptsMap['Accounts'] },
    { employeeId: 'EMP-VW-0003', name: 'Ajay Pillai', email: 'ajay.pillai@college.com', phone: '+15550120', roleId: rolesMap['Viewer'], departmentId: deptsMap['Office'] },
  ];

  for (const u of sampleUsers) {
    await prisma.user.upsert({
      where: { email: u.email },
      update: {},
      create: { ...u, password: samplePassword, status: 'ACTIVE' },
    });
  }
  console.log(`${sampleUsers.length} sample users seeded.`);

  // 5c. Seed Sample Students
  const studentPassword = await bcrypt.hash('Student@123', 10);

  const sampleStudents = [
    // Computer Science
    { rollNumber: 'CS2021001', name: 'Aarav Sharma', email: 'aarav.sharma@student.college.com', phone: '+15550201', departmentId: deptsMap['Computer Science'] },
    { rollNumber: 'CS2021002', name: 'Nisha Patel', email: 'nisha.patel@student.college.com', phone: '+15550202', departmentId: deptsMap['Computer Science'] },
    { rollNumber: 'CS2021003', name: 'Rohit Verma', email: 'rohit.verma@student.college.com', phone: '+15550203', departmentId: deptsMap['Computer Science'] },
    { rollNumber: 'CS2022001', name: 'Preethi Suresh', email: 'preethi.suresh@student.college.com', phone: '+15550204', departmentId: deptsMap['Computer Science'] },

    // Mechanical Engineering
    { rollNumber: 'ME2021001', name: 'Arjun Nair', email: 'arjun.nair@student.college.com', phone: '+15550205', departmentId: deptsMap['Mechanical'] },
    { rollNumber: 'ME2021002', name: 'Deepa Krishnan', email: 'deepa.krishnan@student.college.com', phone: '+15550206', departmentId: deptsMap['Mechanical'] },
    { rollNumber: 'ME2022001', name: 'Sanjay Rao', email: 'sanjay.rao@student.college.com', phone: '+15550207', departmentId: deptsMap['Mechanical'] },

    // Electronics
    { rollNumber: 'EC2021001', name: 'Pooja Menon', email: 'pooja.menon@student.college.com', phone: '+15550208', departmentId: deptsMap['Electronics'] },
    { rollNumber: 'EC2021002', name: 'Rahul Iyer', email: 'rahul.iyer@student.college.com', phone: '+15550209', departmentId: deptsMap['Electronics'] },
    { rollNumber: 'EC2022001', name: 'Snehal Pillai', email: 'snehal.pillai@student.college.com', phone: '+15550210', departmentId: deptsMap['Electronics'] },

    // Civil Engineering
    { rollNumber: 'CE2021001', name: 'Karthik Reddy', email: 'karthik.reddy@student.college.com', phone: '+15550211', departmentId: deptsMap['Civil'] },
    { rollNumber: 'CE2021002', name: 'Meghana Singh', email: 'meghana.singh@student.college.com', phone: '+15550212', departmentId: deptsMap['Civil'] },
    { rollNumber: 'CE2022001', name: 'Vivek Kumar', email: 'vivek.kumar@student.college.com', phone: '+15550213', departmentId: deptsMap['Civil'] },

    // Library
    { rollNumber: 'LIB2022001', name: 'Ananya Das', email: 'ananya.das@student.college.com', phone: '+15550214', departmentId: deptsMap['Library'] },
    { rollNumber: 'LIB2022002', name: 'Nikhil Joshi', email: 'nikhil.joshi@student.college.com', phone: '+15550215', departmentId: deptsMap['Library'] },
  ];

  for (const s of sampleStudents) {
    await prisma.user.upsert({
      where: { email: s.email },
      update: {},
      create: {
        ...s,
        password: studentPassword,
        roleId: rolesMap['Student'],
        status: 'ACTIVE',
      },
    });
  }
  console.log(`${sampleStudents.length} students seeded.`);

  // 6. Seed Conditions
  for (const cond of defaultConditions) {
    await prisma.condition.upsert({
      where: { conditionName: cond.conditionName },
      update: {},
      create: cond,
    });
  }
  console.log('Asset conditions seeded.');

  // 7. Seed Statuses
  for (const stat of defaultStatuses) {
    await prisma.assetStatus.upsert({
      where: { statusName: stat.statusName },
      update: {},
      create: stat,
    });
  }
  console.log('Asset statuses seeded.');

  // 8. Seed 20 Categories
  for (const cat of defaultCategories) {
    await prisma.assetCategory.upsert({
      where: { categoryCode: cat.categoryCode },
      update: {},
      create: {
        ...cat,
        createdBy: adminUser.id,
      },
    });
  }
  console.log('20 Categories seeded.');

  // 9. Seed 20 Locations
  for (const loc of defaultLocations) {
    await prisma.location.upsert({
      where: { locationCode: loc.locationCode },
      update: {},
      create: {
        ...loc,
        createdBy: adminUser.id,
      },
    });
  }
  console.log('20 Locations seeded.');

  // 10. Seed 10 Vendors
  for (const vnd of defaultVendors) {
    await prisma.vendor.upsert({
      where: { vendorCode: vnd.vendorCode },
      update: {},
      create: {
        ...vnd,
        createdBy: adminUser.id,
      },
    });
  }
  console.log('10 Vendors seeded.');

  // 11. Seed 10 Manufacturers
  for (const mfg of defaultManufacturers) {
    await prisma.manufacturer.upsert({
      where: { manufacturerCode: mfg.manufacturerCode },
      update: {},
      create: mfg,
    });
  }
  // 12. Seed Default Technicians
  const defaultTechnicians = [
    { employeeId: 'TECH-001', name: 'John Electrician', email: 'john.tech@college.com', phone: '+15550201', specialization: 'Electrical & UPS Systems', isInternal: true },
    { employeeId: 'TECH-002', name: 'Sara Systems', email: 'sara.tech@college.com', phone: '+15550202', specialization: 'Desktops, Laptops & IT Networking', isInternal: true },
    { employeeId: 'TECH-003', name: 'Mark LabCare', email: 'mark.lab@college.com', phone: '+15550203', specialization: 'Lab microscopes & scale calibration', isInternal: true },
    { employeeId: 'TECH-004', name: 'External Dell Engineer', email: 'dell.tech@vendor.com', phone: '+18004563355', specialization: 'Dell Server Hardware support', isInternal: false },
  ];
  for (const tech of defaultTechnicians) {
    await prisma.technician.upsert({
      where: { employeeId: tech.employeeId },
      update: {},
      create: tech,
    });
  }
  console.log('Technicians seeded.');

  // 13. Seed Default System Settings
  const defaultSettings = [
    { settingKey: 'college_name', settingValue: 'College of Advanced Engineering', description: 'Name of the college' },
    { settingKey: 'college_email', settingValue: 'support@college.edu', description: 'Contact email' },
    { settingKey: 'asset_prefix', settingValue: 'AST', description: 'Prefix for auto-generated asset tags' },
    { settingKey: 'max_upload_size', settingValue: '5', description: 'Maximum file upload size in MB' },
    { settingKey: 'warranty_reminder_days', settingValue: '30', description: 'Days before warning on warranty expiries' },
    { settingKey: 'maintenance_reminder_days', settingValue: '7', description: 'Days before alert on preventive schedules' },
  ];
  for (const s of defaultSettings) {
    await prisma.systemSetting.upsert({
      where: { settingKey: s.settingKey },
      update: {},
      create: s,
    });
  }
  console.log('Default settings configured.');

  // 14. Seed Super Admin User Preferences
  await prisma.userPreference.upsert({
    where: { userId: adminUser.id },
    update: {},
    create: {
      userId: adminUser.id,
      theme: 'dark',
      language: 'en',
      itemsPerPage: 10,
    },
  });
  console.log('Super Admin preferences configured.');

  console.log('Seeding complete successfully.');
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

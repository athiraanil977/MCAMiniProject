import { Router } from 'express';
import * as backupController from '../controllers/backupController.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';

const router = Router();

router.use(authMiddleware);
router.use(permissionMiddleware('manage_users')); // Super Admin only

router.get('/', backupController.listBackups);
router.post('/', backupController.createBackup);
router.delete('/:id', backupController.deleteBackup);
router.get('/download/:id', backupController.downloadBackup);

export default router;

import { Router } from 'express';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import * as departmentRepository from '../repositories/departmentRepository.js';
import { successResponse } from '../utils/responseFormatter.js';
import { HTTP_STATUS } from '../constants/index.js';

const router = Router();
router.use(authMiddleware);

router.get('/', async (req, res) => {
  const departments = await departmentRepository.getAllDepartments();
  return successResponse(res, HTTP_STATUS.OK, 'Departments list retrieved', departments);
});

export default router;

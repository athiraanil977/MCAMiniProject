import { Router } from 'express';
import * as masterController from '../controllers/masterController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import { categorySchema } from '../validators/masterValidator.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

// Publicly viewable categories for authorized staff
router.get('/', permissionMiddleware('view_assets'), masterController.getCategories);
router.get('/:id', permissionMiddleware('view_assets'), masterController.getCategory);

// Management routes
router.post('/', permissionMiddleware('manage_assets'), validateSchema(categorySchema), masterController.createCategory);
router.put('/:id', permissionMiddleware('manage_assets'), validateSchema(categorySchema), masterController.updateCategory);
router.delete('/:id', permissionMiddleware('manage_assets'), masterController.deleteCategory);
router.patch('/:id/restore', permissionMiddleware('manage_assets'), masterController.restoreCategory);

export default router;

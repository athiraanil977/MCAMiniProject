import { Router } from 'express';
import * as maintenanceController from '../controllers/maintenanceController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import {
  requestSchema,
  recordSchema,
  scheduleSchema
} from '../validators/maintenanceValidator.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

// =========================================================================
// Dashboard Metrics
// =========================================================================
router.get('/dashboard-metrics', permissionMiddleware('view_reports'), maintenanceController.getMaintenanceMetrics);

// =========================================================================
// Maintenance Requests (Staff/Faculty can create, view own; Admins manage)
// =========================================================================
router.get('/requests', permissionMiddleware('view_assets'), maintenanceController.getRequests);
router.get('/requests/:id', permissionMiddleware('view_assets'), maintenanceController.getRequest);
router.post('/requests', permissionMiddleware('view_assets'), validateSchema(requestSchema), maintenanceController.createRequest);
router.put('/requests/:id', permissionMiddleware('manage_maintenance'), validateSchema(requestSchema), maintenanceController.updateRequest);
router.delete('/requests/:id', permissionMiddleware('manage_maintenance'), maintenanceController.deleteRequest);

// =========================================================================
// Preventive Maintenance Schedules (Admins & Managers configure)
// =========================================================================
router.get('/schedules', permissionMiddleware('view_assets'), maintenanceController.getSchedules);
router.get('/schedules/:id', permissionMiddleware('view_assets'), maintenanceController.getSchedule);
router.post('/schedules', permissionMiddleware('manage_maintenance'), validateSchema(scheduleSchema), maintenanceController.createSchedule);
router.put('/schedules/:id', permissionMiddleware('manage_maintenance'), validateSchema(scheduleSchema), maintenanceController.updateSchedule);
router.delete('/schedules/:id', permissionMiddleware('manage_maintenance'), maintenanceController.deleteSchedule);

// =========================================================================
// Maintenance Records (Technicians & Managers write)
// =========================================================================
router.get('/', permissionMiddleware('view_assets'), maintenanceController.getRecords);
router.get('/:id', permissionMiddleware('view_assets'), maintenanceController.getRecord);
router.post('/', permissionMiddleware('manage_maintenance'), validateSchema(recordSchema), maintenanceController.startRecord);
router.put('/:id', permissionMiddleware('manage_maintenance'), validateSchema(recordSchema), maintenanceController.completeRecord);
router.delete('/:id', permissionMiddleware('manage_maintenance'), maintenanceController.deleteRecord);

export default router;

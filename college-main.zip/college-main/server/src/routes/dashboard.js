import { Router } from 'express';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import * as masterController from '../controllers/masterController.js';
import * as assetController from '../controllers/assetController.js';
import * as dashboardController from '../controllers/dashboardController.js';

const router = Router();

router.use(authMiddleware);

// Retrieve aggregated master metrics for the dashboard
router.get('/master-metrics', masterController.getMasterMetrics);

// Retrieve aggregated asset inventory metrics for the dashboard
router.get('/asset-metrics', assetController.getAssetMetrics);

// Executive Dashboard aggregate queries
router.get('/', dashboardController.getDashboardSummary);
router.get('/cards', dashboardController.getDashboardCards);
router.get('/charts', dashboardController.getDashboardCharts);
router.get('/activity', dashboardController.getRecentActivitiesList);
router.get('/summary', dashboardController.getDashboardSummary);

export default router;

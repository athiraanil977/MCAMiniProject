import { Router } from 'express';
import * as maintenanceController from '../controllers/masterController.js'; // wait, it's inside maintenanceController!
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import { technicianSchema } from '../validators/maintenanceValidator.js';
import * as controller from '../controllers/maintenanceController.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

router.get('/', permissionMiddleware('view_users'), controller.getTechnicians);
router.get('/:id', permissionMiddleware('view_users'), controller.getTechnician);
router.post('/', permissionMiddleware('manage_users'), validateSchema(technicianSchema), controller.createTechnician);
router.put('/:id', permissionMiddleware('manage_users'), validateSchema(technicianSchema), controller.updateTechnician);
router.delete('/:id', permissionMiddleware('manage_users'), controller.deleteTechnician);

export default router;

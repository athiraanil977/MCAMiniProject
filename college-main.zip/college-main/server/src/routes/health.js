import { Router } from 'express';
import * as healthController from '../controllers/healthController.js';

const router = Router();

// Health routes are PUBLIC – no auth required (for uptime monitors, load balancers)
router.get('/', healthController.getHealth);
router.get('/database', healthController.getDatabaseHealth);
router.get('/storage', healthController.getStorageHealth);
router.get('/system', healthController.getSystemHealth);

export default router;

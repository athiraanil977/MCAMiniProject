import { Router } from 'express';
import * as assetController from '../controllers/assetController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import { upload } from '../middlewares/uploadMiddleware.js';
import {
  assetSchema,
  allocationSchema,
  returnSchema,
  transferSchema,
  reservationSchema,
  disposalSchema
} from '../validators/assetValidator.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

// Core Read Queries
router.get('/', permissionMiddleware('view_assets'), assetController.getAssets);
router.get('/:id', permissionMiddleware('view_assets'), assetController.getAsset);

// Core Write Queries
router.post('/', permissionMiddleware('manage_assets'), validateSchema(assetSchema), assetController.createAsset);
router.put('/:id', permissionMiddleware('manage_assets'), validateSchema(assetSchema), assetController.updateAsset);
router.delete('/:id', permissionMiddleware('manage_assets'), assetController.deleteAsset);
router.patch('/:id/restore', permissionMiddleware('manage_assets'), assetController.restoreAsset);

// File uploads
router.post('/upload', permissionMiddleware('manage_assets'), upload.single('file'), assetController.uploadFile);
router.post('/:id/documents', permissionMiddleware('manage_assets'), assetController.addAssetDocument);

// Lifecycle Operations
router.post('/allocate', permissionMiddleware('manage_assets'), validateSchema(allocationSchema), assetController.allocateAsset);
router.post('/return', permissionMiddleware('manage_assets'), validateSchema(returnSchema), assetController.returnAsset);
router.post('/transfer', permissionMiddleware('manage_assets'), validateSchema(transferSchema), assetController.transferAsset);
router.post('/dispose', permissionMiddleware('manage_assets'), validateSchema(disposalSchema), assetController.disposeAsset);

// Reservations (Staff/Faculty can reserve assets)
router.post('/reserve', permissionMiddleware('view_assets'), validateSchema(reservationSchema), assetController.reserveAsset);
router.patch('/reservations/:id/approve', permissionMiddleware('manage_assets'), assetController.approveReservation);

export default router;

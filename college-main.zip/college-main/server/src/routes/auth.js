import { Router } from 'express';
import * as authController from '../controllers/authController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import {
  loginSchema,
  logoutSchema,
  refreshSchema,
  changePasswordSchema,
  forgotPasswordSchema,
  resetPasswordSchema
} from '../validators/authValidator.js';

const router = Router();

// Public Authentication Endpoints
router.post('/login', validateSchema(loginSchema), authController.login);
router.post('/logout', validateSchema(logoutSchema), authController.logout);
router.post('/refresh', validateSchema(refreshSchema), authController.refresh);
router.post('/forgot-password', validateSchema(forgotPasswordSchema), authController.forgotPassword);
router.post('/reset-password', validateSchema(resetPasswordSchema), authController.resetPassword);

// Protected Authentication Endpoints
router.post('/change-password', authMiddleware, validateSchema(changePasswordSchema), authController.changePassword);

export default router;

import { Router } from 'express';
import * as settingsController from '../controllers/settingsController.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

router.get('/', settingsController.getSettings);
router.put('/', permissionMiddleware('manage_users'), settingsController.updateSettings); // Restricted to Super Admin / Manager role actions

export default router;

import { Router } from 'express';
import * as auditLogController from '../controllers/auditLogController.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

router.get('/', permissionMiddleware('view_users'), auditLogController.getAuditLogs);
router.get('/:id', permissionMiddleware('view_users'), auditLogController.getAuditLog);

export default router;

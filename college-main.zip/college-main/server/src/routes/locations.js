import { Router } from 'express';
import * as masterController from '../controllers/masterController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import { locationSchema } from '../validators/masterValidator.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

// Viewing routes
router.get('/', permissionMiddleware('view_assets'), masterController.getLocations);
router.get('/:id', permissionMiddleware('view_assets'), masterController.getLocation);

// Management routes
router.post('/', permissionMiddleware('manage_assets'), validateSchema(locationSchema), masterController.createLocation);
router.put('/:id', permissionMiddleware('manage_assets'), validateSchema(locationSchema), masterController.updateLocation);
router.delete('/:id', permissionMiddleware('manage_assets'), masterController.deleteLocation);
router.patch('/:id/restore', permissionMiddleware('manage_assets'), masterController.restoreLocation);

export default router;

import { Router } from 'express';
import * as reportController from '../controllers/reportController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import {
  saveReportSchema,
  exportReportSchema
} from '../validators/reportValidator.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

// Retrieve reporting lists
router.get('/assets', permissionMiddleware('view_reports'), reportController.getAssetsReport);
router.get('/maintenance', permissionMiddleware('view_reports'), reportController.getMaintenanceReport);
router.get('/financial', permissionMiddleware('view_reports'), reportController.getFinancialReport);

// Exports
router.post('/export', permissionMiddleware('view_reports'), validateSchema(exportReportSchema), reportController.exportReport);

// Saved Report Configurations
router.get('/saved', reportController.getSavedReports);
router.post('/save', validateSchema(saveReportSchema), reportController.saveReport);

export default router;

import { Router } from 'express';
import authRouter from './auth.js';
import assetsRouter from './assets.js';
import categoriesRouter from './categories.js';
import locationsRouter from './locations.js';
import vendorsRouter from './vendors.js';
import maintenanceRouter from './maintenance.js';
import usersRouter from './users.js';
import dashboardRouter from './dashboard.js';
import reportsRouter from './reports.js';
import manufacturersRouter from './manufacturers.js';
import techniciansRouter from './technicians.js';
import profileRouter from './profile.js';
import settingsRouter from './settings.js';
import notificationsRouter from './notifications.js';
import auditLogsRouter from './auditLogs.js';
import backupsRouter from './backups.js';
import departmentsRouter from './departments.js';
import healthRouter from './health.js';
import { authLimiter } from '../middlewares/rateLimitMiddleware.js';

const router = Router();

// Auth routes (brute-force protected with strict limiter)
router.use('/auth', authLimiter, authRouter);

// Resource routes
router.use('/assets', assetsRouter);
router.use('/categories', categoriesRouter);
router.use('/locations', locationsRouter);
router.use('/vendors', vendorsRouter);
router.use('/maintenance', maintenanceRouter);
router.use('/users', usersRouter);
router.use('/dashboard', dashboardRouter);
router.use('/reports', reportsRouter);
router.use('/manufacturers', manufacturersRouter);
router.use('/technicians', techniciansRouter);
router.use('/profile', profileRouter);
router.use('/settings', settingsRouter);
router.use('/notifications', notificationsRouter);
router.use('/audit-logs', auditLogsRouter);
router.use('/backups', backupsRouter);
router.use('/departments', departmentsRouter);

// Health checks (public – no auth)
router.use('/health', healthRouter);

export default router;

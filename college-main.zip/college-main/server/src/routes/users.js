import { Router } from 'express';
import * as userController from '../controllers/userController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import { createUserSchema, updateUserSchema } from '../validators/userValidator.js';

const router = Router();

// Apply auth middleware globally to all user routes
router.use(authMiddleware);

// User List & Creation
router.get('/', permissionMiddleware('view_users'), userController.getUsers);
router.post('/', permissionMiddleware('manage_users'), validateSchema(createUserSchema), userController.createUser);

// Specific User Operations
router.get('/:id', permissionMiddleware('view_users'), userController.getUser);
router.put('/:id', permissionMiddleware('manage_users'), validateSchema(updateUserSchema), userController.updateUser);
router.delete('/:id', permissionMiddleware('manage_users'), userController.deleteUser);

// Account status controls
router.post('/:id/activate', permissionMiddleware('manage_users'), userController.activateUser);
router.post('/:id/deactivate', permissionMiddleware('manage_users'), userController.deactivateUser);

export default router;

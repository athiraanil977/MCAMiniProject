import { Router } from 'express';
import * as masterController from '../controllers/masterController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import { manufacturerSchema } from '../validators/masterValidator.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

// Viewing routes
router.get('/', permissionMiddleware('view_assets'), masterController.getManufacturers);
router.get('/:id', permissionMiddleware('view_assets'), masterController.getManufacturer);

// Management routes
router.post('/', permissionMiddleware('manage_assets'), validateSchema(manufacturerSchema), masterController.createManufacturer);
router.put('/:id', permissionMiddleware('manage_assets'), validateSchema(manufacturerSchema), masterController.updateManufacturer);
router.delete('/:id', permissionMiddleware('manage_assets'), masterController.deleteManufacturer);
router.patch('/:id/restore', permissionMiddleware('manage_assets'), masterController.restoreManufacturer);

export default router;

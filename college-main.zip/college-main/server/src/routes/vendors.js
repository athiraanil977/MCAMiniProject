import { Router } from 'express';
import * as masterController from '../controllers/masterController.js';
import { validateSchema } from '../utils/validationUtility.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { permissionMiddleware } from '../middlewares/permissionMiddleware.js';
import { vendorSchema } from '../validators/masterValidator.js';

const router = Router();

// Apply auth globally
router.use(authMiddleware);

// Viewing routes
router.get('/', permissionMiddleware('view_assets'), masterController.getVendors);
router.get('/:id', permissionMiddleware('view_assets'), masterController.getVendor);

// Management routes
router.post('/', permissionMiddleware('manage_assets'), validateSchema(vendorSchema), masterController.createVendor);
router.put('/:id', permissionMiddleware('manage_assets'), validateSchema(vendorSchema), masterController.updateVendor);
router.delete('/:id', permissionMiddleware('manage_assets'), masterController.deleteVendor);
router.patch('/:id/restore', permissionMiddleware('manage_assets'), masterController.restoreVendor);

export default router;

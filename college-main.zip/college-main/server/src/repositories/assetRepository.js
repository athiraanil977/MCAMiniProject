import prisma from '../database/index.js';

// =========================================================================
// Helper to generate next unique Asset Tag, Barcode, and QR Code
// =========================================================================
export const generateAssetCodes = async (tx) => {
  const db = tx || prisma;
  const lastAsset = await db.asset.findFirst({
    orderBy: { id: 'desc' },
  });

  let nextNum = 1;
  if (lastAsset) {
    const match = lastAsset.assetTag.match(/AST-(\d+)/);
    if (match) {
      nextNum = parseInt(match[1], 10) + 1;
    }
  }

  const paddedNum = String(nextNum).padStart(6, '0');
  const assetTag = `AST-${paddedNum}`;
  const barcode = `BAR-${paddedNum}`;
  const qrCode = `QR-${paddedNum}`;

  return { assetTag, barcode, qrCode };
};

// =========================================================================
// Core CRUD Operations
// =========================================================================

export const createAsset = async (data, userId) => {
  return await prisma.$transaction(async (tx) => {
    const codes = await generateAssetCodes(tx);
    
    const asset = await tx.asset.create({
      data: {
        ...data,
        assetTag: codes.assetTag,
        barcode: codes.barcode,
        qrCode: codes.qrCode,
        createdBy: userId,
      },
    });

    // Record initial history log
    await tx.assetHistory.create({
      data: {
        assetId: asset.id,
        action: 'Created',
        performedBy: userId,
        newValue: JSON.stringify({ assetTag: asset.assetTag, assetName: asset.assetName }),
        remarks: 'Asset profile registered in catalog.',
      },
    });

    return asset;
  });
};

export const updateAsset = async (id, data, userId) => {
  return await prisma.$transaction(async (tx) => {
    const oldAsset = await tx.asset.findUnique({ where: { id } });
    if (!oldAsset) throw new Error('Asset not found');

    const updated = await tx.asset.update({
      where: { id },
      data: {
        ...data,
        updatedBy: userId,
      },
    });

    // Record history
    await tx.assetHistory.create({
      data: {
        assetId: id,
        action: 'Updated',
        performedBy: userId,
        oldValue: JSON.stringify({ assetName: oldAsset.assetName, statusId: oldAsset.statusId, conditionId: oldAsset.conditionId }),
        newValue: JSON.stringify({ assetName: updated.assetName, statusId: updated.statusId, conditionId: updated.conditionId }),
        remarks: 'Asset profile specifications modified.',
      },
    });

    return updated;
  });
};

export const softDeleteAsset = async (id, userId) => {
  return await prisma.$transaction(async (tx) => {
    const asset = await tx.asset.update({
      where: { id },
      data: { deletedAt: new Date() },
    });

    await tx.assetHistory.create({
      data: {
        assetId: id,
        action: 'Deleted',
        performedBy: userId,
        remarks: 'Asset profile soft-deleted/archived.',
      },
    });

    return asset;
  });
};

export const restoreAsset = async (id, userId) => {
  return await prisma.$transaction(async (tx) => {
    const asset = await tx.asset.update({
      where: { id },
      data: { deletedAt: null },
    });

    await tx.assetHistory.create({
      data: {
        assetId: id,
        action: 'Restored',
        performedBy: userId,
        remarks: 'Asset profile restored to catalog.',
      },
    });

    return asset;
  });
};

export const getAssetById = async (id) => {
  return await prisma.asset.findFirst({
    where: { id, deletedAt: null },
    include: {
      category: true,
      manufacturer: true,
      vendor: true,
      department: true,
      location: true,
      condition: true,
      status: true,
      assignedUser: { select: { id: true, name: true, email: true } },
      createdByUser: { select: { id: true, name: true } },
      updatedByUser: { select: { id: true, name: true } },
      allocations: {
        orderBy: { allocationDate: 'desc' },
        include: {
          allocatedToUser: { select: { id: true, name: true } },
          department: true,
        },
      },
      transfers: {
        orderBy: { transferDate: 'desc' },
        include: {
          fromDepartment: true,
          toDepartment: true,
          fromLocation: true,
          toLocation: true,
        },
      },
      reservations: {
        orderBy: { reservationDate: 'desc' },
        include: {
          requestedByUser: { select: { id: true, name: true } },
        },
      },
      documents: {
        orderBy: { createdAt: 'desc' },
      },
      histories: {
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { name: true } },
        },
      },
    },
  });
};

export const getAssetsList = async ({
  page = 1,
  limit = 10,
  search = '',
  categoryId,
  departmentId,
  locationId,
  statusId,
  conditionId,
  showDeleted = false,
  warrantyExpired = false,
  minCost,
  maxCost,
  includeReservations = false,
}) => {
  const skip = (page - 1) * limit;
  const where = {
    deletedAt: showDeleted ? { not: null } : null,
  };

  // Category, department, location, status filters
  if (categoryId) where.categoryId = categoryId;
  if (departmentId) where.departmentId = departmentId;
  if (locationId) where.locationId = locationId;
  if (statusId) where.statusId = statusId;
  if (conditionId) where.conditionId = conditionId;

  // Cost ranges
  if (minCost !== undefined || maxCost !== undefined) {
    where.purchaseCost = {};
    if (minCost !== undefined) where.purchaseCost.gte = minCost;
    if (maxCost !== undefined) where.purchaseCost.lte = maxCost;
  }

  // Warranty Expired check
  if (warrantyExpired) {
    where.warrantyEnd = { lt: new Date() };
  }

  // Full-text searches
  if (search) {
    where.OR = [
      { assetName: { contains: search } },
      { assetTag: { contains: search } },
      { serialNumber: { contains: search } },
      { barcode: { contains: search } },
      { qrCode: { contains: search } },
    ];
  }

  const [assets, total] = await prisma.$transaction([
    prisma.asset.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        category: true,
        department: true,
        location: true,
        status: true,
        condition: true,
        assignedUser: { select: { name: true } },
        reservations: includeReservations ? {
          orderBy: { reservationDate: 'desc' },
          include: {
            requestedByUser: {
              select: {
                id: true,
                name: true,
                role: { select: { roleName: true } }
              }
            }
          }
        } : false,
      },
    }),
    prisma.asset.count({ where }),
  ]);

  return { assets, total };
};

// =========================================================================
// Lifecycle Action Loggers
// =========================================================================

export const allocateAsset = async ({ assetId, allocatedToUserId, allocatedDepartmentId, expectedReturnDate, purpose, remarks, userId }) => {
  return await prisma.$transaction(async (tx) => {
    // 1. Fetch status definitions
    const allocatedStatus = await tx.assetStatus.findFirst({ where: { statusName: 'Allocated' } });
    if (!allocatedStatus) throw new Error('Allocated status definition is missing. Please run database seed.');

    // 2. Fetch current status of the asset
    const asset = await tx.asset.findUnique({ where: { id: assetId } });
    if (!asset) throw new Error('Asset not found');

    // 3. Create allocation entry
    const allocation = await tx.assetAllocation.create({
      data: {
        assetId,
        allocatedToUserId,
        allocatedDepartmentId,
        expectedReturnDate,
        purpose,
        remarks,
        status: 'Allocated',
        allocatedBy: userId,
      },
    });

    // 4. Update asset status and assigned attributes
    await tx.asset.update({
      where: { id: assetId },
      data: {
        statusId: allocatedStatus.id,
        assignedUserId: allocatedToUserId,
        departmentId: allocatedDepartmentId || asset.departmentId,
      },
    });

    // 5. Append history log
    await tx.assetHistory.create({
      data: {
        assetId,
        action: 'Allocated',
        performedBy: userId,
        newValue: JSON.stringify({ assignedUserId: allocatedToUserId, departmentId: allocatedDepartmentId }),
        remarks: `Allocated to ${allocatedToUserId ? 'user ' + allocatedToUserId : 'department ' + allocatedDepartmentId}.`,
      },
    });

    return allocation;
  });
};

export const returnAsset = async ({ assetId, remarks, userId }) => {
  return await prisma.$transaction(async (tx) => {
    const availableStatus = await tx.assetStatus.findFirst({ where: { statusName: 'Available' } });
    if (!availableStatus) throw new Error('Available status definition is missing. Run seed.');

    // Find active allocation
    const activeAlloc = await tx.assetAllocation.findFirst({
      where: { assetId, status: 'Allocated' },
      orderBy: { allocationDate: 'desc' },
    });

    if (activeAlloc) {
      await tx.assetAllocation.update({
        where: { id: activeAlloc.id },
        data: {
          actualReturnDate: new Date(),
          status: 'Returned',
          returnedBy: userId,
        },
      });
    }

    // Update asset profile
    await tx.asset.update({
      where: { id: assetId },
      data: {
        statusId: availableStatus.id,
        assignedUserId: null,
      },
    });

    // Write history logs
    await tx.assetHistory.create({
      data: {
        assetId,
        action: 'Returned',
        performedBy: userId,
        remarks: `Returned asset back to catalog. Remarks: ${remarks || 'None'}`,
      },
    });
  });
};

export const transferAsset = async ({ assetId, toDepartmentId, toLocationId, reason, remarks, userId }) => {
  return await prisma.$transaction(async (tx) => {
    const asset = await tx.asset.findUnique({ where: { id: assetId } });
    if (!asset) throw new Error('Asset not found');

    const transfer = await tx.assetTransfer.create({
      data: {
        assetId,
        fromDepartmentId: asset.departmentId,
        toDepartmentId,
        fromLocationId: asset.locationId,
        toLocationId,
        transferredBy: userId,
        reason,
        remarks,
      },
    });

    // Update asset departments & locations
    await tx.asset.update({
      where: { id: assetId },
      data: {
        departmentId: toDepartmentId,
        locationId: toLocationId,
      },
    });

    // Write logs
    await tx.assetHistory.create({
      data: {
        assetId,
        action: 'Transferred',
        performedBy: userId,
        oldValue: JSON.stringify({ departmentId: asset.departmentId, locationId: asset.locationId }),
        newValue: JSON.stringify({ departmentId: toDepartmentId, locationId: toLocationId }),
        remarks: `Transferred asset between rooms. Reason: ${reason || 'None'}`,
      },
    });

    return transfer;
  });
};

export const reserveAsset = async ({ assetId, requestedBy, reservationStart, reservationEnd, purpose, remarks }) => {
  // Create the reservation record (no transaction needed — asset status only changes on approval)
  const reservation = await prisma.assetReservation.create({
    data: {
      assetId,
      requestedBy,
      reservationStart,
      reservationEnd,
      purpose,
      remarks,
      status: 'Pending',
    },
  });

  // Log history entry independently — non-critical, don't let it block the reservation
  try {
    await prisma.assetHistory.create({
      data: {
        assetId,
        action: 'Reserved',
        performedBy: requestedBy,
        remarks: `Created reservation request for range: ${reservationStart} - ${reservationEnd}.`,
      },
    });
  } catch (histErr) {
    console.warn('[ASSET] Asset history log failed (non-fatal):', histErr.message);
  }

  return reservation;
};


export const approveOrRejectReservation = async (id, status, remarks, userId) => {
  return await prisma.$transaction(async (tx) => {
    const reserv = await tx.assetReservation.findUnique({ where: { id } });
    if (!reserv) throw new Error('Reservation not found');

    const updated = await tx.assetReservation.update({
      where: { id },
      data: {
        status,
        approvedBy: userId,
        remarks,
      },
    });

    // If approved, toggle asset status to Reserved
    if (status === 'Approved') {
      const reservedStatus = await tx.assetStatus.findFirst({ where: { statusName: 'Reserved' } });
      if (reservedStatus) {
        await tx.asset.update({
          where: { id: reserv.assetId },
          data: { statusId: reservedStatus.id },
        });
      }
    }

    await tx.assetHistory.create({
      data: {
        assetId: reserv.assetId,
        action: 'Status Changed',
        performedBy: userId,
        remarks: `Reservation request status updated to ${status}. Admin notes: ${remarks || 'None'}`,
      },
    });

    return updated;
  });
};

export const disposeAsset = async ({ assetId, reason, method, approvedBy, remarks, documentPath }) => {
  return await prisma.$transaction(async (tx) => {
    const disposedStatus = await tx.assetStatus.findFirst({ where: { statusName: 'Disposed' } });
    if (!disposedStatus) throw new Error('Disposed status definition is missing. Run seed.');

    const disposal = await tx.assetDisposal.create({
      data: {
        assetId,
        reason,
        method,
        approvedBy,
        remarks,
        documentPath,
      },
    });

    // Mark asset status as Disposed and remove any assignments
    await tx.asset.update({
      where: { id: assetId },
      data: {
        statusId: disposedStatus.id,
        assignedUserId: null,
      },
    });

    await tx.assetHistory.create({
      data: {
        assetId,
        action: 'Disposed',
        performedBy: approvedBy,
        remarks: `Asset decommissioned via disposal channel (${method}). Reason: ${reason}.`,
      },
    });

    return disposal;
  });
};

export const addAssetDocument = async ({ assetId, documentType, fileName, filePath, userId }) => {
  return await prisma.assetDocument.create({
    data: {
      assetId,
      documentType,
      fileName,
      filePath,
      uploadedBy: userId,
    },
  });
};

// =========================================================================
// Dashboard & Metric Calculations
// =========================================================================

export const getDashboardAssetMetrics = async () => {
  // Aggregate queries
  const statuses = await prisma.assetStatus.findMany();
  const categories = await prisma.assetCategory.findMany({ where: { deletedAt: null } });
  const departments = await prisma.department.findMany();

  // Run bulk promises
  const [
    totalAssets,
    warrantyExpired,
    statusCounts,
    categoryCounts,
    deptCounts,
  ] = await Promise.all([
    prisma.asset.count({ where: { deletedAt: null } }),
    prisma.asset.count({ where: { deletedAt: null, warrantyEnd: { lt: new Date() } } }),
    Promise.all(statuses.map(async (st) => ({
      status: st.statusName,
      count: await prisma.asset.count({ where: { deletedAt: null, statusId: st.id } }),
    }))),
    Promise.all(categories.map(async (cat) => ({
      category: cat.categoryName,
      count: await prisma.asset.count({ where: { deletedAt: null, categoryId: cat.id } }),
    }))),
    Promise.all(departments.map(async (dept) => ({
      department: dept.departmentName,
      count: await prisma.asset.count({ where: { deletedAt: null, departmentId: dept.id } }),
    }))),
  ]);

  // Extract flat counters
  const countsByStatus = {};
  statusCounts.forEach((item) => {
    countsByStatus[item.status] = item.count;
  });

  return {
    totalAssets,
    availableAssets: countsByStatus['Available'] || 0,
    allocatedAssets: countsByStatus['Allocated'] || 0,
    reservedAssets: countsByStatus['Reserved'] || 0,
    disposedAssets: countsByStatus['Disposed'] || 0,
    maintenanceAssets: countsByStatus['Maintenance'] || 0,
    warrantyExpired,
    assetsByDepartment: deptCounts,
    assetsByCategory: categoryCounts,
    assetsByStatus: statusCounts,
  };
};

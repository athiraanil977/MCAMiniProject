import prisma from '../database/index.js';

// Refresh Token Operations
export const createRefreshToken = async (userId, token, expiresAt) => {
  return await prisma.refreshToken.create({
    data: { userId, token, expiresAt },
  });
};

export const findRefreshToken = async (token) => {
  return await prisma.refreshToken.findUnique({
    where: { token },
    include: { user: true },
  });
};

export const deleteRefreshToken = async (token) => {
  try {
    return await prisma.refreshToken.delete({
      where: { token },
    });
  } catch (error) {
    // Suppress error if token already deleted
    return null;
  }
};

export const deleteUserRefreshTokens = async (userId) => {
  return await prisma.refreshToken.deleteMany({
    where: { userId },
  });
};

// Password Reset Token Operations
export const createPasswordResetToken = async (userId, token, expiresAt) => {
  return await prisma.passwordResetToken.create({
    data: { userId, token, expiresAt },
  });
};

export const findPasswordResetToken = async (token) => {
  return await prisma.passwordResetToken.findUnique({
    where: { token },
    include: { user: true },
  });
};

export const markPasswordResetTokenUsed = async (token) => {
  return await prisma.passwordResetToken.update({
    where: { token },
    data: { used: true },
  });
};

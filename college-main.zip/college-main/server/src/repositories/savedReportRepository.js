import prisma from '../database/index.js';

export const createSavedReport = async (data) => {
  return await prisma.savedReport.create({
    data: {
      userId: data.userId,
      reportName: data.reportName,
      reportType: data.reportType,
      filterJson: JSON.stringify(data.filters || {}),
    },
  });
};

export const getSavedReports = async (userId) => {
  return await prisma.savedReport.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  });
};

export const deleteSavedReport = async (id, userId) => {
  return await prisma.savedReport.delete({
    where: {
      id,
      userId,
    },
  });
};

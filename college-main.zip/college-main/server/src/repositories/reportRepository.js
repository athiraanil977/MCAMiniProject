import prisma from '../database/index.js';

// =========================================================================
// Assets Reports Filter Queries
// =========================================================================

export const queryAssetsReport = async (filters = {}) => {
  const where = { deletedAt: null };

  if (filters.categoryId) where.categoryId = parseInt(filters.categoryId, 10);
  if (filters.departmentId) where.departmentId = parseInt(filters.departmentId, 10);
  if (filters.locationId) where.locationId = parseInt(filters.locationId, 10);
  if (filters.vendorId) where.vendorId = parseInt(filters.vendorId, 10);
  if (filters.manufacturerId) where.manufacturerId = parseInt(filters.manufacturerId, 10);
  if (filters.conditionId) where.conditionId = parseInt(filters.conditionId, 10);
  if (filters.statusId) where.statusId = parseInt(filters.statusId, 10);

  if (filters.warrantyStatus === 'expired') {
    where.warrantyEnd = { lt: new Date() };
  } else if (filters.warrantyStatus === 'expiring') {
    const now = new Date();
    const future = new Date();
    future.setDate(now.getDate() + 30);
    where.warrantyEnd = { gt: now, lte: future };
  }

  if (filters.costMin !== undefined || filters.costMax !== undefined) {
    where.purchaseCost = {};
    if (filters.costMin) where.purchaseCost.gte = parseFloat(filters.costMin);
    if (filters.costMax) where.purchaseCost.lte = parseFloat(filters.costMax);
  }

  return await prisma.asset.findMany({
    where,
    include: {
      category: { select: { categoryName: true } },
      department: { select: { departmentName: true } },
      location: { select: { locationName: true } },
      vendor: { select: { vendorName: true } },
      manufacturer: { select: { manufacturerName: true } },
      condition: { select: { conditionName: true } },
      status: { select: { statusName: true } },
    },
    orderBy: { createdAt: 'desc' },
  });
};

// =========================================================================
// Maintenance Reports Filter Queries
// =========================================================================

export const queryMaintenanceReport = async (filters = {}) => {
  const where = {};

  if (filters.assetId) where.assetId = parseInt(filters.assetId, 10);
  if (filters.status) where.status = filters.status;
  if (filters.maintenanceType) where.maintenanceType = filters.maintenanceType;
  if (filters.vendorId) where.vendorId = parseInt(filters.vendorId, 10);

  if (filters.startDateMin || filters.startDateMax) {
    where.startDate = {};
    if (filters.startDateMin) where.startDate.gte = new Date(filters.startDateMin);
    if (filters.startDateMax) where.startDate.lte = new Date(filters.startDateMax);
  }

  return await prisma.maintenanceRecord.findMany({
    where,
    include: {
      asset: { select: { assetTag: true, assetName: true } },
      vendor: { select: { vendorName: true } },
    },
    orderBy: { startDate: 'desc' },
  });
};

// =========================================================================
// Financial Reports Filter Queries
// =========================================================================

export const queryFinancialReport = async (filters = {}) => {
  const where = { deletedAt: null };

  if (filters.departmentId) where.departmentId = parseInt(filters.departmentId, 10);
  if (filters.categoryId) where.categoryId = parseInt(filters.categoryId, 10);

  return await prisma.asset.findMany({
    where,
    select: {
      id: true,
      assetTag: true,
      assetName: true,
      purchaseCost: true,
      purchaseDate: true,
      createdAt: true,
      category: { select: { categoryName: true } },
      department: { select: { departmentName: true } },
    },
    orderBy: { purchaseDate: 'desc' },
  });
};

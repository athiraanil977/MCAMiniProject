import prisma from '../database/index.js';

// =========================================================================
// Number Generators
// =========================================================================

export const generateRequestNumber = async (tx) => {
  const db = tx || prisma;
  const lastRequest = await db.maintenanceRequest.findFirst({
    orderBy: { id: 'desc' },
  });
  let nextNum = 1;
  if (lastRequest) {
    const match = lastRequest.requestNumber.match(/REQ-(\d+)/);
    if (match) {
      nextNum = parseInt(match[1], 10) + 1;
    }
  }
  return `REQ-${String(nextNum).padStart(6, '0')}`;
};

export const generateMaintenanceNumber = async (tx) => {
  const db = tx || prisma;
  const lastRecord = await db.maintenanceRecord.findFirst({
    orderBy: { id: 'desc' },
  });
  let nextNum = 1;
  if (lastRecord) {
    const match = lastRecord.maintenanceNumber.match(/MNT-(\d+)/);
    if (match) {
      nextNum = parseInt(match[1], 10) + 1;
    }
  }
  return `MNT-${String(nextNum).padStart(6, '0')}`;
};

// =========================================================================
// Maintenance Request Operations
// =========================================================================

export const findOpenRequestByAssetId = async (assetId) => {
  return await prisma.maintenanceRequest.findFirst({
    where: {
      assetId,
      status: { in: ['Open', 'Assigned', 'In Progress', 'Waiting Parts'] },
    },
  });
};

export const createRequest = async (data, userId) => {
  return await prisma.$transaction(async (tx) => {
    const requestNumber = await generateRequestNumber(tx);
    return await tx.maintenanceRequest.create({
      data: {
        ...data,
        requestNumber,
        requestedBy: userId,
      },
    });
  });
};

export const updateRequest = async (id, data) => {
  return await prisma.maintenanceRequest.update({
    where: { id },
    data,
  });
};

export const getRequestById = async (id) => {
  return await prisma.maintenanceRequest.findUnique({
    where: { id },
    include: {
      asset: { include: { status: true, condition: true } },
      requestedByUser: { select: { id: true, name: true, email: true } },
      department: true,
      technician: true,
      records: true,
    },
  });
};

export const getRequestsList = async ({ page = 1, limit = 10, search = '', status, priority, requestedBy }) => {
  const skip = (page - 1) * limit;
  const where = {};

  if (status) where.status = status;
  if (priority) where.priority = priority;
  if (requestedBy) where.requestedBy = requestedBy;

  if (search) {
    where.OR = [
      { problemTitle: { contains: search } },
      { requestNumber: { contains: search } },
      { asset: { assetName: { contains: search } } },
      { asset: { assetTag: { contains: search } } },
    ];
  }

  const [requests, total] = await prisma.$transaction([
    prisma.maintenanceRequest.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        asset: { select: { assetTag: true, assetName: true } },
        requestedByUser: { select: { name: true } },
        technician: { select: { name: true } },
      },
    }),
    prisma.maintenanceRequest.count({ where }),
  ]);

  return { requests, total };
};

// =========================================================================
// Maintenance Record Operations
// =========================================================================

export const createRecord = async (data) => {
  return await prisma.$transaction(async (tx) => {
    const maintenanceNumber = await generateMaintenanceNumber(tx);
    return await tx.maintenanceRecord.create({
      data: {
        ...data,
        maintenanceNumber,
      },
    });
  });
};

export const updateRecord = async (id, data) => {
  return await prisma.maintenanceRecord.update({
    where: { id },
    data,
    include: { parts: true },
  });
};

export const getRecordById = async (id) => {
  return await prisma.maintenanceRecord.findUnique({
    where: { id },
    include: {
      asset: { include: { status: true, condition: true } },
      request: true,
      vendor: true,
      parts: true,
      attachments: true,
    },
  });
};

export const getRecordsList = async ({ page = 1, limit = 10, search = '', status, maintenanceType, assetId }) => {
  const skip = (page - 1) * limit;
  const where = {};

  if (status) where.status = status;
  if (maintenanceType) where.maintenanceType = maintenanceType;
  if (assetId) where.assetId = assetId;

  if (search) {
    where.OR = [
      { maintenanceNumber: { contains: search } },
      { technicianName: { contains: search } },
      { asset: { assetName: { contains: search } } },
      { asset: { assetTag: { contains: search } } },
    ];
  }

  const [records, total] = await prisma.$transaction([
    prisma.maintenanceRecord.findMany({
      where,
      skip,
      take: limit,
      orderBy: { startDate: 'desc' },
      include: {
        asset: { select: { assetTag: true, assetName: true } },
        vendor: { select: { vendorName: true } },
      },
    }),
    prisma.maintenanceRecord.count({ where }),
  ]);

  return { records, total };
};

// =========================================================================
// Spare Parts Management
// =========================================================================

export const addPartToRecord = async (maintenanceId, partData) => {
  return await prisma.maintenancePart.create({
    data: {
      maintenanceId,
      ...partData,
    },
  });
};

export const removePartsForRecord = async (maintenanceId) => {
  return await prisma.maintenancePart.deleteMany({
    where: { maintenanceId },
  });
};

// =========================================================================
// Maintenance Schedules
// =========================================================================

export const createSchedule = async (data) => {
  return await prisma.maintenanceSchedule.create({ data });
};

export const updateSchedule = async (id, data) => {
  return await prisma.maintenanceSchedule.update({
    where: { id },
    data,
  });
};

export const getScheduleById = async (id) => {
  return await prisma.maintenanceSchedule.findUnique({
    where: { id },
    include: {
      asset: true,
      technician: true,
      vendor: true,
    },
  });
};

export const getSchedulesList = async ({ page = 1, limit = 10, search = '', isActive }) => {
  const skip = (page - 1) * limit;
  const where = {};

  if (isActive !== undefined) where.isActive = isActive;

  if (search) {
    where.OR = [
      { scheduleName: { contains: search } },
      { asset: { assetName: { contains: search } } },
      { asset: { assetTag: { contains: search } } },
    ];
  }

  const [schedules, total] = await prisma.$transaction([
    prisma.maintenanceSchedule.findMany({
      where,
      skip,
      take: limit,
      orderBy: { nextMaintenanceDate: 'asc' },
      include: {
        asset: { select: { assetTag: true, assetName: true } },
        technician: { select: { name: true } },
      },
    }),
    prisma.maintenanceSchedule.count({ where }),
  ]);

  return { schedules, total };
};

// =========================================================================
// Technician Directory
// =========================================================================

export const createTechnician = async (data) => {
  return await prisma.technician.create({ data });
};

export const updateTechnician = async (id, data) => {
  return await prisma.technician.update({
    where: { id },
    data,
  });
};

export const getTechnicianById = async (id) => {
  return await prisma.technician.findUnique({
    where: { id },
    include: { vendor: true },
  });
};

export const getTechniciansList = async ({ page = 1, limit = 10, search = '', status }) => {
  const skip = (page - 1) * limit;
  const where = {};

  if (status) where.status = status;

  if (search) {
    where.OR = [
      { name: { contains: search } },
      { employeeId: { contains: search } },
      { specialization: { contains: search } },
    ];
  }

  const [technicians, total] = await prisma.$transaction([
    prisma.technician.findMany({
      where,
      skip,
      take: limit,
      orderBy: { name: 'asc' },
      include: { vendor: { select: { vendorName: true } } },
    }),
    prisma.technician.count({ where }),
  ]);

  return { technicians, total };
};

// =========================================================================
// Attachments
// =========================================================================

export const createAttachment = async (data) => {
  return await prisma.maintenanceAttachment.create({ data });
};
export const getAttachmentsForRecord = async (maintenanceId) => {
  return await prisma.maintenanceAttachment.findMany({
    where: { maintenanceId },
  });
};

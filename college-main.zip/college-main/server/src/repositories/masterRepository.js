import prisma from '../database/index.js';

// =========================================================================
// Category Operations
// =========================================================================

export const createCategory = async (data) => {
  return await prisma.assetCategory.create({ data });
};

export const updateCategory = async (id, data) => {
  return await prisma.assetCategory.update({
    where: { id },
    data,
  });
};

export const softDeleteCategory = async (id) => {
  return await prisma.assetCategory.update({
    where: { id },
    data: { deletedAt: new Date(), isActive: false },
  });
};

export const restoreCategory = async (id) => {
  return await prisma.assetCategory.update({
    where: { id },
    data: { deletedAt: null, isActive: true },
  });
};

export const getCategoryById = async (id) => {
  return await prisma.assetCategory.findFirst({
    where: { id, deletedAt: null },
    include: { createdByUser: true, updatedByUser: true },
  });
};

export const findCategoryByCode = async (categoryCode) => {
  return await prisma.assetCategory.findFirst({
    where: { categoryCode, deletedAt: null },
  });
};

export const findCategoryByName = async (categoryName) => {
  return await prisma.assetCategory.findFirst({
    where: { categoryName, deletedAt: null },
  });
};

export const getCategoriesList = async ({ page = 1, limit = 10, search = '', isActive, showDeleted = false }) => {
  const skip = (page - 1) * limit;
  const where = {
    deletedAt: showDeleted ? { not: null } : null,
  };

  if (isActive !== undefined) {
    where.isActive = isActive;
  }

  if (search) {
    where.OR = [
      { categoryName: { contains: search } },
      { categoryCode: { contains: search } },
    ];
  }

  const [categories, total] = await prisma.$transaction([
    prisma.assetCategory.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: { createdByUser: true }
    }),
    prisma.assetCategory.count({ where }),
  ]);

  return { categories, total };
};

// =========================================================================
// Location Operations
// =========================================================================

export const createLocation = async (data) => {
  return await prisma.location.create({ data });
};

export const updateLocation = async (id, data) => {
  return await prisma.location.update({
    where: { id },
    data,
  });
};

export const softDeleteLocation = async (id) => {
  return await prisma.location.update({
    where: { id },
    data: { deletedAt: new Date(), isActive: false },
  });
};

export const restoreLocation = async (id) => {
  return await prisma.location.update({
    where: { id },
    data: { deletedAt: null, isActive: true },
  });
};

export const getLocationById = async (id) => {
  return await prisma.location.findFirst({
    where: { id, deletedAt: null },
    include: { createdByUser: true, updatedByUser: true },
  });
};

export const findLocationByCode = async (locationCode) => {
  return await prisma.location.findFirst({
    where: { locationCode, deletedAt: null },
  });
};

export const getLocationsList = async ({ page = 1, limit = 10, search = '', isActive, showDeleted = false }) => {
  const skip = (page - 1) * limit;
  const where = {
    deletedAt: showDeleted ? { not: null } : null,
  };

  if (isActive !== undefined) {
    where.isActive = isActive;
  }

  if (search) {
    where.OR = [
      { locationName: { contains: search } },
      { locationCode: { contains: search } },
      { building: { contains: search } },
    ];
  }

  const [locations, total] = await prisma.$transaction([
    prisma.location.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: { createdByUser: true }
    }),
    prisma.location.count({ where }),
  ]);

  return { locations, total };
};

// =========================================================================
// Vendor Operations
// =========================================================================

export const createVendor = async (data) => {
  return await prisma.vendor.create({ data });
};

export const updateVendor = async (id, data) => {
  return await prisma.vendor.update({
    where: { id },
    data,
  });
};

export const softDeleteVendor = async (id) => {
  return await prisma.vendor.update({
    where: { id },
    data: { deletedAt: new Date(), isActive: false },
  });
};

export const restoreVendor = async (id) => {
  return await prisma.vendor.update({
    where: { id },
    data: { deletedAt: null, isActive: true },
  });
};

export const getVendorById = async (id) => {
  return await prisma.vendor.findFirst({
    where: { id, deletedAt: null },
    include: { createdByUser: true, updatedByUser: true },
  });
};

export const findVendorByCode = async (vendorCode) => {
  return await prisma.vendor.findFirst({
    where: { vendorCode, deletedAt: null },
  });
};

export const getVendorsList = async ({ page = 1, limit = 10, search = '', isActive, showDeleted = false }) => {
  const skip = (page - 1) * limit;
  const where = {
    deletedAt: showDeleted ? { not: null } : null,
  };

  if (isActive !== undefined) {
    where.isActive = isActive;
  }

  if (search) {
    where.OR = [
      { vendorName: { contains: search } },
      { vendorCode: { contains: search } },
      { contactPerson: { contains: search } },
    ];
  }

  const [vendors, total] = await prisma.$transaction([
    prisma.vendor.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: { createdByUser: true }
    }),
    prisma.vendor.count({ where }),
  ]);

  return { vendors, total };
};

// =========================================================================
// Manufacturer Operations
// =========================================================================

export const createManufacturer = async (data) => {
  return await prisma.manufacturer.create({ data });
};

export const updateManufacturer = async (id, data) => {
  return await prisma.manufacturer.update({
    where: { id },
    data,
  });
};

export const softDeleteManufacturer = async (id) => {
  return await prisma.manufacturer.update({
    where: { id },
    data: { deletedAt: new Date(), isActive: false },
  });
};

export const restoreManufacturer = async (id) => {
  return await prisma.manufacturer.update({
    where: { id },
    data: { deletedAt: null, isActive: true },
  });
};

export const getManufacturerById = async (id) => {
  return await prisma.manufacturer.findFirst({
    where: { id, deletedAt: null },
  });
};

export const findManufacturerByCode = async (manufacturerCode) => {
  return await prisma.manufacturer.findFirst({
    where: { manufacturerCode, deletedAt: null },
  });
};

export const getManufacturersList = async ({ page = 1, limit = 10, search = '', isActive, showDeleted = false }) => {
  const skip = (page - 1) * limit;
  const where = {
    deletedAt: showDeleted ? { not: null } : null,
  };

  if (isActive !== undefined) {
    where.isActive = isActive;
  }

  if (search) {
    where.OR = [
      { manufacturerName: { contains: search } },
      { manufacturerCode: { contains: search } },
    ];
  }

  const [manufacturers, total] = await prisma.$transaction([
    prisma.manufacturer.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    }),
    prisma.manufacturer.count({ where }),
  ]);

  return { manufacturers, total };
};

// =========================================================================
// Meta & Metric Counts
// =========================================================================

export const getMasterMetrics = async () => {
  const [categories, locations, vendors, manufacturers] = await Promise.all([
    prisma.assetCategory.count({ where: { deletedAt: null } }),
    prisma.location.count({ where: { deletedAt: null } }),
    prisma.vendor.count({ where: { deletedAt: null } }),
    prisma.manufacturer.count({ where: { deletedAt: null } }),
  ]);

  return {
    categories,
    locations,
    vendors,
    manufacturers,
  };
};

import prisma from '../database/index.js';

// =========================================================================
// Global System Settings
// =========================================================================

export const getSettings = async () => {
  return await prisma.systemSetting.findMany();
};

export const updateSetting = async (key, value, userId) => {
  return await prisma.systemSetting.upsert({
    where: { settingKey: key },
    update: {
      settingValue: String(value),
      updatedBy: userId,
    },
    create: {
      settingKey: key,
      settingValue: String(value),
      updatedBy: userId,
    },
  });
};

// =========================================================================
// User preferences
// =========================================================================

export const getUserPreferences = async (userId) => {
  return await prisma.userPreference.findUnique({
    where: { userId },
  });
};

export const updateUserPreferences = async (userId, data) => {
  return await prisma.userPreference.upsert({
    where: { userId },
    update: data,
    create: {
      userId,
      ...data,
    },
  });
};
export const getSettingByKey = async (key) => {
  return await prisma.systemSetting.findUnique({
    where: { settingKey: key },
  });
};

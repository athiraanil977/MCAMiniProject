import prisma from '../database/index.js';

export const createBackupRecord = async (data) => {
  return await prisma.backupHistory.create({ data });
};

export const updateBackupRecord = async (id, data) => {
  return await prisma.backupHistory.update({ where: { id }, data });
};

export const getBackupsList = async ({ page = 1, limit = 10 }) => {
  const skip = (page - 1) * limit;
  const [backups, total] = await prisma.$transaction([
    prisma.backupHistory.findMany({
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { name: true, email: true } } },
    }),
    prisma.backupHistory.count(),
  ]);
  return { backups, total };
};

export const getBackupById = async (id) => {
  return await prisma.backupHistory.findUnique({
    where: { id },
    include: { user: { select: { name: true } } },
  });
};

export const deleteBackupRecord = async (id) => {
  return await prisma.backupHistory.delete({ where: { id } });
};

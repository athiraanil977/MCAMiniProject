import prisma from '../database/index.js';

export const getAllRoles = async () => {
  return await prisma.role.findMany({
    orderBy: { roleName: 'asc' },
  });
};

export const findRoleById = async (id) => {
  return await prisma.role.findUnique({
    where: { id },
  });
};

export const findRoleByName = async (roleName) => {
  return await prisma.role.findUnique({
    where: { roleName },
  });
};

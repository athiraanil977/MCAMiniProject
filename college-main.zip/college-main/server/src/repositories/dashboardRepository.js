import prisma from '../database/index.js';

// =========================================================================
// Executive KPI Cards & Totals Aggregations
// =========================================================================

export const getDashboardKPICards = async () => {
  const [
    statuses,
    totalDepts,
    totalVendors,
    totalUsers,
    totalMaintRequests,
    totalMaintCostAggregate,
    totalAssetValueAggregate,
  ] = await Promise.all([
    prisma.asset.groupBy({
      by: ['statusId'],
      _count: { _all: true },
    }),
    prisma.department.count(),
    prisma.vendor.count(),
    prisma.user.count(),
    prisma.maintenanceRequest.count(),
    prisma.maintenanceRecord.aggregate({
      _sum: { cost: true },
    }),
    prisma.asset.aggregate({
      _sum: { purchaseCost: true },
    }),
  ]);

  // Load Status Map to match counts
  const statusMappings = await prisma.assetStatus.findMany();
  const statusCounts = {};
  statusMappings.forEach((s) => {
    statusCounts[s.statusName] = 0;
  });

  statuses.forEach((g) => {
    const sName = statusMappings.find((m) => m.id === g.statusId)?.statusName;
    if (sName) {
      statusCounts[sName] = g._count._all;
    }
  });

  const now = new Date();
  const thirtyDaysLater = new Date();
  thirtyDaysLater.setDate(now.getDate() + 30);

  const [warrantyExpiredCount, warrantyExpiringSoonCount] = await Promise.all([
    prisma.asset.count({
      where: {
        warrantyEnd: { lt: now },
      },
    }),
    prisma.asset.count({
      where: {
        warrantyEnd: {
          gt: now,
          lte: thirtyDaysLater,
        },
      },
    }),
  ]);

  return {
    totalAssets: await prisma.asset.count({ where: { deletedAt: null } }),
    availableAssets: statusCounts['Available'] || 0,
    allocatedAssets: statusCounts['Allocated'] || 0,
    reservedAssets: statusCounts['Reserved'] || 0,
    maintenanceAssets: statusCounts['Maintenance'] || 0,
    disposedAssets: statusCounts['Disposed'] || 0,
    lostAssets: statusCounts['Lost'] || 0,
    warrantyExpired: warrantyExpiredCount,
    warrantyExpiringSoon: warrantyExpiringSoonCount,
    totalDepartments: totalDepts,
    totalVendors: totalVendors,
    totalUsers: totalUsers,
    totalMaintenanceRequests: totalMaintRequests,
    totalMaintenanceCost: parseFloat(totalMaintCostAggregate._sum.cost || 0),
    totalAssetValue: parseFloat(totalAssetValueAggregate._sum.purchaseCost || 0),
  };
};

// =========================================================================
// Charts Aggregation Pipeline
// =========================================================================

export const getDashboardChartsData = async () => {
  const [
    categories,
    departments,
    locations,
    conditions,
    vendorAssets,
  ] = await Promise.all([
    prisma.assetCategory.findMany({ select: { id: true, categoryName: true } }),
    prisma.department.findMany({ select: { id: true, departmentName: true } }),
    prisma.location.findMany({ select: { id: true, locationName: true } }),
    prisma.condition.findMany({ select: { id: true, conditionName: true } }),
    prisma.vendor.findMany({ select: { id: true, vendorName: true } }),
  ]);

  const [
    byCategoryGroup,
    byDeptGroup,
    byLocGroup,
    byConditionGroup,
    byVendorGroup,
  ] = await Promise.all([
    prisma.asset.groupBy({
      by: ['categoryId'],
      _count: { _all: true },
      _sum: { purchaseCost: true },
    }),
    prisma.asset.groupBy({
      by: ['departmentId'],
      _count: { _all: true },
    }),
    prisma.asset.groupBy({
      by: ['locationId'],
      _count: { _all: true },
    }),
    prisma.asset.groupBy({
      by: ['conditionId'],
      _count: { _all: true },
    }),
    prisma.asset.groupBy({
      by: ['vendorId'],
      _count: { _all: true },
    }),
  ]);

  // Map category counts
  const assetsByCategory = byCategoryGroup.map((g) => ({
    categoryName: categories.find((c) => c.id === g.categoryId)?.categoryName || 'Unknown',
    count: g._count._all,
    value: parseFloat(g._sum.purchaseCost || 0),
  }));

  // Map dept counts
  const assetsByDepartment = byDeptGroup.map((g) => ({
    departmentName: departments.find((d) => d.id === g.departmentId)?.departmentName || 'Not Assigned',
    count: g._count._all,
  }));

  // Map loc counts
  const assetsByLocation = byLocGroup.map((g) => ({
    locationName: locations.find((l) => l.id === g.locationId)?.locationName || 'Unknown',
    count: g._count._all,
  }));

  // Map condition counts
  const assetsByCondition = byConditionGroup.map((g) => ({
    conditionName: conditions.find((c) => c.id === g.conditionId)?.conditionName || 'Unknown',
    count: g._count._all,
  }));

  // Map vendor counts
  const assetsByVendor = byVendorGroup.map((g) => ({
    vendorName: vendorAssets.find((v) => v.id === g.vendorId)?.vendorName || 'Unknown',
    count: g._count._all,
  }));

  return {
    assetsByCategory,
    assetsByDepartment,
    assetsByLocation,
    assetsByCondition,
    assetsByVendor,
  };
};

// =========================================================================
// Real-Time Audit Activities Logs
// =========================================================================

export const getRecentActivities = async () => {
  return await prisma.assetHistory.findMany({
    take: 10,
    orderBy: { createdAt: 'desc' },
    include: {
      asset: { select: { assetTag: true, assetName: true } },
      user: { select: { name: true, profileImage: true } },
    },
  });
};

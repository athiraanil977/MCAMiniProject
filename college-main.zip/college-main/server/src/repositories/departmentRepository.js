import prisma from '../database/index.js';

export const getAllDepartments = async () => {
  return await prisma.department.findMany({
    orderBy: { departmentName: 'asc' },
  });
};

export const findDepartmentById = async (id) => {
  return await prisma.department.findUnique({
    where: { id },
  });
};

export const findDepartmentByName = async (departmentName) => {
  return await prisma.department.findUnique({
    where: { departmentName },
  });
};

import prisma from '../database/index.js';

export const findUserById = async (id, includeRelations = true) => {
  return await prisma.user.findFirst({
    where: { 
      id,
      deletedAt: null // Soft-delete filter
    },
    include: includeRelations ? {
      role: {
        include: {
          permissions: {
            include: {
              permission: true
            }
          }
        }
      },
      department: true
    } : undefined
  });
};

export const findUserByEmail = async (email, includeRelations = true) => {
  return await prisma.user.findFirst({
    where: { 
      email,
      deletedAt: null // Soft-delete filter
    },
    include: includeRelations ? {
      role: {
        include: {
          permissions: {
            include: {
              permission: true
            }
          }
        }
      },
      department: true
    } : undefined
  });
};

export const findUserByEmployeeId = async (employeeId) => {
  return await prisma.user.findFirst({
    where: { 
      employeeId,
      deletedAt: null 
    }
  });
};

export const createUser = async (userData) => {
  return await prisma.user.create({
    data: userData,
    include: {
      role: true,
      department: true
    }
  });
};

export const updateUser = async (id, updateData) => {
  return await prisma.user.update({
    where: { id },
    data: updateData,
    include: {
      role: true,
      department: true
    }
  });
};

export const softDeleteUser = async (id) => {
  return await prisma.user.update({
    where: { id },
    data: { 
      deletedAt: new Date(),
      status: 'INACTIVE'
    }
  });
};

export const updateUserStatus = async (id, status) => {
  return await prisma.user.update({
    where: { id },
    data: { status }
  });
};

export const updateLastLogin = async (id) => {
  return await prisma.user.update({
    where: { id },
    data: { lastLogin: new Date() }
  });
};

export const updatePassword = async (id, hashedPassword) => {
  return await prisma.user.update({
    where: { id },
    data: { password: hashedPassword }
  });
};

export const getUsersList = async ({ page = 1, limit = 10, search = '', roleId, departmentId, status }) => {
  const skip = (page - 1) * limit;

  // Build filters
  const where = {
    deletedAt: null, // Soft delete exclusion
  };

  if (roleId) {
    where.roleId = parseInt(roleId, 10);
  }

  if (departmentId) {
    where.departmentId = parseInt(departmentId, 10);
  }

  if (status) {
    where.status = status;
  }

  if (search) {
    where.OR = [
      { name: { contains: search } },
      { email: { contains: search } },
      { employeeId: { contains: search } }
    ];
  }

  const [users, total] = await prisma.$transaction([
    prisma.user.findMany({
      where,
      skip,
      take: limit,
      include: {
        role: true,
        department: true
      },
      orderBy: { createdAt: 'desc' }
    }),
    prisma.user.count({ where })
  ]);

  return { users, total };
};

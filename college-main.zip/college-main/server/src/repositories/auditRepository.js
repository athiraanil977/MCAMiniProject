import prisma from '../database/index.js';

export const createAuditLog = async (data) => {
  return await prisma.auditLog.create({
    data,
  });
};

export const getAuditLogsList = async ({ page = 1, limit = 10, search = '', userId, module, action }) => {
  const skip = (page - 1) * limit;
  const where = {};

  if (userId) where.userId = userId;
  if (module) where.module = module;
  if (action) where.action = action;

  if (search) {
    where.OR = [
      { module: { contains: search } },
      { action: { contains: search } },
      { entity: { contains: search } },
      { ipAddress: { contains: search } },
      { user: { name: { contains: search } } },
    ];
  }

  const [logs, total] = await prisma.$transaction([
    prisma.auditLog.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { name: true, email: true } },
      },
    }),
    prisma.auditLog.count({ where }),
  ]);

  return { logs, total };
};
export const getAuditLogById = async (id) => {
  return await prisma.auditLog.findUnique({
    where: { id },
    include: {
      user: { select: { name: true, email: true } },
    },
  });
};

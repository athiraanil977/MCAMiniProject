export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  ACCEPTED: 202,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500,
};

export const ROLES = {
  ADMIN: 'ADMIN',
  MANAGER: 'MANAGER',
  STAFF: 'STAFF',
};

export const ASSET_STATUS = {
  AVAILABLE: 'AVAILABLE',
  IN_USE: 'IN_USE',
  UNDER_MAINTENANCE: 'UNDER_MAINTENANCE',
  RETIRED: 'RETIRED',
  LOST: 'LOST',
};

export const USER_STATUS = {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  PENDING: 'PENDING',
};

export const PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 10,
  MAX_LIMIT: 100,
};

export const API_ROUTES = {
  AUTH: '/api/auth',
  ASSETS: '/api/assets',
  CATEGORIES: '/api/categories',
  LOCATIONS: '/api/locations',
  VENDORS: '/api/vendors',
  MAINTENANCE: '/api/maintenance',
  USERS: '/api/users',
  DASHBOARD: '/api/dashboard',
  REPORTS: '/api/reports',
};

export const MESSAGES = {
  AUTH: {
    LOGIN_SUCCESS: 'Logged in successfully',
    LOGIN_FAILED: 'Invalid credentials',
    UNAUTHORIZED: 'Unauthorized access',
    FORBIDDEN: 'Access forbidden',
    TOKEN_EXPIRED: 'Token has expired',
    TOKEN_INVALID: 'Invalid token',
    LOGOUT_SUCCESS: 'Logged out successfully',
  },
  DATABASE: {
    CONNECTION_SUCCESS: 'Database connection established successfully',
    CONNECTION_FAILED: 'Database connection failed',
  },
  GENERAL: {
    SUCCESS: 'Success',
    ERROR: 'An unexpected error occurred',
    NOT_FOUND: 'Resource not found',
    VALIDATION_FAILED: 'Validation failed',
  },
};

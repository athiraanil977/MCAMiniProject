import app from './app.js';
import prisma from './database/index.js';
import dotenv from 'dotenv';

dotenv.config();

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    console.log('Initializing Prisma Database connection test...');
    // Query MySQL engine directly to check state without defined tables
    await prisma.$queryRaw`SELECT 1`;
    console.log('Database connection check: SUCCESS.');
  } catch (error) {
    console.warn('Database connection check: FAILED.');
    console.warn('Reason: Please make sure your database URL in .env is configured and MySQL service is running.');
    console.warn('Continuing server startup (Prisma client will attempt lazy reconnects)...');
  }

  const server = app.listen(PORT, () => {
    console.log(`Server is running in [${process.env.NODE_ENV || 'development'}] mode on port ${PORT}`);
  });

  // Graceful termination handling
  const gracefulShutdown = async (signal) => {
    console.log(`Received ${signal}. Starting graceful shutdown...`);
    server.close(async () => {
      await prisma.$disconnect();
      console.log('Database disconnected. HTTP server closed.');
      process.exit(0);
    });
  };

  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
}

startServer();

import path from 'path';
import fs from 'fs';

export const getFileMetadata = (file) => {
  if (!file) return null;
  return {
    filename: file.filename,
    originalName: file.originalname,
    mimeType: file.mimetype,
    size: file.size,
    path: file.path,
  };
};

export const checkFileExists = (filePath) => {
  if (!filePath) return false;
  return fs.existsSync(path.resolve(filePath));
};

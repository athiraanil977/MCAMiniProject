export const formatError = (err) => {
  const isDev = process.env.NODE_ENV === 'development';
  return {
    message: err.message || 'An internal server error occurred',
    ...(isDev && { stack: err.stack }),
    ...(err.errors && { errors: err.errors }),
  };
};

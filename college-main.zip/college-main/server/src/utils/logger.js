import { createLogger, format, transports } from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import path from 'path';
import fs from 'fs';

const LOG_DIR = process.env.LOG_DIR || 'logs';
const LOG_LEVEL = process.env.LOG_LEVEL || 'info';
const isDev = process.env.NODE_ENV !== 'production';

// Ensure log directory exists
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

const { combine, timestamp, errors, json, colorize, printf } = format;

// Dev console format: colorized, readable
const devConsoleFormat = combine(
  colorize({ all: true }),
  timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  errors({ stack: true }),
  printf(({ level, message, timestamp: ts, stack, ...meta }) => {
    const extras = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : '';
    return `${ts} [${level}]: ${message}${stack ? '\n' + stack : ''}${extras}`;
  })
);

// Production format: structured JSON
const prodFormat = combine(
  timestamp(),
  errors({ stack: true }),
  json()
);

// Daily rotating file transport – combined logs
const combinedFileTransport = new DailyRotateFile({
  filename: path.join(LOG_DIR, 'combined-%DATE%.log'),
  datePattern: 'YYYY-MM-DD',
  maxFiles: `${process.env.BACKUP_RETENTION_DAYS || 30}d`,
  zippedArchive: true,
  level: LOG_LEVEL,
  format: combine(timestamp(), errors({ stack: true }), json()),
});

// Daily rotating file transport – errors only
const errorFileTransport = new DailyRotateFile({
  filename: path.join(LOG_DIR, 'error-%DATE%.log'),
  datePattern: 'YYYY-MM-DD',
  maxFiles: '30d',
  zippedArchive: true,
  level: 'error',
  format: combine(timestamp(), errors({ stack: true }), json()),
});

const logger = createLogger({
  level: LOG_LEVEL,
  defaultMeta: { service: 'college-asset-mgmt' },
  transports: [
    new transports.Console({
      format: isDev ? devConsoleFormat : prodFormat,
    }),
    combinedFileTransport,
    errorFileTransport,
  ],
  exitOnError: false,
});

export default logger;

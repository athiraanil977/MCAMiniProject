import { ZodError } from 'zod';
import { HTTP_STATUS } from '../constants/index.js';
import { errorResponse } from './responseFormatter.js';

export const validateSchema = (schema) => {
  return async (req, res, next) => {
    try {
      if (schema.body) {
        req.body = await schema.body.parseAsync(req.body);
      }
      if (schema.query) {
        req.query = await schema.query.parseAsync(req.query);
      }
      if (schema.params) {
        req.params = await schema.params.parseAsync(req.params);
      }
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const formattedErrors = error.errors.map((err) => ({
          field: err.path.join('.'),
          message: err.message,
        }));
        return errorResponse(res, HTTP_STATUS.BAD_REQUEST, 'Validation failed', formattedErrors);
      }
      next(error);
    }
  };
};

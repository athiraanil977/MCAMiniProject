import * as reportService from '../services/reportService.js';
import * as exportService from '../services/exportService.js';
import { successResponse } from '../utils/responseFormatter.js';
import { HTTP_STATUS } from '../constants/index.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

// =========================================================================
// Report Query Handlers
// =========================================================================

export const getAssetsReport = asyncHandler(async (req, res) => {
  const result = await reportService.getAssetsReport(req.query);
  return successResponse(res, HTTP_STATUS.OK, 'Assets report retrieved', result);
});

export const getMaintenanceReport = asyncHandler(async (req, res) => {
  const result = await reportService.getMaintenanceReport(req.query);
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance report retrieved', result);
});

export const getFinancialReport = asyncHandler(async (req, res) => {
  const result = await reportService.getFinancialReport(req.query);
  return successResponse(res, HTTP_STATUS.OK, 'Financial depreciation report retrieved', result);
});

// =========================================================================
// Saved Report Handlers
// =========================================================================

export const saveReport = asyncHandler(async (req, res) => {
  const result = await reportService.saveUserReport(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Saved report configuration logged', result);
});

export const getSavedReports = asyncHandler(async (req, res) => {
  const result = await reportService.listSavedReports(req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Saved reports retrieved', result);
});

// =========================================================================
// Excel / CSV Export Processor
// =========================================================================

export const exportReport = asyncHandler(async (req, res) => {
  const { format, reportType, filters } = req.body;
  
  let data = [];
  let headers = [];

  if (reportType === 'assets') {
    const raw = await reportService.getAssetsReport(filters);
    data = raw.map((a) => ({
      assetTag: a.assetTag,
      assetName: a.assetName,
      serialNumber: a.serialNumber,
      categoryName: a.category?.categoryName || 'Unknown',
      departmentName: a.department?.departmentName || 'Not Assigned',
      locationName: a.location?.locationName || 'Unknown',
      conditionName: a.condition?.conditionName || 'Unknown',
      statusName: a.status?.statusName || 'Unknown',
      purchaseCost: a.purchaseCost ? parseFloat(a.purchaseCost) : 0,
    }));
    headers = [
      { label: 'Asset Tag', key: 'assetTag' },
      { label: 'Asset Name', key: 'assetName' },
      { label: 'Serial Number', key: 'serialNumber' },
      { label: 'Category', key: 'categoryName' },
      { label: 'Department', key: 'departmentName' },
      { label: 'Location', key: 'locationName' },
      { label: 'Condition', key: 'conditionName' },
      { label: 'Status', key: 'statusName' },
      { label: 'Purchase Cost ($)', key: 'purchaseCost' },
    ];
  } else if (reportType === 'maintenance') {
    const raw = await reportService.getMaintenanceReport(filters);
    data = raw.map((m) => ({
      maintenanceNumber: m.maintenanceNumber,
      assetTag: m.asset?.assetTag || 'Unknown',
      maintenanceType: m.maintenanceType,
      technicianName: m.technicianName || 'Not Assigned',
      vendorName: m.vendor?.vendorName || 'Not Assigned',
      downtimeHours: m.downtimeHours ? parseFloat(m.downtimeHours) : 0,
      cost: m.cost ? parseFloat(m.cost) : 0,
      labourCost: m.labourCost ? parseFloat(m.labourCost) : 0,
      partsCost: m.partsCost ? parseFloat(m.partsCost) : 0,
      resolution: m.resolution || '',
    }));
    headers = [
      { label: 'Repair Number', key: 'maintenanceNumber' },
      { label: 'Asset Tag', key: 'assetTag' },
      { label: 'Type', key: 'maintenanceType' },
      { label: 'Technician', key: 'technicianName' },
      { label: 'Vendor', key: 'vendorName' },
      { label: 'Downtime (Hours)', key: 'downtimeHours' },
      { label: 'Cost ($)', key: 'cost' },
      { label: 'Labour Cost ($)', key: 'labourCost' },
      { label: 'Parts Cost ($)', key: 'partsCost' },
      { label: 'Resolution', key: 'resolution' },
    ];
  } else if (reportType === 'financial') {
    data = await reportService.getFinancialReport(filters);
    headers = [
      { label: 'Asset Tag', key: 'assetTag' },
      { label: 'Asset Name', key: 'assetName' },
      { label: 'Category', key: 'categoryName' },
      { label: 'Department', key: 'departmentName' },
      { label: 'Purchase Cost ($)', key: 'purchaseCost' },
      { label: 'Age (Years)', key: 'ageYears' },
      { label: 'Acc. Depreciation ($)', key: 'accumulatedDepreciation' },
      { label: 'Current Book Value ($)', key: 'currentBookValue' },
    ];
  } else {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, message: 'Invalid reportType specified.' });
  }

  if (format === 'excel') {
    const buffer = await exportService.exportToExcel(reportType, headers, data);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${reportType}_report.xlsx"`);
    return res.send(buffer);
  } else {
    // CSV fallback
    const csvContent = exportService.exportToCSV(headers, data);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${reportType}_report.csv"`);
    return res.send(csvContent);
  }
});

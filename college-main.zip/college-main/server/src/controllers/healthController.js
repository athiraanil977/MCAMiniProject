import * as healthService from '../services/healthService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const getHealth = asyncHandler(async (req, res) => {
  const summary = await healthService.getSummary();
  const status = summary.status === 'healthy' ? HTTP_STATUS.OK : 207;
  return successResponse(res, status, 'Health check complete', summary);
});

export const getDatabaseHealth = asyncHandler(async (req, res) => {
  const result = await healthService.checkDatabase();
  return successResponse(res, HTTP_STATUS.OK, 'Database health check', result);
});

export const getStorageHealth = asyncHandler(async (req, res) => {
  const result = await healthService.checkStorage();
  return successResponse(res, HTTP_STATUS.OK, 'Storage health check', result);
});

export const getSystemHealth = asyncHandler(async (req, res) => {
  const result = await healthService.checkSystem();
  return successResponse(res, HTTP_STATUS.OK, 'System health check', result);
});

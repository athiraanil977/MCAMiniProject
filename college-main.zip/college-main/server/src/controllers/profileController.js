import bcrypt from 'bcrypt';
import prisma from '../database/index.js';
import * as settingsRepository from '../repositories/settingsRepository.js';
import * as auditService from '../services/auditService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';
import { z } from 'zod';

// Password criteria checking helper
const passwordSchema = z.string()
  .min(8, 'Password must be at least 8 characters long')
  .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
  .regex(/[0-9]/, 'Password must contain at least one number')
  .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character');

// =========================================================================
// Profile Handlers
// =========================================================================

export const getProfile = asyncHandler(async (req, res) => {
  const result = await prisma.user.findUnique({
    where: { id: req.user.id },
    include: {
      role: true,
      department: true,
      preferences: true,
    },
  });
  
  if (result) {
    delete result.password; // Strip hashed password
  }
  
  return successResponse(res, HTTP_STATUS.OK, 'Profile retrieved', result);
});

export const updateProfile = asyncHandler(async (req, res) => {
  const { name, phone } = req.body;
  const oldUser = await prisma.user.findUnique({ where: { id: req.user.id } });

  const updated = await prisma.user.update({
    where: { id: req.user.id },
    data: { name, phone },
  });

  delete updated.password;

  // Log activity
  await auditService.logActivity({
    userId: req.user.id,
    module: 'Profile',
    action: 'Update',
    entity: 'User',
    entityId: req.user.id,
    oldData: { name: oldUser.name, phone: oldUser.phone },
    newData: { name, phone },
  }, req);

  return successResponse(res, HTTP_STATUS.OK, 'Profile updated successfully', updated);
});

export const changePassword = asyncHandler(async (req, res) => {
  const { oldPassword, newPassword, confirmPassword } = req.body;

  if (newPassword !== confirmPassword) {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, message: 'New password and confirm password do not match.' });
  }

  // Enforce password criteria
  const passCheck = passwordSchema.safeParse(newPassword);
  if (!passCheck.success) {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({
      success: false,
      message: passCheck.error.errors[0].message,
    });
  }

  const userObj = await prisma.user.findUnique({ where: { id: req.user.id } });
  if (!userObj) {
    return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, message: 'User not found.' });
  }

  const matches = await bcrypt.compare(oldPassword, userObj.password);
  if (!matches) {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, message: 'Invalid current password.' });
  }

  // Save new hash
  const hashedPassword = await bcrypt.hash(newPassword, 10);
  await prisma.user.update({
    where: { id: req.user.id },
    data: { password: hashedPassword },
  });

  // Log activity
  await auditService.logActivity({
    userId: req.user.id,
    module: 'Profile',
    action: 'Password Change',
    entity: 'User',
    entityId: req.user.id,
    oldData: 'Hashed password mask',
    newData: 'Hashed password mask',
  }, req);

  return successResponse(res, HTTP_STATUS.OK, 'Password changed successfully');
});

export const updatePreferences = asyncHandler(async (req, res) => {
  const oldPref = await settingsRepository.getUserPreferences(req.user.id);
  const result = await settingsRepository.updateUserPreferences(req.user.id, req.body);

  // Log activity
  await auditService.logActivity({
    userId: req.user.id,
    module: 'Profile',
    action: 'Preference Changes',
    entity: 'UserPreference',
    entityId: String(result.id),
    oldData: oldPref,
    newData: result,
  }, req);

  return successResponse(res, HTTP_STATUS.OK, 'User preferences updated', result);
});

export const uploadPhoto = asyncHandler(async (req, res) => {
  if (!req.file) {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, message: 'No image file uploaded.' });
  }

  const profileImage = `/uploads/${req.file.filename}`;
  const oldUser = await prisma.user.findUnique({ where: { id: req.user.id } });

  await prisma.user.update({
    where: { id: req.user.id },
    data: { profileImage },
  });

  // Log activity
  await auditService.logActivity({
    userId: req.user.id,
    module: 'Profile',
    action: 'Update Photo',
    entity: 'User',
    entityId: req.user.id,
    oldData: { profileImage: oldUser.profileImage },
    newData: { profileImage },
  }, req);

  return successResponse(res, HTTP_STATUS.OK, 'Profile photo updated successfully', { profileImage });
});

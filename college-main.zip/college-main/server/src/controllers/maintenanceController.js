import * as maintenanceService from '../services/maintenanceService.js';
import * as maintenanceRepository from '../repositories/maintenanceRepository.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';
import prisma from '../database/index.js';

// =========================================================================
// Maintenance Request Handlers
// =========================================================================

export const createRequest = asyncHandler(async (req, res) => {
  const result = await maintenanceService.createRequest(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Maintenance request logged successfully', result);
});

export const updateRequest = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceService.updateRequest(parseInt(id, 10), req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance request updated successfully', result);
});

export const getRequest = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceRepository.getRequestById(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Request retrieved', result);
});

export const getRequests = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const status = req.query.status || undefined;
  const priority = req.query.priority || undefined;
  
  // Faculty can only view their own requests
  const requestedBy = (req.user.role === 'Faculty' || req.user.role === 'Department Staff') ? req.user.id : undefined;

  const { requests, total } = await maintenanceRepository.getRequestsList({
    page,
    limit,
    search,
    status,
    priority,
    requestedBy,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Requests list retrieved', requests, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

export const deleteRequest = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await prisma.maintenanceRequest.delete({ where: { id: parseInt(id, 10) } });
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance request deleted successfully');
});

// =========================================================================
// Maintenance Record Handlers
// =========================================================================

export const startRecord = asyncHandler(async (req, res) => {
  const result = await maintenanceService.startMaintenanceRecord(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Maintenance record initialized successfully', result);
});

export const completeRecord = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceService.completeMaintenanceRecord(parseInt(id, 10), req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance record finalized successfully', result);
});

export const getRecord = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceRepository.getRecordById(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Record retrieved', result);
});

export const getRecords = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const status = req.query.status || undefined;
  const maintenanceType = req.query.maintenanceType || undefined;
  const assetId = req.query.assetId ? parseInt(req.query.assetId, 10) : undefined;

  const { records, total } = await maintenanceRepository.getRecordsList({
    page,
    limit,
    search,
    status,
    maintenanceType,
    assetId,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Records list retrieved', records, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

export const deleteRecord = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await prisma.maintenanceRecord.delete({ where: { id: parseInt(id, 10) } });
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance record deleted successfully');
});

// =========================================================================
// Maintenance Schedule Handlers
// =========================================================================

export const createSchedule = asyncHandler(async (req, res) => {
  const result = await maintenanceService.createSchedule(req.body);
  return successResponse(res, HTTP_STATUS.CREATED, 'Maintenance schedule configured', result);
});

export const updateSchedule = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceService.updateSchedule(parseInt(id, 10), req.body);
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance schedule updated', result);
});

export const getSchedule = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceRepository.getScheduleById(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Schedule retrieved', result);
});

export const getSchedules = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const isActive = req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined;

  const { schedules, total } = await maintenanceRepository.getSchedulesList({
    page,
    limit,
    search,
    isActive,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Schedules list retrieved', schedules, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

export const deleteSchedule = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await prisma.maintenanceSchedule.delete({ where: { id: parseInt(id, 10) } });
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance schedule deleted successfully');
});

// =========================================================================
// Technician Handlers
// =========================================================================

export const createTechnician = asyncHandler(async (req, res) => {
  const result = await maintenanceRepository.createTechnician(req.body);
  return successResponse(res, HTTP_STATUS.CREATED, 'Technician registered successfully', result);
});

export const updateTechnician = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceRepository.updateTechnician(parseInt(id, 10), req.body);
  return successResponse(res, HTTP_STATUS.OK, 'Technician profile updated successfully', result);
});

export const getTechnician = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await maintenanceRepository.getTechnicianById(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Technician profile retrieved', result);
});

export const getTechnicians = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const status = req.query.status || undefined;

  const { technicians, total } = await maintenanceRepository.getTechniciansList({
    page,
    limit,
    search,
    status,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Technicians directory retrieved', technicians, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

export const deleteTechnician = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await prisma.technician.delete({ where: { id: parseInt(id, 10) } });
  return successResponse(res, HTTP_STATUS.OK, 'Technician profile deleted successfully');
});

// =========================================================================
// Dashboard Metrics
// =========================================================================

export const getMaintenanceMetrics = asyncHandler(async (req, res) => {
  const result = await maintenanceService.getDashboardMetrics();
  return successResponse(res, HTTP_STATUS.OK, 'Maintenance dashboard metrics retrieved', result);
});

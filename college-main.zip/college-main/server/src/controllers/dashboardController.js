import * as dashboardService from '../services/dashboardService.js';
import * as dashboardRepository from '../repositories/dashboardRepository.js';
import { successResponse } from '../utils/responseFormatter.js';
import { HTTP_STATUS } from '../constants/index.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const getDashboardSummary = asyncHandler(async (req, res) => {
  const bypass = req.query.bypass === 'true';
  const result = await dashboardService.getDashboardSummary(bypass);
  return successResponse(res, HTTP_STATUS.OK, 'Dashboard summary retrieved', result);
});

export const getDashboardCards = asyncHandler(async (req, res) => {
  const result = await dashboardRepository.getDashboardKPICards();
  return successResponse(res, HTTP_STATUS.OK, 'Dashboard cards retrieved', result);
});

export const getDashboardCharts = asyncHandler(async (req, res) => {
  const result = await dashboardRepository.getDashboardChartsData();
  return successResponse(res, HTTP_STATUS.OK, 'Dashboard charts retrieved', result);
});

export const getRecentActivitiesList = asyncHandler(async (req, res) => {
  const result = await dashboardRepository.getRecentActivities();
  return successResponse(res, HTTP_STATUS.OK, 'Recent audit activities list retrieved', result);
});

import * as assetService from '../services/assetService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

// =========================================================================
// Asset Core CRUD Controllers
// =========================================================================

export const createAsset = asyncHandler(async (req, res) => {
  const result = await assetService.createAsset(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Asset registered successfully', result);
});

export const updateAsset = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await assetService.updateAsset(parseInt(id, 10), req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Asset specifications updated successfully', result);
});

export const deleteAsset = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await assetService.deleteAsset(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Asset profile soft-deleted successfully');
});

export const restoreAsset = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await assetService.restoreAsset(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Asset profile restored successfully');
});

export const getAsset = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await assetService.getAsset(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Asset profile retrieved', result);
});

export const getAssets = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const categoryId = req.query.categoryId ? parseInt(req.query.categoryId, 10) : undefined;
  const departmentId = req.query.departmentId ? parseInt(req.query.departmentId, 10) : undefined;
  const locationId = req.query.locationId ? parseInt(req.query.locationId, 10) : undefined;
  const statusId = req.query.statusId ? parseInt(req.query.statusId, 10) : undefined;
  const conditionId = req.query.conditionId ? parseInt(req.query.conditionId, 10) : undefined;
  const showDeleted = req.query.showDeleted === 'true';
  const warrantyExpired = req.query.warrantyExpired === 'true';
  const includeReservations = req.query.includeReservations === 'true';
  const minCost = req.query.minCost ? parseFloat(req.query.minCost) : undefined;
  const maxCost = req.query.maxCost ? parseFloat(req.query.maxCost) : undefined;

  const { assets, total } = await assetService.listAssets({
    page,
    limit,
    search,
    categoryId,
    departmentId,
    locationId,
    statusId,
    conditionId,
    showDeleted,
    warrantyExpired,
    includeReservations,
    minCost,
    maxCost,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Asset list retrieved', assets, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// =========================================================================
// Lifecycle Operations
// =========================================================================

export const allocateAsset = asyncHandler(async (req, res) => {
  const result = await assetService.allocateAsset(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Asset allocated successfully', result);
});

export const returnAsset = asyncHandler(async (req, res) => {
  const result = await assetService.returnAsset(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Asset returned successfully', result);
});

export const transferAsset = asyncHandler(async (req, res) => {
  const result = await assetService.transferAsset(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Asset transferred successfully', result);
});

export const reserveAsset = asyncHandler(async (req, res) => {
  const result = await assetService.reserveAsset(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Reservation requested successfully', result);
});

export const approveReservation = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { status, remarks } = req.body; // Approved, Rejected
  const result = await assetService.approveOrRejectReservation(parseInt(id, 10), status, remarks, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, `Reservation ${status.toLowerCase()} successfully`, result);
});

export const disposeAsset = asyncHandler(async (req, res) => {
  const result = await assetService.disposeAsset(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Asset decommissioned/disposed successfully', result);
});

// =========================================================================
// File Uploads
// =========================================================================

export const uploadFile = asyncHandler(async (req, res) => {
  if (!req.file) {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({
      success: false,
      message: 'No file uploaded.',
    });
  }

  const filePath = `/uploads/${req.file.filename}`;
  const fileName = req.file.originalname;

  return successResponse(res, HTTP_STATUS.OK, 'File uploaded successfully', {
    filePath,
    fileName,
  });
});

export const addAssetDocument = asyncHandler(async (req, res) => {
  const result = await assetService.uploadAssetDocument(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Document attached successfully', result);
});

// =========================================================================
// Dashboard Metrics
// =========================================================================

export const getAssetMetrics = asyncHandler(async (req, res) => {
  const result = await assetService.getAssetDashboardMetrics();
  return successResponse(res, HTTP_STATUS.OK, 'Dashboard asset metrics retrieved', result);
});

import * as auditRepository from '../repositories/auditRepository.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const getAuditLogs = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const userId = req.query.userId || undefined;
  const module = req.query.module || undefined;
  const action = req.query.action || undefined;

  const { logs, total } = await auditRepository.getAuditLogsList({
    page,
    limit,
    search,
    userId,
    module,
    action,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Audit trails log list retrieved', logs, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

export const getAuditLog = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const log = await auditRepository.getAuditLogById(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Audit trail log retrieved', log);
});

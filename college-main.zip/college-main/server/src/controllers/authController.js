import * as authService from '../services/authService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const result = await authService.login(email, password);
  return successResponse(res, HTTP_STATUS.OK, 'Logged in successfully', result);
});

export const logout = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  await authService.logout(refreshToken);
  return successResponse(res, HTTP_STATUS.OK, 'Logged out successfully');
});

export const refresh = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  const result = await authService.refreshSession(refreshToken);
  return successResponse(res, HTTP_STATUS.OK, 'Session refreshed successfully', result);
});

export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const userId = req.user.id;
  await authService.changePassword(userId, currentPassword, newPassword);
  return successResponse(res, HTTP_STATUS.OK, 'Password updated successfully');
});

export const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const resetToken = await authService.requestPasswordReset(email);
  return successResponse(res, HTTP_STATUS.OK, 'Password reset token generated successfully', { resetToken });
});

export const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.body;
  await authService.completePasswordReset(token, password);
  return successResponse(res, HTTP_STATUS.OK, 'Password reset successfully');
});

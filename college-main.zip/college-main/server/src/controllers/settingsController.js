import * as settingsRepository from '../repositories/settingsRepository.js';
import * as auditService from '../services/auditService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const getSettings = asyncHandler(async (req, res) => {
  const list = await settingsRepository.getSettings();
  const result = {};
  list.forEach((s) => {
    result[s.settingKey] = s.settingValue;
  });
  return successResponse(res, HTTP_STATUS.OK, 'System settings retrieved', result);
});

export const updateSettings = asyncHandler(async (req, res) => {
  const oldSettingsList = await settingsRepository.getSettings();
  const oldSettings = {};
  oldSettingsList.forEach((s) => {
    oldSettings[s.settingKey] = s.settingValue;
  });

  const updates = req.body || {};
  const entries = Object.entries(updates);

  for (const [key, value] of entries) {
    await settingsRepository.updateSetting(key, String(value), req.user.id);
  }

  // Log activity
  await auditService.logActivity({
    userId: req.user.id,
    module: 'Settings',
    action: 'Settings Change',
    entity: 'SystemSetting',
    oldData: oldSettings,
    newData: updates,
  }, req);

  return successResponse(res, HTTP_STATUS.OK, 'System settings updated successfully', updates);
});

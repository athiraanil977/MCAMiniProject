import * as masterService from '../services/masterService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

// =========================================================================
// Category Controllers
// =========================================================================

export const createCategory = asyncHandler(async (req, res) => {
  const result = await masterService.createCategory(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Category created successfully', result);
});

export const updateCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.updateCategory(parseInt(id, 10), req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Category updated successfully', result);
});

export const deleteCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.deleteCategory(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Category deleted successfully');
});

export const restoreCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.restoreCategory(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Category restored successfully');
});

export const getCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.getCategory(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Category retrieved', result);
});

export const getCategories = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const isActive = req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined;
  const showDeleted = req.query.showDeleted === 'true';

  const { categories, total } = await masterService.listCategories({
    page,
    limit,
    search,
    isActive,
    showDeleted,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Categories list retrieved', categories, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// =========================================================================
// Location Controllers
// =========================================================================

export const createLocation = asyncHandler(async (req, res) => {
  const result = await masterService.createLocation(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Location created successfully', result);
});

export const updateLocation = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.updateLocation(parseInt(id, 10), req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Location updated successfully', result);
});

export const deleteLocation = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.deleteLocation(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Location deleted successfully');
});

export const restoreLocation = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.restoreLocation(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Location restored successfully');
});

export const getLocation = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.getLocation(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Location retrieved', result);
});

export const getLocations = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const isActive = req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined;
  const showDeleted = req.query.showDeleted === 'true';

  const { locations, total } = await masterService.listLocations({
    page,
    limit,
    search,
    isActive,
    showDeleted,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Locations list retrieved', locations, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// =========================================================================
// Vendor Controllers
// =========================================================================

export const createVendor = asyncHandler(async (req, res) => {
  const result = await masterService.createVendor(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Vendor created successfully', result);
});

export const updateVendor = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.updateVendor(parseInt(id, 10), req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Vendor updated successfully', result);
});

export const deleteVendor = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.deleteVendor(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Vendor deleted successfully');
});

export const restoreVendor = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.restoreVendor(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Vendor restored successfully');
});

export const getVendor = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.getVendor(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Vendor retrieved', result);
});

export const getVendors = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const isActive = req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined;
  const showDeleted = req.query.showDeleted === 'true';

  const { vendors, total } = await masterService.listVendors({
    page,
    limit,
    search,
    isActive,
    showDeleted,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Vendors list retrieved', vendors, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// =========================================================================
// Manufacturer Controllers
// =========================================================================

export const createManufacturer = asyncHandler(async (req, res) => {
  const result = await masterService.createManufacturer(req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.CREATED, 'Manufacturer created successfully', result);
});

export const updateManufacturer = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.updateManufacturer(parseInt(id, 10), req.body, req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Manufacturer updated successfully', result);
});

export const deleteManufacturer = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.deleteManufacturer(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Manufacturer deleted successfully');
});

export const restoreManufacturer = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await masterService.restoreManufacturer(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Manufacturer restored successfully');
});

export const getManufacturer = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const result = await masterService.getManufacturer(parseInt(id, 10));
  return successResponse(res, HTTP_STATUS.OK, 'Manufacturer retrieved', result);
});

export const getManufacturers = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const isActive = req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined;
  const showDeleted = req.query.showDeleted === 'true';

  const { manufacturers, total } = await masterService.listManufacturers({
    page,
    limit,
    search,
    isActive,
    showDeleted,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Manufacturers list retrieved', manufacturers, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// =========================================================================
// Dashboard / Metrics
// =========================================================================

export const getMasterMetrics = asyncHandler(async (req, res) => {
  const result = await masterService.getDashboardMasterMetrics();
  return successResponse(res, HTTP_STATUS.OK, 'Metrics retrieved successfully', result);
});

import * as notificationRepository from '../repositories/notificationRepository.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const getNotifications = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';

  const { notifications, total } = await notificationRepository.getNotificationsList({
    userId: req.user.id,
    page,
    limit,
    search,
  });

  return successResponse(res, HTTP_STATUS.OK, 'Notifications list retrieved', notifications, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

export const getUnreadCount = asyncHandler(async (req, res) => {
  const count = await notificationRepository.getUnreadCount(req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Unread count retrieved', { count });
});

export const markRead = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await notificationRepository.markAsRead(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Notification marked as read');
});

export const markAllRead = asyncHandler(async (req, res) => {
  await notificationRepository.markAllAsRead(req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'All notifications marked as read');
});

export const deleteNotification = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await notificationRepository.deleteNotification(parseInt(id, 10), req.user.id);
  return successResponse(res, HTTP_STATUS.OK, 'Notification deleted successfully');
});

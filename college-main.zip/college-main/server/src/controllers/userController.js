import * as userService from '../services/userService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const createUser = asyncHandler(async (req, res) => {
  const user = await userService.createUser(req.body);
  return successResponse(res, HTTP_STATUS.CREATED, 'User created successfully', user);
});

export const updateUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const user = await userService.updateUser(id, req.body);
  return successResponse(res, HTTP_STATUS.OK, 'User updated successfully', user);
});

export const deleteUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await userService.deleteUser(id);
  return successResponse(res, HTTP_STATUS.OK, 'User deleted successfully');
});

export const getUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const user = await userService.getUserById(id);
  return successResponse(res, HTTP_STATUS.OK, 'User details retrieved', user);
});

export const getUsers = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);
  const search = req.query.search || '';
  const roleId = req.query.roleId ? parseInt(req.query.roleId, 10) : undefined;
  const departmentId = req.query.departmentId ? parseInt(req.query.departmentId, 10) : undefined;
  const status = req.query.status;

  const { users, total } = await userService.listUsers({
    page,
    limit,
    search,
    roleId,
    departmentId,
    status
  });

  return successResponse(res, HTTP_STATUS.OK, 'Users list retrieved', users, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit)
  });
});

export const activateUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await userService.activateUser(id);
  return successResponse(res, HTTP_STATUS.OK, 'User activated successfully');
});

export const deactivateUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await userService.deactivateUser(id);
  return successResponse(res, HTTP_STATUS.OK, 'User deactivated successfully');
});

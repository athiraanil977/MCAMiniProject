import * as backupService from '../services/backupService.js';
import { HTTP_STATUS } from '../constants/index.js';
import { successResponse } from '../utils/responseFormatter.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';

export const listBackups = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '10', 10);

  const { backups, total } = await backupService.listBackups({ page, limit });

  return successResponse(res, HTTP_STATUS.OK, 'Backup history retrieved', backups, {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

export const createBackup = asyncHandler(async (req, res) => {
  const result = await backupService.createBackup(req.user.id, req);
  return successResponse(res, HTTP_STATUS.CREATED, 'Database backup created successfully', result);
});

export const deleteBackup = asyncHandler(async (req, res) => {
  const { id } = req.params;
  await backupService.deleteBackup(parseInt(id, 10), req.user.id, req);
  return successResponse(res, HTTP_STATUS.OK, 'Backup deleted successfully');
});

export const downloadBackup = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { filePath, fileName } = await backupService.getBackupFilePath(parseInt(id, 10));
  res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
  res.setHeader('Content-Type', 'application/zip');
  res.download(filePath, fileName);
});

import multer from 'multer';
import path from 'path';
import fs from 'fs';

const uploadRoot = process.env.UPLOAD_PATH || 'uploads';

// Subdirectory mapping by field name / route hint
const subDirMap = {
  file: 'documents',
  photo: 'profiles',
  profilePhoto: 'profiles',
  assetImage: 'assets',
  invoiceFile: 'invoices',
  logo: 'logos',
  maintenanceFile: 'maintenance',
};

// Sanitize filename: strip special chars, keep extension safe
const sanitizeFilename = (originalname) => {
  const ext = path.extname(originalname).toLowerCase();
  const base = path.basename(originalname, ext)
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .substring(0, 80);
  return `${base}${ext}`;
};

// Disk storage with dynamic sub-directory routing
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const subDir = subDirMap[file.fieldname] || 'documents';
    const dest = path.resolve(uploadRoot, subDir);
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const safeName = sanitizeFilename(file.originalname);
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e6)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}-${safeName}`);
  },
});

// Allowed MIME types whitelist
const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
];

const fileFilter = (req, file, cb) => {
  if (ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error(`File type not allowed: ${file.mimetype}. Allowed: PDF, PNG, JPG, JPEG, WEBP`), false);
  }
};

// Multer upload config – size from env
export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE || '5242880', 10), // Default 5 MB
  },
});

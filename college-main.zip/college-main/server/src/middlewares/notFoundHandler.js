import { HTTP_STATUS } from '../constants/index.js';
import { errorResponse } from '../utils/responseFormatter.js';

export const notFoundHandler = (req, res, next) => {
  return errorResponse(
    res,
    HTTP_STATUS.NOT_FOUND,
    `Route not found - ${req.method} ${req.originalUrl}`
  );
};

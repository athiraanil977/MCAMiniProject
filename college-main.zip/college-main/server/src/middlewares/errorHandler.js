import { HTTP_STATUS } from '../constants/index.js';
import { formatError } from '../utils/errorFormatter.js';
import { errorResponse } from '../utils/responseFormatter.js';
import logger from '../utils/logger.js';

export const errorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || HTTP_STATUS.INTERNAL_SERVER_ERROR;

  // Log with appropriate level
  if (statusCode >= 500) {
    logger.error(`[${req.method}] ${req.originalUrl} → ${err.message}`, {
      stack: err.stack,
      userId: req.user?.id || null,
      ip: req.ip,
      statusCode,
    });
  } else {
    logger.warn(`[${req.method}] ${req.originalUrl} → ${err.message}`, {
      userId: req.user?.id || null,
      ip: req.ip,
      statusCode,
    });
  }

  const errorDetails = formatError(err);

  return errorResponse(
    res,
    statusCode,
    errorDetails.message,
    errorDetails.errors || null
  );
};

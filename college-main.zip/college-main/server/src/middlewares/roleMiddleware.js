import { HTTP_STATUS, MESSAGES } from '../constants/index.js';
import { errorResponse } from '../utils/responseFormatter.js';

export const roleMiddleware = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return errorResponse(res, HTTP_STATUS.UNAUTHORIZED, MESSAGES.AUTH.UNAUTHORIZED);
    }

    if (!allowedRoles.includes(req.user.role)) {
      return errorResponse(res, HTTP_STATUS.FORBIDDEN, MESSAGES.AUTH.FORBIDDEN);
    }

    next();
  };
};

import { HTTP_STATUS, MESSAGES } from '../constants/index.js';
import { errorResponse } from '../utils/responseFormatter.js';

export const permissionMiddleware = (requiredPermission) => {
  return (req, res, next) => {
    if (!req.user) {
      return errorResponse(res, HTTP_STATUS.UNAUTHORIZED, MESSAGES.AUTH.UNAUTHORIZED);
    }

    const { permissions } = req.user;
    if (!permissions || !permissions.includes(requiredPermission)) {
      console.warn(`[AUTH] Permission Denied: User ${req.user.email} missing required permission "${requiredPermission}"`);
      return errorResponse(res, HTTP_STATUS.FORBIDDEN, MESSAGES.AUTH.FORBIDDEN);
    }

    next();
  };
};
export default permissionMiddleware;

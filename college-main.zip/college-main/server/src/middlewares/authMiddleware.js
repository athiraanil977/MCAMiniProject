import { HTTP_STATUS, MESSAGES } from '../constants/index.js';
import { verifyToken } from '../utils/jwtUtility.js';
import { errorResponse } from '../utils/responseFormatter.js';

export const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return errorResponse(res, HTTP_STATUS.UNAUTHORIZED, MESSAGES.AUTH.UNAUTHORIZED);
  }

  const token = authHeader.split(' ')[1];
  const decoded = verifyToken(token);

  if (!decoded) {
    return errorResponse(res, HTTP_STATUS.UNAUTHORIZED, MESSAGES.AUTH.TOKEN_INVALID);
  }

  // Attach user details to request object
  req.user = {
    id: decoded.id,
    email: decoded.email,
    role: decoded.role,
    permissions: decoded.permissions || [],
  };

  next();
};

import { rateLimit } from 'express-rate-limit';
import logger from '../utils/logger.js';

const windowMs = parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000', 10); // 15 min default

// Standard handler for all rate limit violations
const rateLimitHandler = (req, res) => {
  logger.warn(`Rate limit exceeded: ${req.method} ${req.originalUrl}`, {
    ip: req.ip,
    userId: req.user?.id || null,
  });
  res.status(429).json({
    success: false,
    message: 'Too many requests. Please slow down and try again later.',
  });
};

// General API limiter – 100 req / 15 min
export const generalLimiter = rateLimit({
  windowMs,
  max: parseInt(process.env.RATE_LIMIT_MAX || '100', 10),
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
});

// Auth endpoint limiter – 10 req / 15 min (brute-force protection)
export const authLimiter = rateLimit({
  windowMs,
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX || '10', 10),
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  skipSuccessfulRequests: true, // Only count failed requests
});

// Upload limiter – 20 uploads / 15 min
export const uploadLimiter = rateLimit({
  windowMs,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
});

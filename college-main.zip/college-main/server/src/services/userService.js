import * as userRepository from '../repositories/userRepository.js';
import { hashPassword } from '../utils/passwordUtility.js';

export const createUser = async (userData) => {
  const existingEmail = await userRepository.findUserByEmail(userData.email);
  if (existingEmail) {
    throw new Error('Email address is already registered');
  }

  if (userData.employeeId) {
    const existingEmployee = await userRepository.findUserByEmployeeId(userData.employeeId);
    if (existingEmployee) {
      throw new Error('Employee ID is already registered');
    }
  }

  const hashedPassword = await hashPassword(userData.password);

  const createdUser = await userRepository.createUser({
    ...userData,
    password: hashedPassword,
  });

  console.log(`[USER] User Created: ${createdUser.email} (ID: ${createdUser.id})`);
  return createdUser;
};

export const updateUser = async (id, updateData) => {
  const user = await userRepository.findUserById(id);
  if (!user) {
    throw new Error('User not found');
  }

  if (updateData.email && updateData.email !== user.email) {
    const existingEmail = await userRepository.findUserByEmail(updateData.email);
    if (existingEmail) {
      throw new Error('Email address is already registered');
    }
  }

  if (updateData.employeeId && updateData.employeeId !== user.employeeId) {
    const existingEmployee = await userRepository.findUserByEmployeeId(updateData.employeeId);
    if (existingEmployee) {
      throw new Error('Employee ID is already registered');
    }
  }

  if (updateData.password) {
    updateData.password = await hashPassword(updateData.password);
  }

  const updatedUser = await userRepository.updateUser(id, updateData);
  console.log(`[USER] User Updated: ${updatedUser.email} (ID: ${id})`);
  return updatedUser;
};

export const deleteUser = async (id) => {
  const user = await userRepository.findUserById(id);
  if (!user) {
    throw new Error('User not found');
  }

  await userRepository.softDeleteUser(id);
  console.log(`[USER] User Deleted (Soft Delete): ID ${id}`);
};

export const activateUser = async (id) => {
  const user = await userRepository.findUserById(id);
  if (!user) {
    throw new Error('User not found');
  }

  await userRepository.updateUserStatus(id, 'ACTIVE');
  console.log(`[USER] User Activated: ID ${id}`);
};

export const deactivateUser = async (id) => {
  const user = await userRepository.findUserById(id);
  if (!user) {
    throw new Error('User not found');
  }

  await userRepository.updateUserStatus(id, 'INACTIVE');
  console.log(`[USER] User Deactivated: ID ${id}`);
};

export const getUserById = async (id) => {
  const user = await userRepository.findUserById(id);
  if (!user) {
    throw new Error('User not found');
  }
  return user;
};

export const listUsers = async (filters) => {
  return await userRepository.getUsersList(filters);
};

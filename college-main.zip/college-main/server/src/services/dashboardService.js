import * as dashboardRepository from '../repositories/dashboardRepository.js';

let dashboardCache = null;
let cacheTime = 0;
const CACHE_TTL = 1000 * 60 * 5; // 5 minutes TTL

export const getDashboardSummary = async (bypassCache = false) => {
  const now = Date.now();
  if (!bypassCache && dashboardCache && (now - cacheTime < CACHE_TTL)) {
    console.log('[CACHE] Returning cached executive dashboard metrics.');
    return dashboardCache;
  }

  console.log('[DATABASE] Querying fresh executive dashboard metrics.');
  const [cards, charts, activities] = await Promise.all([
    dashboardRepository.getDashboardKPICards(),
    dashboardRepository.getDashboardChartsData(),
    dashboardRepository.getRecentActivities(),
  ]);

  dashboardCache = {
    cards,
    charts,
    activities,
  };
  cacheTime = now;

  return dashboardCache;
};

export const clearDashboardCache = () => {
  dashboardCache = null;
  cacheTime = 0;
  console.log('[CACHE] Dashboard cache cleared.');
};

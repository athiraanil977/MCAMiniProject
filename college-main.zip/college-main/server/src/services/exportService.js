import ExcelJS from 'exceljs';

// =========================================================================
// Native XLSX Spreadsheet Exporter (ExcelJS)
// =========================================================================

export const exportToExcel = async (reportName, headers, data) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(reportName);

  // Set column configurations
  worksheet.columns = headers.map((h) => ({
    header: h.label,
    key: h.key,
    width: 22,
  }));

  // Style Header Row
  const headerRow = worksheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF4F46E5' }, // Indigo-600 Theme Color
  };
  headerRow.alignment = { vertical: 'middle', horizontal: 'center' };

  // Add data rows
  data.forEach((rowObj) => {
    const rowData = {};
    headers.forEach((h) => {
      rowData[h.key] = rowObj[h.key] !== undefined && rowObj[h.key] !== null ? rowObj[h.key] : '';
    });
    worksheet.addRow(rowData);
  });

  // Write sheet buffer
  return await workbook.xlsx.writeBuffer();
};

// =========================================================================
// UTF-8 CSV Text Exporter
// =========================================================================

export const exportToCSV = (headers, data) => {
  const headerLine = headers.map((h) => `"${String(h.label).replace(/"/g, '""')}"`).join(',');
  const lines = data.map((rowObj) => {
    return headers.map((h) => {
      const val = rowObj[h.key] !== undefined && rowObj[h.key] !== null ? String(rowObj[h.key]) : '';
      return `"${val.replace(/"/g, '""')}"`;
    }).join(',');
  });

  // Return UTF-8 string bytes
  return [headerLine, ...lines].join('\n');
};
export const getDepreciationSummary = (assetsData) => {
  return assetsData.reduce((acc, cur) => {
    acc.originalCost += parseFloat(cur.purchaseCost || 0);
    acc.depreciation += parseFloat(cur.accumulatedDepreciation || 0);
    acc.bookValue += parseFloat(cur.currentBookValue || 0);
    return acc;
  }, { originalCost: 0, depreciation: 0, bookValue: 0 });
};

import * as maintenanceRepository from '../repositories/maintenanceRepository.js';
import * as notificationService from './notificationService.js';
import prisma from '../database/index.js';

// =========================================================================
// Request Workflow Business Rules
// =========================================================================

export const createRequest = async (data, userId) => {
  const asset = await prisma.asset.findUnique({
    where: { id: data.assetId },
    include: { status: true },
  });

  if (!asset) throw new Error('Asset not found');

  // Prevent requests on Disposed or Lost assets
  const blockedStatuses = ['Disposed', 'Lost'];
  if (blockedStatuses.includes(asset.status?.statusName)) {
    throw new Error(`Cannot log maintenance request for a decommissioned/disposed or lost asset.`);
  }

  // Prevent duplicate open requests
  const existingRequest = await maintenanceRepository.findOpenRequestByAssetId(data.assetId);
  if (existingRequest) {
    throw new Error('An active maintenance ticket is already open for this asset.');
  }

  return await maintenanceRepository.createRequest(data, userId);
};

export const updateRequest = async (id, data, userId) => {
  const req = await maintenanceRepository.getRequestById(id);
  if (!req) throw new Error('Request not found');

  const updated = await maintenanceRepository.updateRequest(id, data);
  console.log(`[MAINTENANCE] Request updated: ID ${id} by ${userId}`);

  // Send assignment notifications if tech changed
  if (data.assignedTechnician && data.assignedTechnician !== req.assignedTechnician) {
    notificationService.sendTechnicianAssignmentNotification(data.assignedTechnician, {
      requestNumber: updated.requestNumber,
      title: updated.problemTitle,
    });
  }

  return updated;
};

// =========================================================================
// Records & Repair Completions
// =========================================================================

export const startMaintenanceRecord = async (payload, userId) => {
  const asset = await prisma.asset.findUnique({
    where: { id: payload.assetId },
    include: { status: true },
  });

  if (!asset) throw new Error('Asset not found');
  if (asset.status?.statusName === 'Disposed') {
    throw new Error('Disposed assets cannot undergo maintenance.');
  }

  return await prisma.$transaction(async (tx) => {
    // 1. Fetch Maintenance status definition
    const maintStatus = await tx.assetStatus.findFirst({ where: { statusName: 'Maintenance' } });
    if (!maintStatus) throw new Error('Maintenance status mapping is missing.');

    // 2. Create the record
    const record = await tx.maintenanceRecord.create({
      data: {
        ...payload,
        maintenanceNumber: await maintenanceRepository.generateMaintenanceNumber(tx),
        status: 'In Progress',
        startDate: new Date(),
      },
    });

    // 3. Update asset status
    await tx.asset.update({
      where: { id: payload.assetId },
      data: { statusId: maintStatus.id },
    });

    // 4. Log history
    await tx.assetHistory.create({
      data: {
        assetId: payload.assetId,
        action: 'Maintenance',
        performedBy: userId,
        remarks: `Maintenance started. Record: ${record.maintenanceNumber}.`,
      },
    });

    // 5. Update request status to In Progress
    if (payload.requestId) {
      await tx.maintenanceRequest.update({
        where: { id: payload.requestId },
        data: { status: 'In Progress' },
      });
    }

    return record;
  });
};

export const completeMaintenanceRecord = async (id, payload, userId) => {
  const record = await maintenanceRepository.getRecordById(id);
  if (!record) throw new Error('Maintenance record not found');

  return await prisma.$transaction(async (tx) => {
    // Calculate Parts Cost
    let partsTotal = 0;
    if (payload.parts && payload.parts.length > 0) {
      // Clear old parts if editing
      await tx.maintenancePart.deleteMany({ where: { maintenanceId: id } });
      
      for (const p of payload.parts) {
        const qty = parseInt(p.quantity, 10);
        const cost = parseFloat(p.unitCost);
        const total = qty * cost;
        partsTotal += total;

        await tx.maintenancePart.create({
          data: {
            maintenanceId: id,
            partName: p.partName,
            quantity: qty,
            unitCost: cost,
            totalCost: total,
          },
        });
      }
    }

    // Cost calculations
    const labour = parseFloat(payload.labourCost || 0);
    const totalCost = labour + partsTotal;

    // Calculate Downtime (Hours)
    const start = new Date(record.startDate);
    const end = payload.endDate ? new Date(payload.endDate) : new Date();
    const downtimeHours = Math.max(0, (end.getTime() - start.getTime()) / (1000 * 60 * 60));

    // Update Record
    const updated = await tx.maintenanceRecord.update({
      where: { id },
      data: {
        endDate: end,
        labourCost: labour,
        partsCost: partsTotal,
        cost: totalCost,
        downtimeHours,
        status: 'Completed',
        resolution: payload.resolution || 'Resolved.',
        remarks: payload.remarks || '',
      },
    });

    // Update Request status
    if (record.requestId) {
      await tx.maintenanceRequest.update({
        where: { id: record.requestId },
        data: { status: 'Completed' },
      });
    }

    // Determine and restore previous asset status
    const asset = await tx.asset.findUnique({
      where: { id: record.assetId },
      include: { status: true },
    });

    const bypassRestore = ['Disposed', 'Lost', 'Reserved'];
    if (asset && !bypassRestore.includes(asset.status?.statusName)) {
      // Check active allocations
      const activeAlloc = await tx.assetAllocation.findFirst({
        where: { assetId: record.assetId, status: 'Allocated' },
      });

      const targetStatusName = activeAlloc ? 'Allocated' : 'Available';
      const targetStatus = await tx.assetStatus.findFirst({ where: { statusName: targetStatusName } });

      if (targetStatus) {
        await tx.asset.update({
          where: { id: record.assetId },
          data: { statusId: targetStatus.id },
        });
      }
    }

    // Log history
    await tx.assetHistory.create({
      data: {
        assetId: record.assetId,
        action: 'Status Changed',
        performedBy: userId,
        remarks: `Maintenance completed. Reverted status to normal. Record: ${record.maintenanceNumber}. Total Cost: $${totalCost}`,
      },
    });

    // Notify Completion
    if (record.requestId) {
      const recipientId = record.request?.requestedBy || userId;
      if (recipientId) {
        notificationService.sendMaintenanceCompletedNotification(
          record.requestId,
          { resolution: updated.resolution },
          recipientId
        );
      }
    }

    return updated;
  });
};

// =========================================================================
// Preventive Maintenance Scheduling Calculations
// =========================================================================

export const calculateNextDate = (startDate, frequency) => {
  const date = new Date(startDate);
  switch (frequency) {
    case 'Weekly':
      date.setDate(date.getDate() + 7);
      break;
    case 'Monthly':
      date.setMonth(date.getMonth() + 1);
      break;
    case 'Quarterly':
      date.setMonth(date.getMonth() + 3);
      break;
    case 'Half-Yearly':
      date.setMonth(date.getMonth() + 6);
      break;
    case 'Yearly':
      date.setFullYear(date.getFullYear() + 1);
      break;
    default:
      date.setDate(date.getDate() + 30); // Fallback monthly
  }
  return date;
};

export const createSchedule = async (data) => {
  const asset = await prisma.asset.findUnique({
    where: { id: data.assetId },
    include: { status: true },
  });

  if (!asset) throw new Error('Asset not found');
  if (asset.status?.statusName === 'Disposed') {
    throw new Error('Cannot schedule maintenance for disposed assets.');
  }

  const nextMaintenanceDate = calculateNextDate(new Date(), data.frequency);

  const schedule = await maintenanceRepository.createSchedule({
    ...data,
    nextMaintenanceDate,
  });

  console.log(`[MAINTENANCE] Schedule configured: "${schedule.scheduleName}" for Asset ID ${data.assetId}`);
  return schedule;
};

export const updateSchedule = async (id, data) => {
  const schedule = await maintenanceRepository.getScheduleById(id);
  if (!schedule) throw new Error('Schedule not found');

  const updatePayload = { ...data };
  if (data.frequency && data.frequency !== schedule.frequency) {
    updatePayload.nextMaintenanceDate = calculateNextDate(schedule.lastMaintenanceDate || new Date(), data.frequency);
  }

  return await maintenanceRepository.updateSchedule(id, updatePayload);
};

// =========================================================================
// Metrics / Dashboard Calculations
// =========================================================================

export const getDashboardMetrics = async () => {
  const [
    totalRequests,
    openRequests,
    inProgressRequests,
    completedRequests,
    totalRecords,
    totalCosts,
    totalDowntime,
  ] = await Promise.all([
    prisma.maintenanceRequest.count(),
    prisma.maintenanceRequest.count({ where: { status: 'Open' } }),
    prisma.maintenanceRequest.count({ where: { status: 'In Progress' } }),
    prisma.maintenanceRequest.count({ where: { status: 'Completed' } }),
    prisma.maintenanceRecord.count(),
    prisma.maintenanceRecord.aggregate({ _sum: { cost: true } }),
    prisma.maintenanceRecord.aggregate({ _sum: { downtimeHours: true } }),
  ]);

  return {
    totalRequests,
    openRequests,
    inProgressRequests,
    completedRequests,
    overdueRequests: 0, // Mock metric placeholder
    totalRecords,
    averageCost: totalRecords > 0 ? (parseFloat(totalCosts._sum.cost || 0) / totalRecords) : 0,
    totalDowntime: totalDowntime._sum.downtimeHours || 0,
    upcomingMaintenance: await prisma.maintenanceSchedule.count({ where: { isActive: true } }),
  };
};

import * as assetRepository from '../repositories/assetRepository.js';
import prisma from '../database/index.js';

// Helper to inspect if asset is Disposed
const checkDisposed = (asset) => {
  if (!asset) throw new Error('Asset not found');
  
  // We can look up the statusName directly if we included it, or query by status relation
  if (asset.status?.statusName === 'Disposed') {
    throw new Error('Action denied. This asset has already been decommissioned/disposed.');
  }
};

// Helper to check serial numbers
const checkDuplicateSerial = async (serialNumber, excludeId = null) => {
  const existing = await prisma.asset.findFirst({
    where: {
      serialNumber,
      deletedAt: null,
      NOT: excludeId ? { id: excludeId } : undefined,
    },
  });
  if (existing) {
    throw new Error(`Serial number "${serialNumber}" is already registered on another asset.`);
  }
};

// =========================================================================
// CRUD Operations
// =========================================================================

export const createAsset = async (data, userId) => {
  await checkDuplicateSerial(data.serialNumber);

  // Setup default available status if not specified
  if (!data.statusId) {
    const availableStatus = await prisma.assetStatus.findFirst({ where: { statusName: 'Available' } });
    if (availableStatus) {
      data.statusId = availableStatus.id;
    }
  }

  // Setup default condition if not specified
  if (!data.conditionId) {
    const goodCondition = await prisma.condition.findFirst({ where: { conditionName: 'Good' } });
    if (goodCondition) {
      data.conditionId = goodCondition.id;
    }
  }

  return await assetRepository.createAsset(data, userId);
};

export const updateAsset = async (id, data, userId) => {
  const asset = await assetRepository.getAssetById(id);
  if (!asset) throw new Error('Asset not found');
  checkDisposed(asset);

  if (data.serialNumber && data.serialNumber !== asset.serialNumber) {
    await checkDuplicateSerial(data.serialNumber, id);
  }

  return await assetRepository.updateAsset(id, data, userId);
};

export const deleteAsset = async (id, userId) => {
  const asset = await assetRepository.getAssetById(id);
  if (!asset) throw new Error('Asset not found');
  checkDisposed(asset);

  return await assetRepository.softDeleteAsset(id, userId);
};

export const restoreAsset = async (id, userId) => {
  const asset = await prisma.asset.findUnique({ where: { id } });
  if (!asset) throw new Error('Asset not found');

  return await assetRepository.restoreAsset(id, userId);
};

export const getAsset = async (id) => {
  const asset = await assetRepository.getAssetById(id);
  if (!asset) throw new Error('Asset not found');
  return asset;
};

export const listAssets = async (filters) => {
  return await assetRepository.getAssetsList(filters);
};

// =========================================================================
// Lifecycle Operations
// =========================================================================

export const allocateAsset = async (payload, userId) => {
  const asset = await assetRepository.getAssetById(payload.assetId);
  if (!asset) throw new Error('Asset not found');
  
  checkDisposed(asset);

  if (asset.status?.statusName === 'Allocated') {
    throw new Error('This asset is already allocated. Please return it first.');
  }

  return await assetRepository.allocateAsset({
    ...payload,
    userId,
  });
};

export const returnAsset = async (payload, userId) => {
  const asset = await assetRepository.getAssetById(payload.assetId);
  if (!asset) throw new Error('Asset not found');
  
  checkDisposed(asset);

  if (asset.status?.statusName !== 'Allocated') {
    throw new Error('Asset is not currently checked out/allocated.');
  }

  return await assetRepository.returnAsset({
    ...payload,
    userId,
  });
};

export const transferAsset = async (payload, userId) => {
  const asset = await assetRepository.getAssetById(payload.assetId);
  if (!asset) throw new Error('Asset not found');

  checkDisposed(asset);

  return await assetRepository.transferAsset({
    ...payload,
    userId,
  });
};

export const reserveAsset = async (payload, userId) => {
  const asset = await assetRepository.getAssetById(payload.assetId);
  if (!asset) throw new Error('Asset not found');

  checkDisposed(asset);

  if (asset.status?.statusName === 'Reserved') {
    throw new Error('This asset is already reserved.');
  }

  return await assetRepository.reserveAsset({
    ...payload,
    requestedBy: userId,
  });
};

export const approveOrRejectReservation = async (id, status, remarks, userId) => {
  return await assetRepository.approveOrRejectReservation(id, status, remarks, userId);
};

export const disposeAsset = async (payload, userId) => {
  const asset = await assetRepository.getAssetById(payload.assetId);
  if (!asset) throw new Error('Asset not found');

  checkDisposed(asset);

  return await assetRepository.disposeAsset({
    ...payload,
    approvedBy: userId,
  });
};

export const uploadAssetDocument = async (payload, userId) => {
  return await assetRepository.addAssetDocument({
    ...payload,
    userId,
  });
};

// =========================================================================
// Dashboard Metrics
// =========================================================================

export const getAssetDashboardMetrics = async () => {
  return await assetRepository.getDashboardAssetMetrics();
};

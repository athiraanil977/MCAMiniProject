import * as masterRepository from '../repositories/masterRepository.js';

// =========================================================================
// Category Business Services
// =========================================================================

export const createCategory = async (data, userId) => {
  const existingCode = await masterRepository.findCategoryByCode(data.categoryCode);
  if (existingCode) {
    throw new Error('Category Code is already registered');
  }

  const existingName = await masterRepository.findCategoryByName(data.categoryName);
  if (existingName) {
    throw new Error('Category Name is already registered');
  }

  const created = await masterRepository.createCategory({
    ...data,
    createdBy: userId,
  });

  console.log(`[MASTER] Category Created: ${created.categoryName} (Code: ${created.categoryCode}) by ${userId}`);
  return created;
};

export const updateCategory = async (id, data, userId) => {
  const category = await masterRepository.getCategoryById(id);
  if (!category) {
    throw new Error('Category not found');
  }

  if (data.categoryCode && data.categoryCode !== category.categoryCode) {
    const existingCode = await masterRepository.findCategoryByCode(data.categoryCode);
    if (existingCode) {
      throw new Error('Category Code is already registered');
    }
  }

  if (data.categoryName && data.categoryName !== category.categoryName) {
    const existingName = await masterRepository.findCategoryByName(data.categoryName);
    if (existingName) {
      throw new Error('Category Name is already registered');
    }
  }

  const updated = await masterRepository.updateCategory(id, {
    ...data,
    updatedBy: userId,
  });

  console.log(`[MASTER] Category Updated: ${updated.categoryName} (ID: ${id}) by ${userId}`);
  return updated;
};

export const deleteCategory = async (id, userId) => {
  const category = await masterRepository.getCategoryById(id);
  if (!category) {
    throw new Error('Category not found');
  }

  await masterRepository.softDeleteCategory(id);
  console.log(`[MASTER] Category Deleted (Soft Delete): ID ${id} by ${userId}`);
};

export const restoreCategory = async (id, userId) => {
  await masterRepository.restoreCategory(id);
  console.log(`[MASTER] Category Restored: ID ${id} by ${userId}`);
};

export const getCategory = async (id) => {
  return await masterRepository.getCategoryById(id);
};

export const listCategories = async (filters) => {
  return await masterRepository.getCategoriesList(filters);
};

// =========================================================================
// Location Business Services
// =========================================================================

export const createLocation = async (data, userId) => {
  const existingCode = await masterRepository.findLocationByCode(data.locationCode);
  if (existingCode) {
    throw new Error('Location Code is already registered');
  }

  const created = await masterRepository.createLocation({
    ...data,
    createdBy: userId,
  });

  console.log(`[MASTER] Location Created: ${created.locationName} (Code: ${created.locationCode}) by ${userId}`);
  return created;
};

export const updateLocation = async (id, data, userId) => {
  const loc = await masterRepository.getLocationById(id);
  if (!loc) {
    throw new Error('Location not found');
  }

  if (data.locationCode && data.locationCode !== loc.locationCode) {
    const existingCode = await masterRepository.findLocationByCode(data.locationCode);
    if (existingCode) {
      throw new Error('Location Code is already registered');
    }
  }

  const updated = await masterRepository.updateLocation(id, {
    ...data,
    updatedBy: userId,
  });

  console.log(`[MASTER] Location Updated: ${updated.locationName} (ID: ${id}) by ${userId}`);
  return updated;
};

export const deleteLocation = async (id, userId) => {
  const loc = await masterRepository.getLocationById(id);
  if (!loc) {
    throw new Error('Location not found');
  }

  await masterRepository.softDeleteLocation(id);
  console.log(`[MASTER] Location Deleted (Soft Delete): ID ${id} by ${userId}`);
};

export const restoreLocation = async (id, userId) => {
  await masterRepository.restoreLocation(id);
  console.log(`[MASTER] Location Restored: ID ${id} by ${userId}`);
};

export const getLocation = async (id) => {
  return await masterRepository.getLocationById(id);
};

export const listLocations = async (filters) => {
  return await masterRepository.getLocationsList(filters);
};

// =========================================================================
// Vendor Business Services
// =========================================================================

export const createVendor = async (data, userId) => {
  const existingCode = await masterRepository.findVendorByCode(data.vendorCode);
  if (existingCode) {
    throw new Error('Vendor Code is already registered');
  }

  const created = await masterRepository.createVendor({
    ...data,
    createdBy: userId,
  });

  console.log(`[MASTER] Vendor Created: ${created.vendorName} (Code: ${created.vendorCode}) by ${userId}`);
  return created;
};

export const updateVendor = async (id, data, userId) => {
  const vendor = await masterRepository.getVendorById(id);
  if (!vendor) {
    throw new Error('Vendor not found');
  }

  if (data.vendorCode && data.vendorCode !== vendor.vendorCode) {
    const existingCode = await masterRepository.findVendorByCode(data.vendorCode);
    if (existingCode) {
      throw new Error('Vendor Code is already registered');
    }
  }

  const updated = await masterRepository.updateVendor(id, {
    ...data,
    updatedBy: userId,
  });

  console.log(`[MASTER] Vendor Updated: ${updated.vendorName} (ID: ${id}) by ${userId}`);
  return updated;
};

export const deleteVendor = async (id, userId) => {
  const vendor = await masterRepository.getVendorById(id);
  if (!vendor) {
    throw new Error('Vendor not found');
  }

  await masterRepository.softDeleteVendor(id);
  console.log(`[MASTER] Vendor Deleted (Soft Delete): ID ${id} by ${userId}`);
};

export const restoreVendor = async (id, userId) => {
  await masterRepository.restoreVendor(id);
  console.log(`[MASTER] Vendor Restored: ID ${id} by ${userId}`);
};

export const getVendor = async (id) => {
  return await masterRepository.getVendorById(id);
};

export const listVendors = async (filters) => {
  return await masterRepository.getVendorsList(filters);
};

// =========================================================================
// Manufacturer Business Services
// =========================================================================

export const createManufacturer = async (data, userId) => {
  const existingCode = await masterRepository.findManufacturerByCode(data.manufacturerCode);
  if (existingCode) {
    throw new Error('Manufacturer Code is already registered');
  }

  const created = await masterRepository.createManufacturer(data);
  console.log(`[MASTER] Manufacturer Created: ${created.manufacturerName} (Code: ${created.manufacturerCode}) by ${userId}`);
  return created;
};

export const updateManufacturer = async (id, data, userId) => {
  const mfg = await masterRepository.getManufacturerById(id);
  if (!mfg) {
    throw new Error('Manufacturer not found');
  }

  if (data.manufacturerCode && data.manufacturerCode !== mfg.manufacturerCode) {
    const existingCode = await masterRepository.findManufacturerByCode(data.manufacturerCode);
    if (existingCode) {
      throw new Error('Manufacturer Code is already registered');
    }
  }

  const updated = await masterRepository.updateManufacturer(id, data);
  console.log(`[MASTER] Manufacturer Updated: ${updated.manufacturerName} (ID: ${id}) by ${userId}`);
  return updated;
};

export const deleteManufacturer = async (id, userId) => {
  const mfg = await masterRepository.getManufacturerById(id);
  if (!mfg) {
    throw new Error('Manufacturer not found');
  }

  await masterRepository.softDeleteManufacturer(id);
  console.log(`[MASTER] Manufacturer Deleted (Soft Delete): ID ${id} by ${userId}`);
};

export const restoreManufacturer = async (id, userId) => {
  await masterRepository.restoreManufacturer(id);
  console.log(`[MASTER] Manufacturer Restored: ID ${id} by ${userId}`);
};

export const getManufacturer = async (id) => {
  return await masterRepository.getManufacturerById(id);
};

export const listManufacturers = async (filters) => {
  return await masterRepository.getManufacturersList(filters);
};

// =========================================================================
// Metrics / Dashboard
// =========================================================================

export const getDashboardMasterMetrics = async () => {
  return await masterRepository.getMasterMetrics();
};

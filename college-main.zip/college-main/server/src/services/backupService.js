import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs';
import * as archiverModule from 'archiver';
const archiver = archiverModule.default ?? archiverModule;
import * as backupRepository from '../repositories/backupRepository.js';
import * as auditService from './auditService.js';
import logger from '../utils/logger.js';

const execAsync = promisify(exec);

const BACKUP_DIR = process.env.BACKUP_PATH || 'backups';
const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_PORT = process.env.DB_PORT || '3306';
const DB_NAME = process.env.DB_NAME || 'college';
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || '';

// Ensure backup directory exists
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

// =========================================================================
// Create Backup
// =========================================================================
export const createBackup = async (userId, req) => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const sqlFileName = `backup-${DB_NAME}-${timestamp}.sql`;
  const zipFileName = `backup-${DB_NAME}-${timestamp}.zip`;
  const sqlFilePath = path.resolve(BACKUP_DIR, sqlFileName);
  const zipFilePath = path.resolve(BACKUP_DIR, zipFileName);

  // Create initial DB record as "Running"
  const record = await backupRepository.createBackupRecord({
    backupName: `Database Backup – ${new Date().toLocaleString()}`,
    backupType: 'Manual',
    fileName: zipFileName,
    filePath: zipFilePath,
    createdBy: userId || null,
    status: 'Running',
  });

  try {
    // 1. Run mysqldump
    const dumpCmd = `mysqldump -h ${DB_HOST} -P ${DB_PORT} -u ${DB_USER} --password="${DB_PASSWORD}" ${DB_NAME} > "${sqlFilePath}"`;
    await execAsync(dumpCmd);
    logger.info(`[BACKUP] SQL dump created: ${sqlFileName}`);

    // 2. Compress SQL into ZIP
    await new Promise((resolve, reject) => {
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      output.on('close', resolve);
      archive.on('error', reject);
      archive.pipe(output);
      archive.file(sqlFilePath, { name: sqlFileName });
      archive.finalize();
    });

    // 3. Clean up raw SQL file
    fs.unlinkSync(sqlFilePath);

    const stats = fs.statSync(zipFilePath);
    const updated = await backupRepository.updateBackupRecord(record.id, {
      status: 'Success',
      backupSize: BigInt(stats.size),
    });

    logger.info(`[BACKUP] Backup completed: ${zipFileName} (${stats.size} bytes)`);

    // 4. Audit log
    await auditService.logActivity({
      userId,
      module: 'Backup',
      action: 'Create',
      entity: 'BackupHistory',
      entityId: String(record.id),
      newData: { fileName: zipFileName, size: stats.size },
    }, req);

    return { ...updated, backupSize: stats.size };
  } catch (error) {
    logger.error('[BACKUP] Backup failed', { error: error.message });
    await backupRepository.updateBackupRecord(record.id, { status: 'Failed' });

    // Clean up partial files
    if (fs.existsSync(sqlFilePath)) fs.unlinkSync(sqlFilePath);
    if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath);

    throw new Error(`Backup failed: ${error.message}. Ensure mysqldump is installed and DB credentials are correct.`);
  }
};

// =========================================================================
// Delete Backup
// =========================================================================
export const deleteBackup = async (id, userId, req) => {
  const record = await backupRepository.getBackupById(id);
  if (!record) throw new Error('Backup record not found.');

  // Delete physical file if it exists
  if (fs.existsSync(record.filePath)) {
    fs.unlinkSync(record.filePath);
    logger.info(`[BACKUP] Deleted backup file: ${record.fileName}`);
  }

  await backupRepository.deleteBackupRecord(id);

  await auditService.logActivity({
    userId,
    module: 'Backup',
    action: 'Delete',
    entity: 'BackupHistory',
    entityId: String(id),
    oldData: { fileName: record.fileName },
  }, req);
};

// =========================================================================
// Download Backup (returns file path for streaming)
// =========================================================================
export const getBackupFilePath = async (id) => {
  const record = await backupRepository.getBackupById(id);
  if (!record) throw new Error('Backup record not found.');
  if (!fs.existsSync(record.filePath)) throw new Error('Backup file no longer exists on disk.');
  return { filePath: record.filePath, fileName: record.fileName };
};

// =========================================================================
// List Backups
// =========================================================================
export const listBackups = async (params) => {
  return await backupRepository.getBackupsList(params);
};

import * as notificationRepository from '../repositories/notificationRepository.js';

// =========================================================================
// Real Notification Database Storage Integrations
// =========================================================================

export const sendPreventiveMaintenanceReminder = async (scheduleId, details, userId) => {
  if (!userId) return null;
  console.log(`[NOTIFICATION] PM reminder for Schedule ID ${scheduleId}`);
  return await notificationRepository.createNotification({
    title: 'Upcoming Preventive Maintenance',
    message: `Preventive schedule task "${details.scheduleName}" is scheduled for next service: ${details.nextDate}`,
    type: 'Warning',
    priority: 'Medium',
    userId,
    actionUrl: `/maintenance`,
  });
};

export const sendTechnicianAssignmentNotification = async (technicianId, requestDetails, userId) => {
  if (!userId) return null;
  console.log(`[NOTIFICATION] Assignment ticket for Technician ${technicianId}`);
  return await notificationRepository.createNotification({
    title: 'Maintenance Task Assigned',
    message: `You have been assigned to Repair Ticket ${requestDetails.requestNumber} ("${requestDetails.title}").`,
    type: 'Info',
    priority: 'High',
    userId,
    actionUrl: `/maintenance`,
  });
};

export const sendMaintenanceCompletedNotification = async (requestId, details, userId) => {
  if (!userId) return null;
  console.log(`[NOTIFICATION] Completion ticket for Request ${requestId}`);
  return await notificationRepository.createNotification({
    title: 'Maintenance Repair Completed',
    message: `Repair Ticket ${requestId} has been marked Completed: "${details.resolution}"`,
    type: 'Success',
    priority: 'Low',
    userId,
    actionUrl: `/maintenance`,
  });
};

export const sendWarrantyExpiringReminder = async (assetId, details, userId) => {
  if (!userId) return null;
  console.log(`[NOTIFICATION] Warranty expiring reminder for Asset ${assetId}`);
  return await notificationRepository.createNotification({
    title: 'Asset Warranty Expiring',
    message: `Warranty for Asset ${details.assetTag} ("${details.assetName}") expires on ${details.warrantyEnd}`,
    type: 'Warning',
    priority: 'High',
    userId,
    actionUrl: `/assets/${assetId}`,
  });
};

export const triggerCustomNotification = async ({ userId, title, message, type, priority, actionUrl }) => {
  if (!userId) return null;
  return await notificationRepository.createNotification({
    userId,
    title,
    message,
    type: type || 'Info',
    priority: priority || 'Low',
    actionUrl,
  });
};

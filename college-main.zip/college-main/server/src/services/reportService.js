import * as reportRepository from '../repositories/reportRepository.js';
import * as savedReportRepository from '../repositories/savedReportRepository.js';

export const getAssetsReport = async (filters) => {
  return await reportRepository.queryAssetsReport(filters);
};

export const getMaintenanceReport = async (filters) => {
  return await reportRepository.queryMaintenanceReport(filters);
};

export const getFinancialReport = async (filters) => {
  const assets = await reportRepository.queryFinancialReport(filters);
  const now = new Date();
  
  // Apply Depreciation: Straight line at 10% per annum
  const DEP_ANNUAL_RATE = 0.10; // 10%

  return assets.map((asset) => {
    const cost = parseFloat(asset.purchaseCost || 0);
    const buyDate = asset.purchaseDate ? new Date(asset.purchaseDate) : new Date(asset.createdAt);
    
    // Age in Years
    const ageYears = Math.max(0, (now.getTime() - buyDate.getTime()) / (1000 * 60 * 60 * 24 * 365.25));
    
    const accumulatedDepreciation = cost * DEP_ANNUAL_RATE * ageYears;
    const bookValue = Math.max(0, cost - accumulatedDepreciation);

    return {
      id: asset.id,
      assetTag: asset.assetTag,
      assetName: asset.assetName,
      categoryName: asset.category?.categoryName || 'Unknown',
      departmentName: asset.department?.departmentName || 'Not Assigned',
      purchaseDate: asset.purchaseDate,
      purchaseCost: cost,
      ageYears: parseFloat(ageYears.toFixed(2)),
      accumulatedDepreciation: parseFloat(accumulatedDepreciation.toFixed(2)),
      currentBookValue: parseFloat(bookValue.toFixed(2)),
    };
  });
};

// =========================================================================
// Saved Reports Configurations
// =========================================================================

export const saveUserReport = async (data, userId) => {
  return await savedReportRepository.createSavedReport({
    ...data,
    userId,
  });
};

export const listSavedReports = async (userId) => {
  const reports = await savedReportRepository.getSavedReports(userId);
  return reports.map((r) => ({
    id: r.id,
    reportName: r.reportName,
    reportType: r.reportType,
    filters: JSON.parse(r.filterJson),
    createdAt: r.createdAt,
  }));
};

export const deleteSavedReport = async (id, userId) => {
  return await savedReportRepository.deleteSavedReport(id, userId);
};

import * as auditRepository from '../repositories/auditRepository.js';

// Simple User Agent helper regex
const parseUserAgent = (userAgentString = '') => {
  let browser = 'Unknown Browser';
  let operatingSystem = 'Unknown OS';
  let device = 'Desktop';

  const ua = userAgentString.toLowerCase();

  // Browser detection
  if (ua.includes('chrome')) browser = 'Google Chrome';
  else if (ua.includes('firefox')) browser = 'Mozilla Firefox';
  else if (ua.includes('safari') && !ua.includes('chrome')) browser = 'Apple Safari';
  else if (ua.includes('edge')) browser = 'Microsoft Edge';

  // OS detection
  if (ua.includes('windows')) operatingSystem = 'Windows';
  else if (ua.includes('macintosh') || ua.includes('mac os')) operatingSystem = 'macOS';
  else if (ua.includes('linux')) operatingSystem = 'Linux';
  else if (ua.includes('android')) {
    operatingSystem = 'Android';
    device = 'Mobile';
  } else if (ua.includes('iphone') || ua.includes('ipad')) {
    operatingSystem = 'iOS';
    device = 'Mobile';
  }

  return { browser, operatingSystem, device };
};

export const logActivity = async (payload, req) => {
  try {
    const ipAddress = req?.ip || req?.headers['x-forwarded-for'] || '127.0.0.1';
    const userAgent = req?.headers['user-agent'] || '';

    const { browser, operatingSystem, device } = parseUserAgent(userAgent);

    const oldStr = payload.oldData ? (typeof payload.oldData === 'string' ? payload.oldData : JSON.stringify(payload.oldData)) : null;
    const newStr = payload.newData ? (typeof payload.newData === 'string' ? payload.newData : JSON.stringify(payload.newData)) : null;

    const log = await auditRepository.createAuditLog({
      userId: payload.userId || null,
      module: payload.module,
      action: payload.action,
      entity: payload.entity,
      entityId: payload.entityId ? String(payload.entityId) : null,
      oldData: oldStr,
      newData: newStr,
      ipAddress,
      browser,
      operatingSystem,
      device,
    });

    console.log(`[AUDIT_LOG] [${payload.module}] Action: ${payload.action} | User: ${payload.userId || 'GUEST'}`);
    return log;
  } catch (error) {
    console.error('[AUDIT_LOG_ERROR] Failed to write audit trail:', error);
    return null;
  }
};

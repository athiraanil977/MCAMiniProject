import os from 'os';
import fs from 'fs';
import path from 'path';
import si from 'systeminformation';
import prisma from '../database/index.js';
import logger from '../utils/logger.js';

// =========================================================================
// Database Health
// =========================================================================
export const checkDatabase = async () => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return { status: 'healthy', message: 'Database connection OK' };
  } catch (error) {
    logger.error('[HEALTH] Database check failed', { error: error.message });
    return { status: 'unhealthy', message: error.message };
  }
};

// =========================================================================
// Storage Health
// =========================================================================
export const checkStorage = async () => {
  try {
    const uploadPath = path.resolve(process.env.UPLOAD_PATH || 'uploads');
    const backupPath = path.resolve(process.env.BACKUP_PATH || 'backups');

    // Get disk usage via systeminformation
    const diskData = await si.fsSize();
    const primaryDisk = diskData[0] || {};

    // Count files in uploads
    let uploadCount = 0;
    if (fs.existsSync(uploadPath)) {
      uploadCount = fs.readdirSync(uploadPath, { recursive: true }).length;
    }

    return {
      status: 'healthy',
      diskTotal: primaryDisk.size || 0,
      diskUsed: primaryDisk.used || 0,
      diskFree: primaryDisk.available || 0,
      diskUsagePercent: primaryDisk.use ? `${primaryDisk.use.toFixed(1)}%` : 'N/A',
      uploadPath,
      backupPath,
      uploadFileCount: uploadCount,
    };
  } catch (error) {
    logger.error('[HEALTH] Storage check failed', { error: error.message });
    return { status: 'degraded', message: error.message };
  }
};

// =========================================================================
// System Health
// =========================================================================
export const checkSystem = async () => {
  const memTotal = os.totalmem();
  const memFree = os.freemem();
  const memUsed = memTotal - memFree;

  return {
    status: 'healthy',
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
    uptimeSeconds: Math.floor(process.uptime()),
    uptimeHuman: formatUptime(process.uptime()),
    memoryTotal: memTotal,
    memoryUsed: memUsed,
    memoryFree: memFree,
    memoryUsagePercent: `${((memUsed / memTotal) * 100).toFixed(1)}%`,
    cpuCores: os.cpus().length,
    loadAverage: os.loadavg(),
  };
};

// =========================================================================
// Summary Health
// =========================================================================
export const getSummary = async () => {
  const [db, storage, system] = await Promise.all([
    checkDatabase(),
    checkStorage(),
    checkSystem(),
  ]);

  const allHealthy = db.status === 'healthy' && storage.status === 'healthy';

  return {
    status: allHealthy ? 'healthy' : 'degraded',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0',
    database: db,
    storage,
    system,
  };
};

// Helper
const formatUptime = (seconds) => {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
};

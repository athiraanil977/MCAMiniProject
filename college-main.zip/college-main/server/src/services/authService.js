import crypto from 'crypto';
import * as userRepository from '../repositories/userRepository.js';
import * as authRepository from '../repositories/authRepository.js';
import { comparePassword, hashPassword } from '../utils/passwordUtility.js';
import { signToken } from '../utils/jwtUtility.js';

// Configurable session limits
const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY_DAYS = 7;

export const login = async (email, password) => {
  const user = await userRepository.findUserByEmail(email);
  if (!user) {
    console.warn(`[AUTH] Login Failure: Account not found for ${email}`);
    throw new Error('Invalid email or password');
  }

  const isPasswordValid = await comparePassword(password, user.password);
  if (!isPasswordValid) {
    console.warn(`[AUTH] Login Failure: Incorrect password for ${email}`);
    throw new Error('Invalid email or password');
  }

  if (user.status !== 'ACTIVE') {
    console.warn(`[AUTH] Login Failure: Attempted login to inactive account ${email}`);
    throw new Error('Your account is deactivated. Contact system administrator.');
  }

  // Format permissions to simple string array
  const permissions = user.role.permissions.map(
    (rp) => rp.permission.permissionName
  );

  // Sign tokens
  const accessToken = signToken({
    id: user.id,
    email: user.email,
    role: user.role.roleName,
    permissions
  });

  const rawRefreshToken = crypto.randomBytes(40).toString('hex');
  const refreshExpires = new Date();
  refreshExpires.setDate(refreshExpires.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

  await authRepository.createRefreshToken(user.id, rawRefreshToken, refreshExpires);
  await userRepository.updateLastLogin(user.id);

  console.log(`[AUTH] Login Success: User ${email} authenticated successfully`);

  return {
    accessToken,
    refreshToken: rawRefreshToken,
    user: {
      id: user.id,
      employeeId: user.employeeId,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role.roleName,
      department: user.department?.departmentName || null,
      permissions
    }
  };
};

export const logout = async (refreshToken) => {
  const tokenRecord = await authRepository.findRefreshToken(refreshToken);
  if (tokenRecord) {
    await authRepository.deleteRefreshToken(refreshToken);
    console.log(`[AUTH] Logout: Invalidated refresh token for User ID ${tokenRecord.userId}`);
  }
};

export const refreshSession = async (token) => {
  const tokenRecord = await authRepository.findRefreshToken(token);
  if (!tokenRecord || tokenRecord.expiresAt < new Date()) {
    if (tokenRecord) {
      await authRepository.deleteRefreshToken(token);
    }
    console.warn(`[AUTH] Refresh Failure: Stale or invalid refresh token`);
    throw new Error('Invalid or expired refresh token');
  }

  const user = await userRepository.findUserById(tokenRecord.userId);
  if (!user || user.status !== 'ACTIVE') {
    throw new Error('User not authorized or inactive');
  }

  const permissions = user.role.permissions.map(
    (rp) => rp.permission.permissionName
  );

  // Generate new Access and Refresh tokens (Rotation)
  const accessToken = signToken({
    id: user.id,
    email: user.email,
    role: user.role.roleName,
    permissions
  });

  const newRefreshToken = crypto.randomBytes(40).toString('hex');
  const refreshExpires = new Date();
  refreshExpires.setDate(refreshExpires.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

  // Delete old and store new rotated token
  await authRepository.deleteRefreshToken(token);
  await authRepository.createRefreshToken(user.id, newRefreshToken, refreshExpires);

  return {
    accessToken,
    refreshToken: newRefreshToken,
  };
};

export const changePassword = async (userId, currentPassword, newPassword) => {
  const user = await userRepository.findUserById(userId);
  if (!user) {
    throw new Error('User not found');
  }

  const isPasswordValid = await comparePassword(currentPassword, user.password);
  if (!isPasswordValid) {
    throw new Error('Incorrect current password');
  }

  const hashed = await hashPassword(newPassword);
  await userRepository.updatePassword(userId, hashed);

  console.log(`[AUTH] Password Changed: Updated password for User ID ${userId}`);
};

export const requestPasswordReset = async (email) => {
  const user = await userRepository.findUserByEmail(email);
  if (!user) {
    console.warn(`[AUTH] Reset Failure: Requested reset for missing email ${email}`);
    throw new Error('User with this email does not exist');
  }

  const resetToken = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date();
  expiresAt.setMinutes(expiresAt.getMinutes() + 15); // 15 minutes validity

  await authRepository.createPasswordResetToken(user.id, resetToken, expiresAt);

  console.log(`[AUTH] Password Reset Token Generated: User ID ${user.id}`);
  
  // Return the token since email service is not implemented yet as per prompt constraints
  return resetToken;
};

export const completePasswordReset = async (token, newPassword) => {
  const tokenRecord = await authRepository.findPasswordResetToken(token);
  if (!tokenRecord || tokenRecord.used || tokenRecord.expiresAt < new Date()) {
    console.warn(`[AUTH] Reset Failure: Invalid, used, or expired reset token`);
    throw new Error('Invalid or expired reset token');
  }

  const hashed = await hashPassword(newPassword);
  
  // Transaction: Update password and invalidate token
  await userRepository.updatePassword(tokenRecord.userId, hashed);
  await authRepository.markPasswordResetTokenUsed(token);

  console.log(`[AUTH] Password Reset Success: Completed reset for User ID ${tokenRecord.userId}`);
};

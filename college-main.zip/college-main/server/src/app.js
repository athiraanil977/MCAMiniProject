import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import path from 'path';
import fs from 'fs';

import apiRouter from './routes/index.js';
import { loggerMiddleware } from './middlewares/loggerMiddleware.js';
import { notFoundHandler } from './middlewares/notFoundHandler.js';
import { errorHandler } from './middlewares/errorHandler.js';
import { generalLimiter } from './middlewares/rateLimitMiddleware.js';
import logger from './utils/logger.js';

const app = express();

// =========================================================================
// 1. Trust proxy (for accurate IP behind reverse proxy/load balancer)
// =========================================================================
app.set('trust proxy', 1);

// =========================================================================
// 2. Security Headers (Hardened Helmet)
// =========================================================================
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameSrc: ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  crossOriginEmbedderPolicy: false,
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true,
  },
}));

// =========================================================================
// 3. CORS – whitelist from environment
// =========================================================================
const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:5173')
  .split(',')
  .map((o) => o.trim());

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow server-to-server (no origin) or whitelisted origins
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        logger.warn(`CORS blocked origin: ${origin}`);
        callback(new Error(`CORS policy: origin ${origin} not allowed`));
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  })
);

// =========================================================================
// 4. General Rate Limiter (all /api routes)
// =========================================================================
app.use('/api', generalLimiter);

// =========================================================================
// 5. HTTP Logging
// =========================================================================
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}
app.use(loggerMiddleware);

// =========================================================================
// 6. Body Parsing with size limits
// =========================================================================
app.use(compression());
app.use(cookieParser());
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// =========================================================================
// 7. Ensure upload sub-directories exist
// =========================================================================
const uploadRoot = process.env.UPLOAD_PATH || 'uploads';
const uploadSubDirs = ['assets', 'profiles', 'maintenance', 'invoices', 'documents', 'logos', 'exports', 'backups'];
[uploadRoot, ...uploadSubDirs.map((d) => path.join(uploadRoot, d))].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// =========================================================================
// 8. Static file serving for uploads (with cache headers)
// =========================================================================
app.use(
  '/uploads',
  express.static(path.resolve(uploadRoot), {
    maxAge: process.env.NODE_ENV === 'production' ? '7d' : 0,
    etag: true,
  })
);

// =========================================================================
// 9. API Routes Gateway
// =========================================================================
app.use('/api', apiRouter);

// =========================================================================
// 10. Error Handlers
// =========================================================================
app.use(notFoundHandler);
app.use(errorHandler);

export default app;

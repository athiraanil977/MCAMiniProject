import { PrismaClient } from '@prisma/client';

let prisma;

if (process.env.NODE_ENV === 'production') {
  prisma = new PrismaClient({
    transactionOptions: {
      maxWait:   10000, // max time to acquire a connection (ms)
      timeout:   15000, // max time for the transaction to complete (ms)
    },
  });
} else {
  // Prevent multiple instances of Prisma Client in development due to hot reloading
  if (!global.prisma) {
    global.prisma = new PrismaClient({
      log: ['warn', 'error'],
      transactionOptions: {
        maxWait:   10000,
        timeout:   15000,
      },
    });
  }
  prisma = global.prisma;
}

export default prisma;

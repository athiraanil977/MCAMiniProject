import { z } from 'zod';

export const saveReportSchema = {
  body: z.object({
    reportName: z.string().min(3, 'Report name is required'),
    reportType: z.enum(['assets', 'maintenance', 'financial']),
    filters: z.object({}).passthrough().optional(),
  }),
};

export const exportReportSchema = {
  body: z.object({
    format: z.enum(['csv', 'excel']),
    reportType: z.enum(['assets', 'maintenance', 'financial']),
    filters: z.object({}).passthrough().optional(),
  }),
};

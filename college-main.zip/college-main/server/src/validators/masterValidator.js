import { z } from 'zod';

// =========================================================================
// Category Schema
// =========================================================================

export const categorySchema = {
  body: z.object({
    categoryCode: z.string()
      .min(2, 'Category Code must be at least 2 characters')
      .max(10, 'Category Code must not exceed 10 characters')
      .toUpperCase(),
    categoryName: z.string()
      .min(3, 'Category Name must be at least 3 characters')
      .max(100, 'Category Name must not exceed 100 characters'),
    description: z.string().optional().nullable(),
    icon: z.string().optional().nullable(),
    isActive: z.boolean().optional(),
  }),
};

// =========================================================================
// Location Schema
// =========================================================================

export const locationSchema = {
  body: z.object({
    locationCode: z.string()
      .min(3, 'Location Code must be at least 3 characters')
      .toUpperCase(),
    locationName: z.string().min(3, 'Location Name must be at least 3 characters'),
    building: z.string().min(1, 'Building is required'),
    floor: z.string().optional().nullable(),
    roomNumber: z.string().optional().nullable(),
    description: z.string().optional().nullable(),
    isActive: z.boolean().optional(),
  }),
};

// =========================================================================
// Vendor Schema
// =========================================================================

export const vendorSchema = {
  body: z.object({
    vendorCode: z.string()
      .min(3, 'Vendor Code must be at least 3 characters')
      .toUpperCase(),
    vendorName: z.string().min(3, 'Vendor Name must be at least 3 characters'),
    contactPerson: z.string().optional().nullable(),
    email: z.string().email('Invalid email format').optional().nullable().or(z.literal('')),
    phone: z.string().regex(/^\+?[0-9\s-]{7,15}$/, 'Invalid phone number format').optional().nullable().or(z.literal('')),
    gstNumber: z.string().regex(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/, 'Invalid GST format (Example: 22AAAAA0000A1Z1)').optional().nullable().or(z.literal('')),
    address: z.string().optional().nullable(),
    city: z.string().optional().nullable(),
    state: z.string().optional().nullable(),
    country: z.string().optional().nullable(),
    postalCode: z.string().regex(/^[a-zA-Z0-9\s-]{3,10}$/, 'Invalid postal code').optional().nullable().or(z.literal('')),
    website: z.string().optional().nullable().or(z.literal('')),
    description: z.string().optional().nullable(),
    isActive: z.boolean().optional(),
  }),
};

// =========================================================================
// Manufacturer Schema
// =========================================================================

export const manufacturerSchema = {
  body: z.object({
    manufacturerCode: z.string()
      .min(3, 'Manufacturer Code must be at least 3 characters')
      .toUpperCase(),
    manufacturerName: z.string().min(3, 'Manufacturer Name must be at least 3 characters'),
    website: z.string().optional().nullable().or(z.literal('')),
    supportEmail: z.string().email('Invalid email format').optional().nullable().or(z.literal('')),
    supportPhone: z.string().regex(/^\+?[0-9\s-]{7,15}$/, 'Invalid phone number format').optional().nullable().or(z.literal('')),
    description: z.string().optional().nullable(),
    isActive: z.boolean().optional(),
  }),
};

import { z } from 'zod';

// Helper to coerce date strings or dates
const dateCoercion = z.preprocess((val) => {
  if (typeof val === 'string' && val !== '') {
    return new Date(val);
  }
  return val;
}, z.date().optional().nullable());

// =========================================================================
// Asset Creation / Update Schema
// =========================================================================

export const assetSchema = {
  body: z.object({
    assetName: z.string().min(3, 'Asset Name must be at least 3 characters'),
    description: z.string().optional().nullable(),
    serialNumber: z.string().min(3, 'Serial Number must be at least 3 characters'),
    categoryId: z.number().int('Category ID must be an integer'),
    manufacturerId: z.number().int('Manufacturer ID must be an integer'),
    vendorId: z.number().int('Vendor ID must be an integer'),
    departmentId: z.number().int('Department ID must be an integer').optional().nullable(),
    locationId: z.number().int('Location ID must be an integer'),
    purchaseDate: dateCoercion,
    purchaseCost: z.number().nonnegative('Cost cannot be negative').optional().nullable(),
    invoiceNumber: z.string().optional().nullable(),
    invoiceFile: z.string().optional().nullable(),
    warrantyStart: dateCoercion,
    warrantyEnd: dateCoercion,
    model: z.string().optional().nullable(),
    brand: z.string().optional().nullable(),
    conditionId: z.number().int('Condition ID must be an integer'),
    statusId: z.number().int('Status ID must be an integer').optional().nullable(),
    assignedUserId: z.string().uuid('Invalid user UUID').optional().nullable(),
    purchaseOrder: z.string().optional().nullable(),
    remarks: z.string().optional().nullable(),
    assetImage: z.string().optional().nullable(),
  }),
};

// =========================================================================
// Allocation Schema
// =========================================================================

export const allocationSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required'),
    allocatedToUserId: z.string().uuid('Invalid user UUID').optional().nullable(),
    allocatedDepartmentId: z.number().int('Department ID must be an integer').optional().nullable(),
    expectedReturnDate: dateCoercion,
    purpose: z.string().optional().nullable(),
    remarks: z.string().optional().nullable(),
  }).refine(data => data.allocatedToUserId || data.allocatedDepartmentId, {
    message: 'Must allocate to either a user or a department',
    path: ['allocatedToUserId'],
  }),
};

// =========================================================================
// Return Schema
// =========================================================================

export const returnSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required'),
    remarks: z.string().optional().nullable(),
  }),
};

// =========================================================================
// Transfer Schema
// =========================================================================

export const transferSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required'),
    toDepartmentId: z.number().int('Target Department ID must be an integer').optional().nullable(),
    toLocationId: z.number().int('Target Location ID must be an integer'),
    reason: z.string().optional().nullable(),
    remarks: z.string().optional().nullable(),
  }),
};

// =========================================================================
// Reservation Schema
// =========================================================================

export const reservationSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required'),
    reservationStart: z.preprocess((val) => new Date(val), z.date()),
    reservationEnd: z.preprocess((val) => new Date(val), z.date()),
    purpose: z.string().optional().nullable(),
    remarks: z.string().optional().nullable(),
  }).refine((data) => data.reservationEnd > data.reservationStart, {
    message: 'Reservation end date must be after start date',
    path: ['reservationEnd'],
  }),
};

// =========================================================================
// Disposal Schema
// =========================================================================

export const disposalSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required'),
    reason: z.string().min(5, 'Disposal reason must details decommissioning'),
    method: z.string().min(3, 'Disposal method is required'),
    remarks: z.string().optional().nullable(),
    documentPath: z.string().optional().nullable(),
  }),
};

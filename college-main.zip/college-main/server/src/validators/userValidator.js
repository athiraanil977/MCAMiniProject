import { z } from 'zod';

const passwordSchema = z.string()
  .min(8, 'Password must be at least 8 characters long')
  .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
  .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .regex(/[0-9]/, 'Password must contain at least one number')
  .regex(/[^a-zA-Z0-9]/, 'Password must contain at least one special character');

export const createUserSchema = {
  body: z.object({
    employeeId: z.string().optional().nullable(),
    name: z.string().min(2, 'Name must be at least 2 characters'),
    email: z.string().email('Invalid email address'),
    phone: z.string().regex(/^\+?[0-9\s-]{7,15}$/, 'Invalid phone number format').optional().nullable(),
    password: passwordSchema,
    roleId: z.number().int().positive('Role ID must be a positive integer'),
    departmentId: z.number().int().positive('Department ID must be a positive integer').optional().nullable(),
    status: z.enum(['ACTIVE', 'INACTIVE', 'PENDING']).optional(),
  }),
};

export const updateUserSchema = {
  body: z.object({
    employeeId: z.string().optional().nullable(),
    name: z.string().min(2, 'Name must be at least 2 characters').optional(),
    email: z.string().email('Invalid email address').optional(),
    phone: z.string().regex(/^\+?[0-9\s-]{7,15}$/, 'Invalid phone number format').optional().nullable(),
    password: passwordSchema.optional(),
    roleId: z.number().int().positive('Role ID must be a positive integer').optional(),
    departmentId: z.number().int().positive('Department ID must be a positive integer').optional().nullable(),
    status: z.enum(['ACTIVE', 'INACTIVE', 'PENDING']).optional(),
  }),
};

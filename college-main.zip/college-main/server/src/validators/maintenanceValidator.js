import { z } from 'zod';

// =========================================================================
// Maintenance Request Schema
// =========================================================================

export const requestSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required'),
    priority: z.enum(['Low', 'Medium', 'High', 'Critical']).default('Low'),
    problemTitle: z.string().min(3, 'Problem Title must be at least 3 characters'),
    problemDescription: z.string().optional().nullable(),
    assignedTechnician: z.number().int().optional().nullable(),
    remarks: z.string().optional().nullable(),
    status: z.enum(['Open', 'Assigned', 'In Progress', 'Waiting Parts', 'Completed', 'Cancelled', 'Rejected']).optional(),
  }),
};

// =========================================================================
// Maintenance Record Schema (Start / Complete)
// =========================================================================

const partSchema = z.object({
  partName: z.string().min(1, 'Part Name is required'),
  quantity: z.number().int().positive('Quantity must be positive'),
  unitCost: z.number().nonnegative('Unit Cost cannot be negative'),
});

export const recordSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required').optional(),
    requestId: z.number().int().optional().nullable(),
    maintenanceType: z.enum(['Preventive', 'Corrective', 'Warranty', 'Inspection', 'Upgrade', 'Cleaning', 'Calibration']).default('Corrective'),
    performedBy: z.enum(['INTERNAL', 'EXTERNAL']).default('INTERNAL'),
    vendorId: z.number().int().optional().nullable(),
    technicianName: z.string().optional().nullable(),
    startDate: z.preprocess((val) => new Date(val), z.date()).optional(),
    endDate: z.preprocess((val) => new Date(val), z.date()).optional().nullable(),
    labourCost: z.number().nonnegative().optional().nullable(),
    partsCost: z.number().nonnegative().optional().nullable(),
    cost: z.number().nonnegative().optional().nullable(),
    downtimeHours: z.number().nonnegative().optional().nullable(),
    maintenanceDescription: z.string().optional().nullable(),
    resolution: z.string().optional().nullable(),
    status: z.enum(['Scheduled', 'In Progress', 'Completed', 'Cancelled']).optional(),
    invoiceFile: z.string().optional().nullable(),
    remarks: z.string().optional().nullable(),
    parts: z.array(partSchema).optional(),
  }),
};

// =========================================================================
// Maintenance Schedule Schema
// =========================================================================

export const scheduleSchema = {
  body: z.object({
    assetId: z.number().int('Asset ID is required'),
    scheduleName: z.string().min(3, 'Schedule Name must be at least 3 characters'),
    maintenanceType: z.enum(['Preventive', 'Corrective', 'Warranty', 'Inspection', 'Upgrade', 'Cleaning', 'Calibration']).default('Preventive'),
    frequency: z.enum(['Weekly', 'Monthly', 'Quarterly', 'Half-Yearly', 'Yearly']),
    assignedTechnician: z.number().int().optional().nullable(),
    vendorId: z.number().int().optional().nullable(),
    isActive: z.boolean().default(true),
    remarks: z.string().optional().nullable(),
  }),
};

// =========================================================================
// Technician Directory Schema
// =========================================================================

export const technicianSchema = {
  body: z.object({
    employeeId: z.string().min(3, 'Employee ID is required'),
    name: z.string().min(3, 'Name is required'),
    email: z.string().email('Invalid email address'),
    phone: z.string().optional().nullable(),
    specialization: z.string().optional().nullable(),
    isInternal: z.boolean().default(true),
    vendorId: z.number().int().optional().nullable(),
    status: z.enum(['Active', 'Inactive']).default('Active'),
  }),
};
